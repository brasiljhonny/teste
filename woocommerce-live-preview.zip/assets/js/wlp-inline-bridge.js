(function(){
  function until(cond, cb, timeoutMs=8000, step=100){
    const t0 = Date.now();
    (function spin(){
      if (cond()) return cb();
      if (Date.now()-t0 > timeoutMs) return cb(new Error('timeout LivePreview core'));
      setTimeout(spin, step);
    })();
  }
  function getCore(){ try{ return window.LivePreview?.core || null; }catch(e){ return null; } }
  function attach(core){ const { ui } = core; if(ui && typeof ui.open==='function'){ ui.open=function(){ ui.updateCatalog?.(); ui.updateCanvas?.().then(()=>{ ui.redraw?.(); }); }; } }
  until(()=>!!(window.wlpSettings && window.LivePreview && getCore()), function(){ const core=getCore(); if(core) attach(core); });
})();