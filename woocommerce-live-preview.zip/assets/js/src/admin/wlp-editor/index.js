import { Canvas, Rect, Circle, Polyline, Line, controlsUtils } from 'fabric/es'; // v6
import { nanoid } from 'nanoid';
import TomSelect from 'tom-select';
import 'tom-select/dist/css/tom-select.css';

( function ( $, window, i18n, ajaxurl, settings ) {
	const { __ } = i18n;

	window.printableAreaEditor = {
		_view: false,
		nonce: null,
		canvas: null,
		fCanvas: null,
		cW: 600,
		cH: 600,
		sizer: 1,
		postId: 0,
		areas: [],
		options: {},
		previewMap: new Map(),
		polylinePoints: [],
		closingHandle: null,
		segments: [],
		isDrawing: false,
		originalData: {
			areas: [],
			options: {},
		},

		debug( message ) {
			if ( settings.debug ) {
				// eslint-disable-next-line no-console
				console.debug( message );
			}
		},

		init() {
			const data = { ...this._view.model?.attributes?.meta?.printable_areas };
			data.areas = data.areas ?? [];
			data.options = data.options ?? {};

			this.canvas = document.querySelector( '.printable-area-editor #mask-editor' );
			this.previewCanvas = document.createElement( 'canvas' );

			if ( ! this.canvas ) {
				this.debug( 'Canvas not found' );
				return;
			}

			const width = document.querySelector( `.printable-area-editor #paedit-x-${ this.postId }` );
			const height = document.querySelector( `.printable-area-editor #paedit-y-${ this.postId }` );
			const sizer = document.querySelector( `.printable-area-editor #paedit-sizer-${ this.postId }` );
			this.cW = width
				? this.round( parseInt( width?.value ?? 600 ) * parseFloat( sizer?.value ?? 1 ) )
				: this.cW;
			this.cH = height
				? this.round( parseInt( height?.value ?? 600 ) * parseFloat( sizer?.value ?? 1 ) )
				: this.cH;

			this.aspectRatio = this.cW / this.cH;

			if ( this.fCanvas ) {
				this.fCanvas.destroy();
			}

			this.fCanvas = new Canvas( this.canvas, {
				setRetinaScaling: true,
				left: 0,
				top: 0,
				width: this.cW,
				height: this.cH,
				backgroundColor: '#fff0',
			} );

			this.ts = new TomSelect( document.querySelector( 'select#paedit-wpo-option-dropdown' ), {
				placeholder: __( 'Select any product options', 'woocommerce-live-preview' ),
				closeAfterSelect: false,
				onChange: this.onAssignedOptionsChange.bind( this ),
				plugins: {
					remove_button:{
						title: __( 'Remove this item', 'woocommerce-live-preview' ),
					}
				},
			} );

			this.bindEvents();
			this.resetAreas( data.areas );
			this.options = data.options;
			this.checkClipboardButtons();
			$( 'a.wlp-live-preview-documentation' ).attr( 'tabindex', 0 ).trigger( 'blur' );
		},

		displayCanvas( image ) {
			image.parentElement.querySelector( 'canvas#mask-editor' ).style.display = 'block';
		},

		bindEvents() {
			this.fCanvas.on( 'selection:created', this.selectionChange.bind( this ) );
			this.fCanvas.on( 'selection:updated', this.selectionChange.bind( this ) );
			this.fCanvas.on( 'selection:cleared', this.selectionChange.bind( this ) );

			this.fCanvas.on( 'object:modified', ( e ) => {
				this.updateAreaData( e.target );
			} );

			this.fCanvas.on( 'object:moving', ( e ) => {
				const obj = e.target;
				obj.left = Math.max( this.round( obj.left ), 0 );
				obj.top = Math.max( this.round( obj.top ), 0 );
				obj.left = Math.min( obj.left, this.cW - obj.getScaledWidth() );
				obj.top = Math.min( obj.top, this.cH - obj.getScaledHeight() );
				obj.setCoords();
				this.fCanvas.renderAll();
				this.showInfo( obj );
			} );

			this.fCanvas.on( 'object:scaling', ( e ) => {
				/**
				 * TODO: Fix scaling issues when the object is near the canvas edges
				 */
				const obj = e.target;
				const corner = e.transform.corner;
				let maxScaleX = ( obj.aCoords.br.x - Math.max( obj.aCoords.tl.x, 0 ) ) / obj.width;
				let maxScaleY = ( obj.aCoords.br.y - Math.max( obj.aCoords.tl.y, 0 ) ) / obj.height;

				if ( [ 't', 'b' ].includes( corner[ 0 ] ) ) {
					maxScaleX = Math.min( maxScaleX, maxScaleY );
					maxScaleY = Math.min( maxScaleX, maxScaleY );
				}

				obj.scaleX = Math.min( obj.scaleX, ( this.cW - obj.left ) / obj.width );
				obj.scaleY = Math.min( obj.scaleY, ( this.cH - obj.top ) / obj.height );

				if (
					( corner[ 1 ] === 'l' && obj.left < 0 ) ||
					( corner[ 1 ] === 'r' && obj.left + obj.getScaledWidth() > this.cW )
				) {
					obj.left = corner[ 1 ] === 'l' ? obj.aCoords.tl.x : obj.aCoords.tr.x - obj.getScaledWidth();
					obj.scaleX = maxScaleX;

					if ( corner[ 0 ] === 't' || corner[ 0 ] === 'b' ) {
						obj.scaleY = maxScaleY;
						obj.top = corner[ 0 ] === 't' ? obj.aCoords.tl.y : obj.aCoords.bl.y - obj.getScaledHeight();
					}
				}

				if (
					( corner[ 0 ] === 't' && obj.top < 0 ) ||
					( corner[ 0 ] === 'b' && obj.top + obj.getScaledHeight() > this.cH )
				) {
					obj.top = corner[ 0 ] === 't' ? obj.aCoords.tl.y : this.cH - obj.getScaledHeight();
					obj.scaleY = maxScaleY;

					if ( corner[ 1 ] === 'l' || corner[ 1 ] === 'r' ) {
						obj.scaleX = maxScaleX;
						obj.left = obj.aCoords.tl.x;
					}
				}

				obj.scaleX = this.round( obj.scaleX, 3 );
				obj.scaleY = this.round( obj.scaleY, 3 );
				const defaultProps = this.getDefaultFabricObjectProps();
				obj.set( {
					...defaultProps,
					strokeWidth: defaultProps.strokeWidth / Math.min( obj.scaleX, obj.scaleY ),
					strokeDashArray: defaultProps.strokeDashArray.map(
						( dash ) => dash / Math.min( obj.scaleX, obj.scaleY )
					),
				} );

				obj.setCoords();
				this.showInfo( obj );
				this.fCanvas.renderAll();
			} );

			// canvas Drawing
			window.addEventListener( 'dblclick', () => {
				if ( this.isDrawing ) {
					this.fCanvas.remove( ...this.fCanvas.getObjects( 'Line' ) );
					this.addPolylineToCanvas();
				  
					this.polylinePoints = [];
					this.segments = [];
					this.isDrawing = false;
					this.fCanvas.defaultCursor = 'default';
					this.fCanvas.getObjects().forEach( ( obj ) => {
						obj.selectable = true;
					} );
				}
			} );
		
			this.fCanvas.on( 'mouse:down', ( event ) => {
				if ( this.isDrawing ) {
					this.fCanvas.selection = false;

					let { x, y } = event.pointer
					if ( this.polylinePoints.length > 0 ) {
						const lastPoint = this.polylinePoints[ this.polylinePoints.length - 1 ];
						if ( x === lastPoint.x && y === lastPoint.y ) {
							return;
						}
					}

					if ( this.segments.length > 0 && Math.abs( x - this.segments[0].x1 ) < 10 && Math.abs( y - this.segments[0].y1 ) < 10 ) {
						x = this.segments[0].x1;
						y = this.segments[0].y1;
						this.isDrawing = false;
					}

					this.polylinePoints.push( { x, y } );
					const points = [ x, y, x, y ];
					this.segments.push( new Line( points, {
						strokeWidth: 3,
						selectable: false,
						stroke: 'red',
						strokeLineCap: 'round',
					}) );
					this.fCanvas.add( this.segments[ this.segments.length - 1 ] );

					if ( this.segments.length === 1 ) {
						this.closingHandle = new Rect( {
							left: x - 5,
							top: y - 5,
							width: 10,
							height: 10,
							strokeWidth: 2,
							stroke: 'red',
							selectable: false,
							opacity: 0,
							hoverCursor: 'crosshair',
						} );
						this.fCanvas.add( this.closingHandle );
					}

					if ( ! this.isDrawing ) {
						this.fCanvas.remove( ...this.segments, this.closingHandle );
						this.addPolylineToCanvas();
					  
						this.polylinePoints = [];
						this.segments = [];
						this.fCanvas.defaultCursor = 'default';
						this.fCanvas.getObjects().forEach( ( obj ) => {
							obj.selectable = true;
						} );	
					}
				}
			});

			this.fCanvas.on( 'mouse:up', () => {
				if ( this.isDrawing ) {
					this.fCanvas.selection = true;
				}
			} );

			this.fCanvas.on( 'mouse:move', ( event ) => {
				if ( this.isDrawing && this.segments?.[0] ) {
					let closingHandleOpacity = 0;
					const { x, y } = event.pointer
					this.segments[ this.segments.length - 1 ].set( {
						x2: x,
						y2: y
					} );
					this.fCanvas.renderAll();

					if ( Math.abs( x - this.segments[0].x1 ) < 10 && Math.abs( y - this.segments[0].y1 ) < 10 ) {
						this.segments[ this.segments.length - 1 ].set( {
							x2: this.segments[0].x1,
							y2: this.segments[0].y1
						} );
						closingHandleOpacity = 1;
						this.fCanvas.renderAll();
					}

					this.closingHandle.set( {
						opacity: closingHandleOpacity,
					} );
				}
			} );

			// Add the handler to change events of the checkboxes and selectbox
			document.querySelectorAll( '.printable-area-editor input[type="checkbox"]' ).forEach( ( el ) => {
				const fieldSet = el.closest( '.paedit-checkbox-option' );
				if ( fieldSet.classList.contains( 'global-setting' ) ) {
					el.addEventListener( 'change', ( e ) => {
						this.options[ e.target.name ] = e.target.checked;
					} );
				} else if ( fieldSet.classList.contains( 'area-setting' ) ) {
					el.addEventListener( 'change', ( e ) => {
						const fabricObject = this.fCanvas.getActiveObject();
						if ( ! fabricObject ) {
							return;
						}
						const areaId = fabricObject.id;
						const area = this.areas.find( ( area ) => area.id === areaId );
						if ( ! area ) {
							return;
						}
						area.options[ e.target.name ] = e.target.checked;
					} );
				}
			} );

			document.removeEventListener( 'keydown', this.onDeleteArea.bind( this ) );
			document.addEventListener( 'keydown', this.onDeleteArea.bind( this ) );
		},

		open( postId, nonce, view ) {
			this._oldView = this._view;
			this._view = view;
			this.postId = postId;
			this.nonce = nonce;

			const data = {
				action: 'wlp_editor',
				attachment_id: postId,
				nonce: this.nonce,
			};

			$.ajax( {
				url: ajaxurl,
				data,
				method: 'POST',
				success: ( response ) => {
					if ( response.success ) {
						$( '.media-modal .media-frame-content' ).html( response.data.html );
						this.init( response.data );
					} else {
						this.debug( response );
					}
				},
				error: ( error ) => {
					this.debug( error );
				},
			} );
		},

		close() {
			document.querySelector( '.media-modal-close' )?.click?.();
			if ( this._view ) {
				this._view.render();
			}
			this._view = this._oldView;
		},

		save() {
			const printableAreas = {
				areas: this.areas,
				options: this.options
			};

			this._view.model.save(
				{ printableAreas }
			).done( ( model ) => {
				this._view.model.attributes.meta.printable_areas = printableAreas;
				delete this._view.model.attributes.printableAreas;
				this.close();
				this._view.render();
				this._view.controller.library._requery( true );
				this.checkClipboardButtons();
			} ).fail( ( model ) => {
				this.debug( 'save:fail', model );
			} ).always( ( error ) => {
				this.debug( 'save:always', error );
			});
		},

		onAssignedOptionsChange(values) {
			const fabricObject = this.fCanvas.getActiveObject();
			if ( ! fabricObject ) {
				return;
			}
			const area = this.areas.find( ( area ) => area.id === fabricObject.id );
			if ( ! area ) {
				return;
			}

			area.options.assigned_options = values.join( ',' );
		},

		getDefaultFabricObjectProps() {
			return {
				fill: '#d1712240',
				stroke: '#d17122',
				strokeWidth: 0,
				strokeDashArray: [ 0 ],
				opacity: 1,
				selectable: true,
				hoverCursor: 'default',
				hasBorders: true,
				hasControls: true,
				borderColor: '#2271b1',
				cornerColor: '#2271b1',
				cornerStyle: 'square',
				cornerSize: 10,
				borderWidth: 2,
				borderDashArray: [ 5, 5 ],
			};
		},

		getDefaultOptions() {
			return {
				single_image: false,
				no_resize: false,
				no_move: false,
				no_rotate: false,
				assigned_options: [],
			};
		},

		getDefaultAreaDimensions() {
			const size = Math.min( this.cW, this.cH ) / 4;
			return {
				x: ( this.cW - size ) / 2,
				y: ( this.cH - size ) / 2,
				size,
			};
		},

		addRectangleArea() {
			const d = this.getDefaultAreaDimensions();
			const defaultProps = this.getDefaultFabricObjectProps();
			const rectangleArea = new Rect( {
				...defaultProps,
				left: d.x,
				top: d.y,
				width: d.size,
				height: d.size,
			} );

			rectangleArea.id = nanoid();

			this.fCanvas.add( rectangleArea );
			this.areas.push( this.getAreaData( rectangleArea ) );
		},

		addCircleArea() {
			const d = this.getDefaultAreaDimensions();
			const defaultProps = this.getDefaultFabricObjectProps();
			const circleArea = new Circle( {
				...defaultProps,
				left: d.x,
				top: d.y,
				radius: d.size / 2,
			} );

			circleArea.id = nanoid();

			this.fCanvas.add( circleArea );
			this.areas.push( this.getAreaData( circleArea ) );
		},

		addFreeformArea() {
			if ( this.isDrawing ) {
				this.isDrawing = false;
				this.fCanvas.defaultCursor = 'default';
				this.fCanvas.getObjects().forEach( ( obj ) => {
					obj.selectable = true;
				} );
				this.segments.forEach(function(value, index, ar){
					this.fCanvas.remove(value);
				});
				this.addPolylineToCanvas();
			} else {
				this.isDrawing = true;
				this.fCanvas.defaultCursor = 'crosshair';
				this.fCanvas.getObjects().forEach( ( obj ) => {
					obj.selectable = false;
				} );
			}
		},

		getAreaData( fabricObject ) {
			let { type, left, top, radius, points, angle } = fabricObject;
			left = this.normalize( left, this.cW );
			top = this.normalize( top, this.cH );
			let width = this.normalize( fabricObject.getScaledWidth(), this.cW );
			let height = this.normalize( fabricObject.getScaledHeight(), this.cH );

			if ( type === 'circle' ) {
				radius = { radius: this.normalize( radius, this.cH ) };
			} else {
				radius = {};
			}

			if ( type === 'polyline' ) {
				points = {
					points: points.map( ( { x, y } ) => ( {
						x: this.normalize( x, this.cW ),
						y: this.normalize( y, this.cH ),
					} ) ),
				};
			} else {
				points = {};
			}

			return {
				id: fabricObject.id,
				type,
				left,
				top,
				width,
				height,
				angle,
				...radius,
				...points,
				options: this.getDefaultOptions(),
			};
		},

		selectionChange( e ) {
			if ( e?.selected?.length ) {
				this.showInfo( e.selected[ 0 ] );
			} else {
				this.showInfo( null );
			}
		},

		showInfo( obj ) {
			const areaSettings = document.querySelector( '#selected-area-settings' );
			areaSettings.classList.toggle( 'hidden', ! obj );

			if ( ! obj ) {
				return;
			}

			const area = this.areas.find( ( area ) => area.id === obj.id );
			const areaOptions = area.options ?? {};
			const areaOptionsCheckboxes = document.querySelectorAll( '.printable-area-editor .area-setting input[type="checkbox"]' );
			areaOptionsCheckboxes.forEach( ( checkbox ) => {
				checkbox.checked = areaOptions[ checkbox.name ];
			} );

			const typeEl = document.querySelector( '#selected-area-type' );
			const positionEl = document.querySelector( '#selected-area-position' );
			const sizeEl = document.querySelector( '#selected-area-size' );

			this.ts.setValue( String(areaOptions?.assigned_options ?? '').split(',') ?? [] );

			const type = {
				rect: 'Rectangle',
				circle: 'Circle',
				polyline: 'Polyline',
			};
			typeEl.textContent = type[ obj.type ];
			positionEl.textContent = `${ this.round( obj.left ) }, ${ this.round( obj.top ) }`;
			sizeEl.textContent = `${ this.round( obj.getScaledWidth() ) } × ${ this.round( obj.getScaledHeight() ) }`;
			
		},

		updateAreaData( fabricObject ) {
			const areaIndex = this.areas.findIndex( ( a ) => a.id === fabricObject.id );
			this.areas[ areaIndex ] = this.getAreaData( fabricObject );
		},

		normalize( number, size ) {
			const value = this.round( number / ( size * this.sizer ), 3 );

			return value;
		},

		round( number, precision = 0 ) {
			const factor = 10 ** precision;
			return Math.round( number * factor ) / factor;
		},

		onDeleteArea( event ) {
			if ( event.key === 'Delete' || event.key === 'Backspace' ) {
				this.removeActiveArea();
			}
		},

		removeActiveArea() {
			const activeObject = this.fCanvas.getActiveObject();
			if ( activeObject ) {
				const id = activeObject.id;
				this.areas = this.areas.filter( ( area ) => area.id !== id );
				this.fCanvas.remove( activeObject );
			}
		},

		getFabric() {
			return this.fCanvas;
		},

		getAreas() {
			return this.areas;
		},

		resetAreas( areas = [], fCanvas = null, props = {} ) {
			fCanvas = fCanvas ?? this.fCanvas;

			if ( ! fCanvas ) {
				fCanvas = this.previewMap.get( document.querySelector( 'canvas#printable-area-preview' ) );
			}

			if ( ! fCanvas ) {
				this.debug( 'Canvas not found' );
				return;
			}

			this.areas = [ ...areas ];
			fCanvas.clear();

			const cW = fCanvas.width;
			const cH = fCanvas.height;

			const shapeTypes = {
				rect: Rect,
				circle: Circle,
				polyline: Polyline,
			};

			areas.forEach( ( area ) => {
				const { type, left, top, width, height, radius, points, angle } = area;
				const nPoints = Array.isArray( points ) && points.length > 0 ? [ ...points ] : null;
				area.options = { ...this.getDefaultOptions(), ...( area.options ?? {} ) };
				delete area.options.variations;

				if ( type === 'polyline' ) {
					nPoints.forEach( ( point, index ) => {
						nPoints[ index ] = {
							x: point.x * cW,
							y: point.y * cH,
						};
					} );
				}

				const defaultProps = this.getDefaultFabricObjectProps();
				const scaleX = type === 'circle' ? width / ( 2 * radius ) : 1;
				const scaleY = type === 'circle' ? height / ( 2 * radius ) : 1;

				const shapeProps = [
					nPoints,
					{
						...defaultProps,
						...props,
						left: left * cW,
						top: top * cH,
						width: width * cW,
						height: height * cH,
						angle,
						radius: type === 'circle' ? radius * cH : 0,
						scaleX: type === 'circle' ? width * cW / ( 2 * radius * cH ) : 1,
						scaleY: type === 'circle' ? height * cH / ( 2 * radius * cH ) : 1,
						strokeWidth: defaultProps.strokeWidth / Math.min( scaleX, scaleY ),
						strokeDashArray: defaultProps.strokeDashArray.map(
							( dash ) => dash / Math.min( scaleX, scaleY )
						),
					},
				].filter( Boolean );

				const fabricObject = new shapeTypes[ type ]( ...shapeProps );
				fabricObject.id = area.id;

				if ( type === 'polyline' ) {
					fabricObject.controls = controlsUtils.createPolyControls( fabricObject.points.length );
				}

				fCanvas.add( fabricObject );
			} );

			fCanvas.renderAll();
		},

		checkClipboardButtons: function () {
			const hasAreas = this._view?.model?.attributes.meta?.printable_areas?.areas?.length > 0;
			const hasClipboard = this.clipboard?.areas.length > 0;
			const copyButton = document.querySelector( '#wlp-button-copy' );
			const pasteButton = document.querySelector( '#wlp-button-paste' );

			copyButton && ( copyButton.disabled = ! hasAreas );
			pasteButton && ( pasteButton.disabled = ! hasClipboard );
		},

		copyAreas( postId = null, nonce = null ) {
			if ( postId ) {
				this.clipboard = this._view.model.attributes.meta.printable_areas;
				this.checkClipboardButtons();
			}
		},

		pasteAreas( postId = null, nonce = null ) {
			const previewContainer = document.querySelector( '.attachment-media-view .thumbnail-image .preview-container' );
			previewContainer.classList.add( 'loading' );

			if ( this.clipboard?.areas.length > 0 ) {
				const printableAreas = this.clipboard;
				printableAreas.areas = printableAreas.areas.map( ( area ) => {
					return {
						...area,
						id: nanoid(),
					};
				} ); 
				postId = postId ?? this.postId;

				this._view.model.save(
					{ printableAreas }
				).done( ( model ) => {
					this._view.model.attributes.meta.printable_areas = this.clipboard;
					delete this._view.model.attributes.printableAreas;
					this._view.controller.library._requery(true);
					this.resetAreas( this.clipboard.areas, this.previewMap.get( document.querySelector( 'canvas#printable-area-preview' ) ) );
					previewContainer.classList.remove( 'loading' );
					this.checkClipboardButtons();
				} ).fail( ( error ) => {
					this.debug( 'paste:fail', error );
				} ).always( ( object ) => {
					this.debug( 'paste:always', object );
				} );

				return;
			}

			previewContainer.classList.remove( 'loading' );
		},

		restoreDataFromClipboard() {
			if ( this.clipboard?.areas.length > 0 ) {
				this.resetAreas( this.clipboard.areas, this.previewMap.get( document.querySelector( 'canvas#printable-area-preview' ) ) );
			}
		},

		addPolylineToCanvas() {
			const polyline = new Polyline( this.polylinePoints, {
				...this.getDefaultFabricObjectProps(),
			} );
			polyline.id = nanoid();
			polyline.controls = controlsUtils.createPolyControls( polyline.points.length );
			this.fCanvas.add( polyline );
			this.fCanvas.renderAll();
			this.areas.push( this.getAreaData( polyline ) );
		},
		
		resizeCanvas() {
			const canvas = document.querySelector( 'canvas#printable-area-preview' );
			const container = canvas?.closest( '.thumbnail-image' );

			if ( ! container ) {
				return;
			}

			const image = container.querySelector( 'img.details-image' );
			const width = image.clientWidth;
			const height = image.clientHeight;
			const fCanvas = this.previewMap.get( canvas );
		
			// Resize the Fabric.js canvas
			fCanvas.setWidth( width );
			fCanvas.setHeight( height );

			// Optionally scale objects on the canvas (if desired)
			const scaleX = width / fCanvas.getWidth();
			const scaleY = height / fCanvas.getHeight();
			fCanvas.getObjects().forEach( ( obj ) => {
				obj.scaleX = obj.scaleX * scaleX;
				obj.scaleY = obj.scaleY * scaleY;
				obj.left = obj.left * scaleX;
				obj.top = obj.top * scaleY;
				obj.setCoords();
			} );
		
			// Re-render the canvas
			fCanvas.renderAll();
		},
	};

	window.addEventListener( 'resize', () => {
		printableAreaEditor.resizeCanvas();
	} );
} )( jQuery, window, wp.i18n, window.ajaxurl, window.wlpEditor );
