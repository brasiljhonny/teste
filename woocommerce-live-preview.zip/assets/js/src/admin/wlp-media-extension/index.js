import { Canvas } from 'fabric/es';

/* eslint-disable object-shorthand */
( function ( media, window ) {
	const currentTwoColumn = media.view.Attachment.Details.TwoColumn;

	media.view.Attachment.Details.TwoColumn = currentTwoColumn.extend( {
		template: function( view ) {
			const html = currentTwoColumn.prototype.template( view );
			const content = document.createElement( 'div' );
			content.innerHTML = html;

			// STEP 1: Add the printable area editor buttons

			const thumbnailImage = content.querySelector( '.attachment-media-view .thumbnail-image' );

			if ( ! thumbnailImage ) {
				return content.innerHTML;
			}

			const attachmentCompat = content.querySelector( '.attachment-info .settings .attachment-compat' );
			const buttonSpan = document.createElement( 'span' );
			buttonSpan.classList.add( 'setting', 'wlp-media-setting' );
			buttonSpan.innerHTML = wp.media.template( 'wlp-printable-area-buttons' )( view );
			attachmentCompat.parentElement.insertBefore( buttonSpan, attachmentCompat );

			const hasAreas = this.model?.attributes?.meta?.printable_areas?.areas?.length > 0;
			content.querySelector( '#wlp-button-set' ).classList.toggle( 'hidden', hasAreas );
			content.querySelector( '#wlp-button-edit' ).classList.toggle( 'hidden', ! hasAreas );

			// STEP 2: Wrap the thumbnail img element with a container and add a canvas to preview the printable areas

			const previewContainer = document.createElement( 'div' );
			previewContainer.classList.add( 'preview-container' );
			thumbnailImage.appendChild( previewContainer );

			let canvas = document.querySelector( '#printable-area-preview' );
			if ( ! canvas ) {
				canvas = document.createElement( 'canvas' );
				canvas.id = 'printable-area-preview';
			}

			previewContainer.appendChild( canvas );
			thumbnailImage.prepend( previewContainer );

			return content.innerHTML;
		},

		events: {
			...currentTwoColumn.prototype.events,
			'click .edit-attachment': 'editAttachment',
			'click .wlp-editor-button': 'buttonClick',
		},

		render: function () {
			currentTwoColumn.prototype.render.apply(this, arguments);

			setTimeout( () => {
				window.printableAreaEditor._view = this;
				window.jQuery( '.barn2-help-tip' ).tipTip( { attribute: 'data-tip', edgeOffset: -20, maxWidth: '400px' } );
				this.printableAreaEditor().checkClipboardButtons();
				this.renderPreviewCanvas();
			}, 20 );
		},

		printableAreaEditor: function () {
			return window.printableAreaEditor;
		},

		buttonClick: function ( e ) {
			e.preventDefault();
			const action = e.target.dataset?.action;

			if ( ! action ) {
				return this;
			}

			const postId = e.target.dataset.postId;
			const nonce = e.target.dataset.nonce;
			this.printableAreaEditor()[ action ]( postId, nonce, this );
		},

		renderPreviewCanvas: function () {
			const canvas = document.querySelector( '#printable-area-preview' );

			if ( ! canvas ) {
				return this;
			}

			if ( ! this.printableAreaEditor().previewMap.has( canvas ) ) {
				const observer = new window.ResizeObserver( ( entries ) => {
					for ( const entry of entries ) {
						const { width, height } = entry.contentRect;
						if ( width * height > 0 ) {
							this.resetAreas( canvas, width, height );
							return this;
						}
					}
				} );

				observer.observe( canvas.closest( '.thumbnail-image' ).querySelector( 'img' ) );
			} else {
				this.resetAreas( canvas );
			}

			return this;
		},

		updateAreas: function ( areas ) {
			const library = this.controller.library,
				self = this;

			this.model.attributes.meta.printable_areas.areas = areas;
			this.model.save().done( () => {
				library._requery( true );
				self.renderPreviewCanvas();

				/*
				* @todo We need to move focus back to the previous, next, or first
				* attachment but the library gets re-queried and refreshed.
				* Thus, the references to the previous attachments are lost.
				* We need an alternate method.
				*/
				self.moveFocusToLastFallback();
			} );

			const canvas = document.querySelector( '#printable-area-preview' );

			if ( ! canvas ) {
				return this;
			}

			this.resetAreas( canvas );
		},

		resetAreas: function ( canvas, width = null, height = null ) {
			let fCanvas;

			if ( ! this.printableAreaEditor().previewMap.has( canvas ) ) {
				fCanvas = new Canvas( canvas, {
					setRetinaScaling: true,
					left: 0,
					top: 0,
					width: width ?? canvas.width,
					height: height ?? canvas.height,
					backgroundColor: '#fff0',
				} );

				this.printableAreaEditor().previewMap.set( canvas, fCanvas );

				fCanvas.on( 'mouse:down', ( event ) => {
					const target = fCanvas.findTarget( event );

					// if the event falls inside a printable area, open the editor
					if ( target ) {
						this.printableAreaEditor().open(
							this.model.attributes.id,
							this.model.attributes.nonces.printable_area,
							this
						);
					}
				} );
			} else {
				fCanvas = this.printableAreaEditor().previewMap.get( canvas );
			}

			const defaultOptions = {
				selectable: false,
				hasControls: false,
				hoverCursor: 'pointer',
				strokeWidth: 1,
				strokeDashArray: [ 5, 5 ],
			};

			this.printableAreaEditor().resetAreas(
				this.model.attributes.meta.printable_areas.areas,
				fCanvas,
				defaultOptions
			);

			return this;
		},
	} );
} )( window.wp.media, window );
