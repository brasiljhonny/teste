/**
 * External dependencies
 */

/**
 * Fabric.js
 * 
 * The reason why we import everything from 'fabric/es' is that importing a single class
 * pulls most of the library as dependencies anyway.
 * Because of that, the increment in bundle size between importing everything
 * and importing a single class is negligible, so we import everything not only for simplicity
 * but most importantly to ensure that all classes are available when needed
 * so that adding new features does not require changing this import.
 */
import * as classes from 'fabric/es';

/**
 * Internal dependencies
 */
import { displayRatio, redraw, removeObject } from './ui';
import { uid, applyFilters } from './utils';

export const maskTypes = [ 'rect', 'circle', 'polyline' ];
const maskTypeClasses = () => ( { rect: classes.Rect, circle: classes.Circle, polyline: classes.Polyline } );
const maskTypeClass = ( type ) => {
	const classes = maskTypeClasses();
	if ( type in classes ) {
		return classes[ type ];
	}
	return null;
};

export const exportableTypes = () => {
	return applyFilters( 'wlpExportableTypes', [] );
};

const solidDashArray = [];
const dashedDashArray = [ 5, 5 ];
export const dashArray = ( isSolid ) => {
	return ( isSolid ? solidDashArray : dashedDashArray ).map( ( v ) => v * displayRatio() );
};

export const defaultMaskProps = ( object = null ) => {
	return {
		fill: '#0001',
		stroke: '#fff7',
		strokeWidth: 2 * displayRatio(),
		strokeDashArray: dashedDashArray.map( ( v ) => v * displayRatio() ),
		strokeUniform: true,
		selectable: false,
		cornerColor: '#fff',
		cornerStrokeColor: '#000',
		cornerScaleFactor: 5,
		hoverCursor: 'default',
		opacity: object?.id === 'full' ? 0 : 1,
		objectCaching: false,
	};
};

export const defaultObjectProps = () => {
	return {
		borderColor: '#fff',
		borderScaleFactor: 2 * displayRatio(),
		cornerSize: 10 * displayRatio(),
		touchCornerSize: 25 * displayRatio(),
		cornerStrokeColor: '#fff',
		cornerColor: '#999',
		borderOpacityWhenMoving: 0.75,
		objectCaching: false,
	};
};

export const deleteControl = ( props = {} ) => {
	return customControl({
		...props,
		actionName: 'delete',
		cornerSize: 24 * displayRatio(),
		touchCornerSize: 40 * displayRatio(),
		offsetX: 16 * displayRatio(),
		offsetY: -16 * displayRatio(),
		icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="%23EA3323"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z"/></svg>',
	});
};

export const customControl = ( props ) => {
	const img = new Image();
	img.src = props.icon;
	delete props.icon;

	return new classes.Control( {
		...props,
		x: 0.5,
		y: -0.5,
		cursorStyle: 'pointer',
		render: ( ctx, left, top, _styleOverride, fabricObject ) => {
			const size = 24 * displayRatio();
			ctx.save();
			ctx.translate(left, top);
			ctx.rotate( classes.util.degreesToRadians( fabricObject.angle ) );
			ctx.beginPath();
			ctx.arc( 0, 0, 1.25 * size / 2, 0, Math.PI * 2, false );
			ctx.closePath();
			ctx.fillStyle = '#ffffff'
			ctx.fill();
			ctx.drawImage( img, -size / 2, -size / 2, size, size);
			ctx.restore();
		},
	} );
}

export const createCanvas = ( canvasElement, props = {} ) => {
	classes.Canvas.prototype.activeSelection = classes.ActiveSelection;

	const newCanvas = new classes.Canvas( canvasElement, {
		...props,
		enableRetinaScaling: true,
		backgroundColor: '#ddd',
		preserveObjectStacking: true,
	} );

	newCanvas.setZoom( 1 );
	newCanvas.setDimensions( {
		width: canvasElement.width,
		height: canvasElement.height,
	} );
	
	return newCanvas;
}

/**
 * Create a printable area of the specified type.
 *
 * @param {string} type - The type of printable area.
 * @param {*} args
 * @returns
 */
export const createMask = ( type, args ) => {
	const maskClass = maskTypeClass( type );
	if ( ! maskClass ) {
		throw new Error( `Invalid mask type: ${ type }` );
	}

	args[ args.length - 1 ] = {
		...defaultMaskProps(),
		...args[ args.length - 1 ] ?? {},
	}

	classes.FabricObject.prototype.objectCaching = false;
	const mask = new maskClass( ...args );

	mask.set( { id: args[ args.length - 1 ].id || uid() } );

	return mask;
}

export const createImageFromURL = ( url, props = {} ) => {
	return new Promise( ( resolve, reject ) => {
		if ( ! url ) {
			reject( 'Image URL is required.' );
			return;
		}

		classes.FabricImage.fromURL( url, { objectCaching: false, crossOrigin: 'anonymous' } ).then( ( image ) => {
			image.set( {
				...props,
			} );
			image.set( { id: props.id || uid() } );
			resolve( image );
		} );
	} );
};

export const createColor = ( color ) => {
	if ( typeof color === 'string' ) {
		color = classes.Color.fromHex( color );
	} else if ( !( color instanceof Color ) ) {
		throw new Error( 'Invalid color format. Must be a string or a Color instance.' );
	}

	return color;
};

const clipPathProps = ( mask ) => {
	const maskPoints = [ ...( mask?.points ?? [] ), mask?.points?.[ 0 ] ?? null ].filter( Boolean );
	let left = 0;
	let top = 0;
	let width = 0;
	let height = 0;

	if ( mask ) {
		left = mask.left;
		top = mask.top;
		width = mask.width;
		height = mask.height;
	}

	return [
		mask?.type === 'polyline' ? maskPoints : null,
		{
			absolutePositioned: true,
			angle: mask.angle,
			selectable: false,
			originX: 'left',
			originY: 'top',
			left,
			top,
			width,
			height,
			scaleX: mask?.type === 'circle' ? mask.scaleX : 1,
			scaleY: mask?.type === 'circle' ? mask.scaleY : 1,
			radius: mask?.type === 'circle' ? mask.radius : null,
		},
	].filter( Boolean );
};

export const clipPath = ( mask ) => {
	const clipPathClass = maskTypeClass( mask.type ) ?? Rect;

	return new clipPathClass( ...clipPathProps( mask ) );
};

export const toggleMControls = ( object ) => {
	object.setControlsVisibility({
		mt: ! object.controls.mt.visible,
		mb: ! object.controls.mb.visible,
		ml: ! object.controls.ml.visible,
		mr: ! object.controls.mr.visible,
		mtr: ! object.controls.mtr.visible,
	});
	redraw();
}

export const repaint = ( color, image ) => {
	if ( ! image ) {
		return;
	}

	image.filters = [
		new classes.filters.BlendColor( { color: color, mode: 'tint', alpha: 1 } ),
	];
	image.applyFilters();
}

export const recolor = ( color, image ) => {
	if ( ! image ) {
		return;
	}

	const filter = new classes.filters.Composed( {
		subFilters: [
			new classes.filters.Grayscale( { mode: 'luminosity' } ), // make it black and white
			new classes.filters.BlendColor( { color: color, mode: 'lighten' } ), // apply a darker color
		]
	} );
	image.filters = [ filter ];
	image.applyFilters();
};

export const duoColor = ( color1, color2, image ) => {
	if ( ! image ) {
		return;
	}

	const filter = new classes.filters.Composed( {
		subFilters: [
			new classes.filters.Grayscale( { mode: 'luminosity' } ), // make it black and white
			new classes.filters.BlendColor( { color: color1 } ), // apply a lighter color
			new classes.filters.BlendColor( { color: color2, mode: 'lighten' } ), // apply a darker color
		]
	} );
	image.filters = [ filter ];
	image.applyFilters();
};

export { classes };