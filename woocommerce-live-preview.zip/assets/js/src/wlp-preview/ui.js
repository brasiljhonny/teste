/**
 * External dependencies
 */
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';


/**
 * Internal dependencies
 */
import { createCanvas, createMask, createImageFromURL, exportableTypes, maskTypes, dashArray, defaultMaskProps, classes } from './fabric';
import { get as getState, set as setState, fromMaskMap, toMaskMap, fromObjectMap, findKeyByObject, cachedImages } from './state';
import { dispatchEvent, getStringHash, applyFilters, debug, warn, isIOS } from './utils';
import { getModuleByType, getModuleByClass, getModuleByOption } from './modules';

const _domElements = {
	modal: null,
	container: null,
	catalog: null,
	canvas: null,
	buttons: {},
	productImages: [],
	variationImages: [],
	availableProductImages: [],
	activeMask: null,
	oData: {},
	foundVariation: null,
	productImageIndex: -1,
	optionId: 0,
	uploadedFiles: [],
	filledInFields: [],
	previewImages: [],
	showMasks: true,
};

let highlightedMask = null;
let draggedObject = null;
let isSelectionEvent = false;

export const get = ( key ) => {
	if ( ! key ) {
		return _domElements;
	}

	if ( key in _domElements ) {
		return _domElements[ key ];
	}

	return null;
}

export const set = ( partial ) => {
	Object.assign( _domElements, partial );
};

export const setFoundVariation = ( variation ) => {
	// before setting the new variation, reset the previous one
	if ( get( 'foundVariation' ) ) {
		const previousVariation = get( 'foundVariation' );
		const galleryImages = document.querySelectorAll( wlpSettings.options.gallery_image_selector );
		galleryImages.forEach( ( element ) => {
			const image = element.querySelector( 'img' );
			if ( image.dataset.original_large_image === previousVariation?.image?.full_src ) {
				Object.assign( image, {
					src: previousVariation?.image?.src,
					srcset: previousVariation?.image?.srcset,
				} );
				Object.assign( image.dataset, {
					large_image: previousVariation?.image?.full_src,
					original_src: previousVariation?.image?.src,
					original_srcset: previousVariation?.image?.srcset,
					original_large_image: previousVariation?.image?.full_src,
				} );
				delete image.dataset.livePreview

				const zoomImg = image
					.closest( wlpSettings.options.gallery_image_selector )
					?.querySelector( 'img.zoomImg' );
				if ( zoomImg ) {
					zoomImg.src = previousVariation.image.full_src;
					zoomImg.srcset = '';
				}
			}
		} );
	}

	set( { foundVariation: variation } );
};

export const modal = () => {
	return get( 'modal' );
};

const setupModal = () => {
	if ( modal() ) {
		return;
	}

	const template = document.querySelector( 'template#wlp-modal-template' );
	const modalElement = template.content.cloneNode( true );
	document.body.appendChild( modalElement );

	set( {
		modal: document.querySelector( '#wlp-live-preview-modal' ),
		container: document.querySelector( '#wlp-live-preview-container' )
	} );
};

const container = () => {
	return get( 'container' );
};

export const canvas = () => {
	return get( 'canvas' );
};

export const displayRatio = () => {
	return canvas().width / canvas().lowerCanvasEl.offsetWidth;
};

export const catalog = () => {
	return get( 'catalog' );
};

const setupCatalog = () => {
	if ( catalog() ) {
		return;
	}

	set( { catalog: modal().querySelector( '#wlp-live-preview-catalog' ) } );
	updateCatalog();
};

export const updateCatalog = () => {
	if ( ! catalog() ) {
		setupCatalog();
	}

	const itemList = catalog().querySelector( '#wlp-catalog' );
	itemList.innerHTML = '';

	document.querySelectorAll( '.wpo-field[data-live-preview-button-text]' ).forEach( ( field ) => {
		const optionId = field.dataset.optionId;
		if ( isOptionPreviewable( optionId ) ) {
			const module = getModuleByClass( field.className );

			module?.getObjectsByOption( optionId )?.forEach( ( object, index ) => {
				addCatalogItem( object, index );
			} );
		}
	} );

	document
		.querySelector( '.single-product div.product .woocommerce-product-gallery' )
		?.classList?.toggle( 'has-catalog', itemList.querySelectorAll( 'li' ).length > 0 );
	
	setAvailableProductImages();
};

const addCatalogItem = ( object, index ) => {
	const module = getModuleByType( object.type );
	if ( ! module ) {
		warn( `No module found for object type: ${ object.type }` );
		return;
	}

	const template = document.querySelector( 'template#wlp-catalog-item' );
	let item = template.content.cloneNode( true ).querySelector( `li.wlp-catalog-item.is-${ object.type }` );
	item.id = `wlp-catalog-item-${ object.optionId }-${ index }`;

	const itemOption = item.querySelector( '.wlp-catalog-item-option' );
	const field = document.querySelector( `.wpo-field[data-option-id="${ object.optionId }"]` );

	let fieldName = field?.querySelector( 'p.wpo-option-name' ) ?? '';
	if ( field.classList.contains( 'wpo-label-is-option-name' ) ) {
		fieldName = field?.querySelector( 'label' );
	}

	fieldName = fieldName.cloneNode( true );
	fieldName.querySelectorAll( 'a' ).forEach( ( a ) => {
		a.remove();
	} );
	fieldName = fieldName.textContent ?? '';
	itemOption.textContent = fieldName;
	itemOption.title = fieldName;

	item = module.formatCatalogItem( item, object );

	if ( ! item ) {
		// the external module has the ability to remove the item from the DOM
		// in which case we bail out
		return;
	}

	item.classList.add( `is-${object.type}` );
	Object.assign( item.dataset, {
		...object,
	} );
	item.addEventListener( 'dragstart', onCatalogItemDragStart );
	// item.addEventListener( 'touchstart', onCatalogItemDragStart );
	item.addEventListener( 'click', addCatalogItemToCanvas );

	catalog()?.querySelector( '#wlp-catalog' ).appendChild( item );
}

const onCatalogItemDragStart = ( event ) => {
	const itemList = catalog()?.querySelector( '#wlp-catalog' );
	const item = event.target.closest( 'li' );
	draggedObject = { ...item.dataset };
	if ( event.dataTransfer ) {
		event.dataTransfer.setData( 'text/plain', JSON.stringify( draggedObject ) );
		event.dataTransfer.dropEffect = 'none';
	}
	const draggedItem = item.cloneNode(true);
	draggedItem.classList.add( 'is-dragging' );
	draggedItem.querySelectorAll( '.item-info' )?.forEach( (element) => {
		element.remove();
	} );

	Object.assign( draggedItem.style, {
		position: 'absolute',
		top: '-9999px',
		left: '-9999px',
	} );
	
	itemList.appendChild(draggedItem);

	if ( event.dataTransfer ) {
		event.dataTransfer.setDragImage(draggedItem, 0, 0);
	}
	requestAnimationFrame(() => {
		setTimeout(() => draggedItem.remove(), 0); // allows render cycle to complete
	});
};

const addObjectToCanvas = ( object, mask ) => {
	mask = mask || activeMask( object.optionId );
	const module = getModuleByType( object.type );

	if ( ! module ) {
		warn( `No module found for object type: ${ object.type }` );
		return;
	}

	module.addToCanvas( object, mask );
}

export const addCatalogItemToCanvas = ( event ) => {
	const listItem = event.target.closest( 'li' );
	const object = { ...( listItem?.dataset ?? {} ) }

	addObjectToCanvas( object );
};

const setupCanvas = () => {
	if ( canvas() ) {
		return;
	}

	const canvasElement = container().querySelector( 'canvas#wlp-live-preview-canvas' );

	container().querySelector( 'div.canvas-container[data-fabric="wrappernew "]' )?.remove();

	const canvasScale = calculateCanvasScale( wlpSettings.options.max_canvas_size );

	// Floor the canvas dimensions to the largest even numbers
	canvasElement.width = Math.floor( canvasScale * wlpSettings.options.max_canvas_size * 2 ) / 2;
	canvasElement.height = Math.floor( canvasScale * wlpSettings.options.max_canvas_size * 2 ) / 2;

	const fCanvas = createCanvas( canvasElement );
	// const ratio = window.devicePixelRatio || 1;
	// const width = canvasElement.clientWidth;
	// const height = canvasElement.clientHeight;

	// canvasElement.width = width * ratio;
	// canvasElement.height = height * ratio;
	// fCanvas.setWidth(width);
	// fCanvas.setHeight(height);
	// fCanvas.setZoom(ratio);

	set( { canvas: fCanvas } );

	const buttons = get( 'buttons' ) || {};
	const prevButton = modal().querySelector( 'span.wlp-prev-image' );
	prevButton.addEventListener( 'click', () => {
		set( { productImageIndex: prevButton.dataset.index } );
		updateCanvas()
			.catch( ( error ) => {
				debug( error );
			} );
	} );

	buttons.prev = prevButton;

	const nextButton = modal().querySelector( 'span.wlp-next-image' );
	nextButton.addEventListener( 'click', () => {
		set( { productImageIndex: nextButton.dataset.index } );
		updateCanvas()
			.catch( ( error ) => {
				debug( error );
			} );
	} );
	buttons.next = nextButton;

	set( { buttons } );

	fCanvas.on( 'before:render', () => {
		// console.time( 'canvasRender' );
	});

	fCanvas.on( 'after:render', () => {
		// console.timeEnd( 'canvasRender' );
	});

	fCanvas.on( 'object:scaling', ( event ) => {
		// add any scaling logic that applies to every possible object type
	} );

	fCanvas.on( 'object:moving', ( event ) => {
		// add any moving logic that applies to every possible object type

		// if the SHIFT key is pressed, we move only in the X or Y axis
		// depending on which delta is greater
		if ( event.e.shiftKey ) {
			const object = event.target;
			const ox = event.transform.original.left;
			const oy = event.transform.original.top;
			const x = object.left - ox;
			const y = object.top - oy;
			const isX = Math.abs( x ) > Math.abs( y );
			const delta = Math.max( Math.abs( x ), Math.abs( y ) );
			const sign = Math.sign( isX ? x : y );

			// calculate deltaX and deltaY based on delta, sign and the angle of the image
			let deltaX = delta * sign * Math.cos( classes.util.degreesToRadians( object.angle ) );
			let deltaY = delta * sign * Math.sin( classes.util.degreesToRadians( object.angle ) );

			if ( ! isX ) {
				deltaX = - delta * sign * Math.sin( classes.util.degreesToRadians( object.angle ) );
				deltaY = delta * sign * Math.cos( classes.util.degreesToRadians( object.angle ) );
			}

			object.set( {
				left: ox + deltaX,
				top: oy + deltaY,
			} );

			object.setCoords();
		}
	} );

	fCanvas.on( 'object:rotating', ( event ) => {
		// add any rotating logic that applies to every possible object type

		const object = event.target;
		// if the SHIFT key is pressed, we rotate the object in 15° steps
		if ( event.e.shiftKey ) {
			object.snapAngle = 15;
		} else {
			object.snapAngle = 0;
		}
	} );

	// highlight the mask when clicked
	fCanvas.on( 'mouse:down', ( event ) => {
		if ( isSelectionEvent ) {
			isSelectionEvent = false;
			return;
		}

		deselectMask();
		const mask = fCanvas.findTarget( event );
		if ( mask && maskTypes.includes( mask.type ) ) {
			selectMask( mask, true );
			redraw( fCanvas );
		}
	} );

	fCanvas.on( 'selection:created', ( event ) => {
		unsetMaskHighlight();
		isSelectionEvent = true;
		if ( exportableTypes().includes( event?.selected?.[0]?.type ) ) {
			const mask = canvas().getObjects( ...maskTypes ).find( ( m ) => m.id === event?.selected?.[0]?.parentId );
			if ( mask ) {
				set( { activeMask: mask } );
			}
		}
	} );

	fCanvas.on( 'selection:updated', ( event ) => {
		unsetMaskHighlight();
		isSelectionEvent = true;
		if ( exportableTypes().includes( event?.selected?.[0]?.type ) ) {
			const mask = canvas().getObjects( ...maskTypes ).find( ( m ) => m.id === event?.selected?.[0]?.parentId );
			if ( mask ) {
				set( { activeMask: mask } );
			}
		}
	} );

	fCanvas.on( 'selection:cleared', ( event ) => {
		set( { activeMask: null } );
	} );

	// highlight the mask when dragging an image over it
	fCanvas.elements.container.addEventListener( 'dragover', ( event ) => {
		if ( event.dataTransfer ) {
			event.dataTransfer.dropEffect = 'none';
		}

		const objects = fCanvas.getObjects( ...exportableTypes() );
		objects.forEach( ( object ) => {
			object.set( 'visible', false );
		} );
		event.preventDefault();
		unsetMaskHighlight();
		const target = fCanvas.findTarget( event );
		if ( target && fCanvas.getObjects( ...maskTypes ).includes( target ) ) {
			const droppable = canAddObjectToMask( target, draggedObject );
			if ( event.dataTransfer ) {
				event.dataTransfer.dropEffect = droppable ? 'copy' : 'none';
			}
			setMaskHighlight( target, droppable );
		}
		objects.forEach( ( object ) => {
			object.set( 'visible', true );
		} );
		redraw( fCanvas );
	} );

	fCanvas.elements.container.addEventListener( 'dragleave', ( event ) => {
		event.preventDefault();
		event.target.style.cursor = 'normal';

		flashMaskHighlight();
	} );

	// add the image to the canvas when dropped over a mask
	fCanvas.elements.container.addEventListener( 'drop', ( event ) => {
		event.preventDefault();
		event.target.style.cursor = 'normal';

		const target = fCanvas.findTarget( event );
		let destination = target;

		if ( exportableTypes().includes( target?.type ) ) {
			const maskId = findKeyByObject( target );

			if ( maskId ) {
				const mask = fCanvas.getObjects( ...maskTypes ).find( ( m ) => m.id === maskId );

				if ( mask ) {
					destination = mask;
				}
			}
		}

		const droppable = canAddObjectToMask( destination, draggedObject );
		if ( event.dataTransfer ) {
			event.dataTransfer.dropEffect = droppable ? 'copy' : 'none';
		}

		if ( ! droppable ) {
			flashMaskHighlight( destination )
				.then( () => {
					draggedObject = null;
				} );
			return;
		}

		if ( maskTypes.includes( destination?.type ) ) {
			if ( ! canAddObjectToMask( destination, draggedObject ) ) {
				// the text is not assigned to the current mask
				flashMaskHighlight( destination )
					.then( () => {
						draggedObject = null;
					} );
				return;
			}

			dispatchEvent( 'wlp:object:dropping', {
				object: draggedObject,
				destination,
				target,
			} );
		}

		draggedObject = null;
		deselectMask();
	} );

	// link CTRL/CMD scroll to fabric canvas zoom
	fCanvas.on( 'mouse:wheel', ( event ) => {
		if ( event?.e?.ctrlKey || event?.e?.metaKey ) {
			const canvasRect = canvas().getElement()?.getBoundingClientRect();

			if ( ! canvasRect ) {
				return;
			}

			// zoom the canvas around the mouse pointer
			const delta = Math.max( -1, Math.min( 1, event?.e?.deltaY ) );
			const zoom = canvas().getZoom();
			// `pointer` is not deprecated for the Fabricjs events.
			canvas().zoomToPoint( event.pointer, zoom + ( delta * zoom ) / 10 );
			canvas().getObjects( ...maskTypes ).forEach( ( object ) => {
				object.set( {
					strokeWidth: 2 * displayRatio(),
					strokeDashArray: dashArray( object.id === activeMask()?.id, displayRatio() ),
				});
			} );
		}
	} );
};

export const updateCanvas = ( image = null ) => {
	return new Promise( ( resolve, reject ) => {
		image = image ?? productImage();

		let index = get( 'productImageIndex' );

		if ( ! image ) {
			reject( 'No image found' );
			return;
		}

		set( { productImageIndex: productImages().indexOf( image ) } );
		index = get( 'productImageIndex' );

		deselectMask();
		removeFromCanvas();

		createImageFromURL( backgroundImage( image ), { objectCaching: false } ).then( ( img ) => {
			if ( ! img || ! img.width || ! img.height ) {
				reject( 'It was not possible to create the background image.' );
				return;
			}

			const canvasScale = calculateCanvasScale( img.width, img.height );
			set( { canvasScale } );

			const cW = Math.floor( canvasScale * img.width * 2 ) / 2;
			const cH = Math.floor( canvasScale * img.height * 2 ) / 2;
			const aspectRatio = cW / cH;

			canvas().setDimensions( {
				width: cW,
				height: cH,
			} );
			img.scaleToWidth( cW );
			img.scaleToHeight( cH );
			resetZoom();

			canvas().backgroundImage = img;
			canvas().backgroundImage.objectCaching = false;
			canvas().backgroundImage.dirty = true;
			canvas().elements.container.style.height = `${ cH }px`;
			canvas().elements.container.style.aspectRatio = `${ aspectRatio }`;

			let printableAreas = imageMasks() ?? [];

			if ( printableAreas.length === 0 ) {
				resetImage( image );
				close();
				reject( 'No printable areas found.' );
				return;
			}

			printableAreas = printableAreas.filter(
				( mask ) =>
					! canvas()
						.getObjects()
						.map( ( o ) => o.id )
						.includes( mask.id )
			);

			add( ...printableAreas );
			printableAreas.forEach( ( mask ) => {
				canvas().sendObjectToBack( mask );
			} );

			const objectPromises = [];
			printableAreas.forEach( ( mask ) => {
				// get the objects already added to the printable area
				let objects = fromObjectMap( mask.id );
				let emptyPrintableArea = objects.length === 0;

				if ( emptyPrintableArea ) {
					// if a printable area is empty, we get a list of objects that can be added to the mask
					objects = applyFilters( 'wlpInitialObjects', [], mask );
				}

				if ( objects.length > 0 && emptyPrintableArea ) {
					// if the printable area is initially empty,
					// only add the first object found
					objects = [ objects[0] ];
				}

				objects.forEach( ( object ) => {
					objectPromises.push( addObjectToCanvas( object, mask ) );
				} );
			} );

			Promise.all( objectPromises ).then( () => {
				updateSliderButtons();
				redraw();
				resolve();
			} );
		} )
		.catch( ( error ) => {
			reject( 'Error loading background image' );
		} );
	} );
};

/**
 * 
 * @param {int} width 
 * @param {int} height 
 * @returns {float} The scale factor to apply to the canvas
 */
const calculateCanvasScale = ( width, height = null ) => {
	// If height is not provided, use width for both dimensions
	height = height || width;

	// we need to upscale the canvas to improve the image quality
	// but we don't want to upscale too much because it will slow down the image creation process
	// or create problems with devices setting limits to the maximum canvas size
	// So the maximum scale is `max_upscale_factor` times the original image size
	// or a factor that will make the maximum canvas width or height `max_canvas_size`
	const calculatedCanvasScale = wlpSettings.options.max_canvas_size / Math.max( width, height );
	let canvasScale = Math.max( Math.round( Math.min( calculatedCanvasScale, wlpSettings.options.max_upscale_factor ) ), 1 );

	// Google Chrome sets a limit to the maximum total pixels of a canvas (256 million pixels)
	// but iOS sets a much lower limit (16 million pixels)
	const maxTotalPixels = isIOS() ? 16777216 : 268435456; // 256 million pixels

	const devicePixelRatio = window?.devicePixelRatio || 1;
	let totalPixels = Math.pow( canvasScale * devicePixelRatio, 2 ) * width * height;

	if ( totalPixels > maxTotalPixels ) {
		// Recalculate the canvas scale to fit the maximum total pixels
		// also taking into account the device pixel ratio
		canvasScale = Math.sqrt( maxTotalPixels / ( width * height ) ) / devicePixelRatio;

		// To compensate for device pixel ratios greater than 1,
		// the canvasScale might be less than 1.
		// Therefore, we approximate it to the nearest value with 3 decimal places
		// that is smaller than the calculated canvas scale
		canvasScale = Math.floor( canvasScale * 1000 ) / 1000;
	}

	return canvasScale;
}

export const removeFromCanvas = ( objects = null ) => {
	if ( ! canvas() ) {
		return;
	}

	objects = objects ?? canvas().getObjects();

	if ( ! Array.isArray( objects ) ) {
		objects = [ objects ].filter( Boolean );
	}

	canvas().remove( ...objects );
	dispatchEvent( 'wlp:canvas:remove', { objects } );
};

export const removeTypesFromCanvas = ( types = null ) => {
	if ( typeof types === 'string' ) {
		types = [ types ];
	}

	if ( ! types ) {
		types = [ ...exportableTypes(), ...maskTypes ];
	}

	removeFromCanvas( canvas()?.getObjects( types ) );
}

const setupImages = () => {
	let productId = document.querySelector( 'form.cart button.single_add_to_cart_button' )?.value;

	if ( ! productId ) {
		productId = document.querySelector( 'form.cart input[name="add-to-cart"]' )?.value;
	}

	set( { productId: productId || 0 } );

	const galleryImages = document.querySelectorAll( wlpSettings.options.gallery_image_selector );
	galleryImages.forEach( ( element, index ) => {
		const image = element.querySelector( 'img' );
		if ( ! image.src.startsWith( 'data:' ) ) {
			setOriginalImage( image );
		}

		addProductImage( image );

		if ( index === 0 ) {
			backupOData();
		}
	} );

	_domElements.productImages = Array.from( galleryImages ).map( ( element ) => element.querySelector( 'img' ) );

	const variationCartForm = document.querySelector( 'form.cart.variations_form' );

	if ( variationCartForm ) {
		const variationId = variationCartForm.querySelector( 'input[name="variation_id"]' )?.value ?? 0;
		const foundVariation = JSON.parse( variationCartForm.dataset.product_variations ).find( ( variation ) => variation?.variation_id === parseInt( variationId ) );
		setFoundVariation( foundVariation ?? null );
	}

	setAvailableProductImages();
};

const setupTriggers = () => {
	document
		.querySelectorAll( '.single-product div.product .woocommerce-product-gallery' )
		.forEach( ( element ) => {
			const trigger = document.createElement( 'a' );
			trigger.classList.add( 'woocommerce-product-live_preview__trigger' );
			trigger.innerText = '✎';
			trigger.title = wlpSettings.options?.live_preview_button_text ?? __( 'Customize', 'woocommerce-live-preview' );
			trigger.href = '#';
			trigger.addEventListener( 'click', () => {
				open();
			} );
			element.appendChild( trigger );
		} );
};

const setupPreviewInput = () => {
	const cartForm = document.querySelector( 'form.cart' );

	if ( ! cartForm ) {
		return;
	}

	if ( ! document.querySelector( 'input[name="wlp-preview-files"]' ) ) {
		const input = document.createElement( 'input' );
		input.type = 'hidden';
		input.name = 'wlp-preview-files';
		cartForm.appendChild( input );
		set( { previewInput: input } );
	}
};

export const defaultOptions = () => {
	return {
		single_image: false,
		no_move: false,
		no_resize: false,
		no_rotate: false,
		default_image_sizing: wlpSettings.options?.default_image_sizing ?? 'contain',
	};
}

const maskAssignedOptions = ( mask, image ) => {
	image = image || productImage();
	const printableOptions = JSON.parse( image?.dataset?.printableOptions ?? '{}' );
	const assignedOptions = String( printableOptions?.assigned_options ?? '' ).split( ',' ).map( ( option ) => parseInt( option || 0 ) ).filter( Boolean );

	return [ ...assignedOptions, ...String(mask?.options?.assigned_options ?? '' ).split( ',' ).map( ( option ) => parseInt( option || 0 ) ).filter( Boolean ) ];
}

export const optionMasks = ( optionId ) => {
	const masks = masksFromProductImage();
	const optionMasks = masks.filter( ( mask ) => {
		return maskAssignedOptions( mask ).includes( optionId );
	} );

	return optionMasks;
};

export const canAddObjectToMask = ( mask, object ) => {
	const assignedOptions = maskAssignedOptions( mask, object );
	const objectOptionId = parseInt( object?.optionId ?? 0 );
	if ( assignedOptions.length === 0 || assignedOptions.includes( objectOptionId ) ) {
		// the mask has no assigned options or the object is assigned to the mask
		return true;
	}

	// the mask has assigned options and the object is not assigned to the mask
	return false;
};

const backgroundImage = ( image ) => {
	let backgroundSrc = image?.dataset?.original_large_image;

	if ( ! backgroundSrc || backgroundSrc === 'undefined' ) {
		setOriginalImage( image );
		backgroundSrc = image?.dataset?.original_large_image;
	}

	if ( get( 'foundVariation' ) ) {
		const vImage = variationImage();
		const vImageInGallery = variationImageInGallery();

		if ( vImage ) {
			if (
				vImageInGallery &&
				vImageInGallery?.dataset?.original_large_image === vImage?.src
			) {
				image = vImageInGallery;
			}
			backgroundSrc = vImage?.src;
		}
	}

	return backgroundSrc;
};

export const productImage = ( index = null ) => {
	if ( get( 'foundVariation' ) ) {
		const vImageInGallery = variationImageInGallery();
		if ( vImageInGallery ) {
			return vImageInGallery;
		}
	}
	index = parseInt( index ?? get( 'productImageIndex' ) );
	let pImage = get( 'availableProductImages' )?.[ 0 ];

	if ( index >= 0 ) {
		pImage = productImages()[ index ];
	}

	return pImage ?? null;
};

const variationImages = () => {
	if ( get( 'variationImages' )?.length > 0 ) {
		return get( 'variationImages' );
	}

	const variationForm = document.querySelector( 'form.cart.variations_form' );
	const variations = JSON.parse( variationForm?.dataset?.product_variations ?? '[]' );

	set( {
		variationImages: variations.map( ( variation ) => ( {
			variation_id: variation.variation_id,
			image_id: variation.image_id,
			src: variation.image.full_src,
			full_src: variation.image.full_src,
			width: variation.image.full_src_w,
			height: variation.image.full_src_h,
			printable_areas: variation.image.printable_areas,
		} ) )
	} );

	return get( 'variationImages' );
};

export const variationImage = () => {
	const foundVariation = get( 'foundVariation' );

	if ( ! foundVariation || ! foundVariation.image ) {
		return null;
	}

	if ( foundVariation && get( 'variationImages' )?.length > 0 ) {
		const vImage = variationImages().find( ( image ) => image?.variation_id === foundVariation?.variation_id );
		if ( vImage && vImage?.printable_areas?.length > 0 ) {
			// the product_variations array contains the variation image
			return vImage;
		}
	}

	// When a product has more variations than the threshold set in WooCommerce,
	// the variation is returned via AJAX request when the event `found_variation` is triggered.
	let printableAreas = foundVariation?.image?.printable_areas;

	if ( ! printableAreas ) {
		const masterVariation = variationImages().filter( ( variationImage ) => {
			return variationImage?.printable_areas?.areas?.length > 0 && variationImage?.printable_areas?.options?.variations;
		} );
		if ( masterVariation.length > 0 ) {
			// We get the printable areas of the first variation
			// that has printable areas and the `variations` option set
			// NOTE: Admins should set the variations option only on one image
			// to avoid unintended behaviors.
			printableAreas = masterVariation[ 0 ].printable_areas;
		}
	}

	const vImage = {
		variation_id: foundVariation.variation_id,
		src: foundVariation.image.full_src,
		full_src: foundVariation.image.full_src,
		width: foundVariation.image.full_src_w,
		height: foundVariation.image.full_src_h,
		printable_areas: printableAreas,
	};

	const vImages = variationImages();
	if ( ! vImages?.find( ( image ) => image.variation_id === vImage.variation_id ) ) {
		// if the variations are loaded dynamically,
		// we keep a reference to the variation image in the variationImages array
		vImages.push( vImage );
		set( { variationImages: vImages } );
	}

	return vImage;
};

const findImageInGallery = ( image ) => {
	const galleryImages = document.querySelectorAll( `${ wlpSettings.options.gallery_image_selector } a img` );
	return Array.from( galleryImages ).findIndex(
		( element ) => element === image || element.dataset.originalLargeImage === image?.dataset?.originalLargeImage
	);
};

const variationImageInGallery = () => {
	const variationSrc = variationImage()?.full_src;
	const galleryImages = document.querySelectorAll( `${ wlpSettings.options.gallery_image_selector } a img` );
	return Array.from( galleryImages ).find(
		( element ) => element?.dataset?.original_large_image === variationSrc
	);
};

export const imageMasks = ( image = null ) => {
	image = image || productImage();
	let masks = fromMaskMap( image ) || [];

	let imagePrintableAreas = masksFromProductImage( image );
	const mainImage = mainProductImage();
	const foundVariation = get( 'foundVariation' );

	if ( foundVariation ) {
		// try to get the printable areas from the variation image
		masks = variationImage()?.printable_areas?.areas ?? [];

		// we found a variation but its image doesn't have any printable areas
		// so we check if the main product image has the "variations" option enabled
		// which allows to extend its printable areas to the variation image
		if ( masks?.length === 0 ) {
			const vImage = variationImage();
			const vImageInGallery = variationImageInGallery();

			if (
				vImage &&
				vImageInGallery &&
				vImageInGallery?.dataset?.original_large_image === vImage?.src
			) {
				// if the variation image is the same as the current image in the gallery
				// then we can replace that image
				image = vImageInGallery;
				masks = fromMaskMap( image ) || [];

				if ( masks.length === 0 ) {
					const variationPrintableAreas = masksFromProductImage( vImage );

					if ( variationPrintableAreas.length > 0 ) {
						imagePrintableAreas = variationPrintableAreas;
					}

					// if we have not found any printable areas at this point,
					// we load those from the main product image
					if ( imagePrintableAreas.length === 0 ) {
						imagePrintableAreas = masksFromProductImage();
					}
				}
			}

			if ( vImage?.src && image?.dataset?.original_large_image !== vImage.src ) {
				// if the variation image is different from the image currently selected
				// then we need to switch back to the main product image but use the source of the variation image
				set( { productImageIndex: 0 } );
				image = productImage();
				masks = fromMaskMap( image ) || [];
				imagePrintableAreas = masksFromProductImage( image );
			}

			if ( masks.length === 0 ) {
				const options = optionsFromProductImage( mainImage );
				if ( options.variations === false ) {
					// the variation image doesn't have any printable areas
					// and the main product image doesn't have the "variations" option enabled
					// we tried everything we could, no printable areas found
					return [];
				}

				masks = fromMaskMap( mainImage ) || [];
			}
		}
	}

	let usableMasks = masks;

	if ( masks.length === 0 ) {
		usableMasks = imagePrintableAreas;
	}

	if ( ! foundVariation ) {
		usableMasks = masksFromProductImage( image );
	}

	toMaskMap( image, usableMasks );

	return usableMasks.map( ( mask ) => {
		const { type, left, top, width, height, radius, points } = mask;
		const defaultProps = defaultMaskProps( mask );

		const normalizedPoints =
			points?.map( ( point ) => ( {
				x: point.x * canvas().width,
				y: point.y * canvas().height,
			} ) ) ?? [];

		const maskProps = { ...mask };
		delete maskProps.points;
		delete maskProps.type;

		const closedPoints = [ ...normalizedPoints, normalizedPoints[ 0 ] ?? null ].filter( Boolean );
		const props = [
			closedPoints.length > 0 ? closedPoints : null,
			{
				...defaultProps,
				...maskProps,
				left: left * canvas().width,
				top: top * canvas().height,
				width: width * canvas().width,
				height: height * canvas().height,
				radius: type === 'circle' ? radius * canvas().height : null,
				scaleX: type === 'circle' ? ( width * canvas().width ) / ( 2 * radius * canvas().height ) : 1,
				scaleY: type === 'circle' ? ( height * canvas().height ) / ( 2 * radius * canvas().height ) : 1,
				assignedOptions: maskAssignedOptions( mask ),
			},
		].filter( Boolean );

		return createMask( type, props );
	} );
};

export const slideToImage = ( index ) => {
	index = index ?? get( 'productImageIndex' );
	const $gallery = window.jQuery( '.woocommerce-product-gallery--with-images' );

	if ( $gallery.find( '.flex-control-thumbs li' ).length > 0 && typeof $gallery?.flexslider === 'function' ) {
		$gallery.flexslider( index );
	}
};

export const setIsLoading = ( loading = true ) => {
	const productGalleryImage = document.querySelector( wlpSettings.options.gallery_viewport_selector );
	productGalleryImage?.classList.toggle( 'is-loading', loading );
};

export const productImages = () => {
	if ( get( 'productImages' )?.length > 0 ) {
		return get( 'productImages' );
	}
	const images = Array.from( document.querySelectorAll( wlpSettings.options.gallery_image_selector + ' img' ) );
	if ( images.length === 0 ) {
		debug( 'No product images found' );
		return [];
	}
	set( { productImages: images } );
	return images;
};

const setAvailableProductImages = () => {
	// let optionId = 0;
	let availableImages = productImages();

	// optionId = get( 'optionId' );
	availableImages = availableImages.filter( ( image ) => {
		return image?.dataset?.printableAreas?.length > 0;
	} );

	// check which option is valid and filter the images so that
	// only the images with printable areas for those options are returned
	const validFields = previewFields().reduce( ( acc, optionId ) => {
		const module = getModuleByOption( optionId );
		if ( module?.getObjectsByOption( optionId, true ).length > 0 ) {
			acc.push( optionId );
		}

		return acc;
	}, [] );

	availableImages = availableImages.filter( ( image ) => {
		const printableAreas = JSON.parse( image?.dataset?.printableAreas || '[]' );
		if ( printableAreas.length === 0 ) {
			return false;
		}

		const unassignedAreas = printableAreas.filter( ( area ) => {
			const assignedOptions = maskAssignedOptions( area, image );
			return assignedOptions.length === 0 || assignedOptions.every( ( optionId ) => ! validFields.includes( parseInt( optionId ) ) );
		} );

		if ( unassignedAreas.length > 0 ) {
			// If there are areas that are not assigned to any option,
			// the image can be considered valid
			return true;
		}

		let assignedOptions = [];
		printableAreas.forEach( ( area ) => {
			assignedOptions.push( ...maskAssignedOptions( area, image ) );
		} );

		// if the image has no assigned options, we consider it valid
		if ( assignedOptions.length === 0 ) {
			return true;
		}

		// if the image has assigned options, we check if any of them is valid
		return assignedOptions.some( ( optionId ) => validFields.includes( parseInt( optionId ) ) );
	});

	// if no image was found at this point,
	// we need to check if the product has variation images with printable areas
	if ( availableImages.length === 0 ) {
		const vImages = variationImages().filter( ( image ) => image.printable_areas?.areas?.length > 0 && image.printable_areas?.options?.variations );

		if ( vImages.length > 0 ) {
			// if we found at least one variation image with printable areas
			// and its option is set to extend those printable areas to other variations
			// then we add those printable areas for the main product image
			const mainImage = mainProductImage();
			Object.assign( mainImage.dataset, {
				printableAreas: JSON.stringify( vImages[ 0 ].printable_areas.areas ),
				printableOptions: JSON.stringify( vImages[ 0 ].printable_areas.options ),
			});
			availableImages = [ mainImage ];
		}
	}

	const foundVariation = get( 'foundVariation' );
	if ( foundVariation ) {
		variationImages().forEach( ( vImage ) => {
			if ( vImage.src !== foundVariation?.image?.full_src ) {
				availableImages = availableImages.filter( ( image ) => image?.dataset?.original_large_image !== vImage.src );
			}
		} );
	}

	set( { availableProductImages: availableImages } );

	return availableImages;
};

const mainProductImage = () => {
	return productImages()[ 0 ] || document.querySelector( wlpSettings.options.main_product_image_selector );
};

const masksFromProductImage = ( image = null ) => {
	// the canvas is not ready yet
	if ( ! canvas() || canvas().width * canvas().height === 0 ) {
		// the canvas is not ready yet
		return [];
	}

	// a variation is selected, so we get the areas for that variation
	if ( get( 'foundVariation' ) ) {
		const vImage = variationImage();
		const masks = vImage?.printable_areas?.areas;

		// the variation has its own areas
		if ( masks && masks.length > 0 ) {
			return masks;
		}

		
	}

	// if no variation is selected, we get the masks from the product image
	image = image ?? productImage();

	const masks = JSON.parse( image?.dataset?.printableAreas || 'false' );
	if ( ! masks ) {
		// no masks were found in the product image
		return [];
	}

	return masks;
};

const optionsFromProductImage = ( pImage = null ) => {
	let options = {};

	if ( get( 'foundVariation' ) ) {
		const vImage = variationImage();
		options = vImage?.printable_areas?.options;

		if ( ! options ) {
			options = JSON.parse( get( 'availableProductImages' )?.[ 0 ]?.dataset?.printableOptions || 'false' ) || defaultOptions();
		}

		return options;
	}

	pImage = pImage ?? productImage();
	return {
		...defaultOptions(),
		...JSON.parse( pImage?.dataset?.printableOptions || '{}' )
	};
};

export const activeMask = ( optionId ) => {
	let mask = get( 'activeMask' );
	if ( ! mask ) {
		let masks = canvas().getObjects( ...maskTypes );
		
		if ( optionId ) {
			masks = masks.filter( ( m ) => {
				const assignedOptions = maskAssignedOptions( m );
				return assignedOptions.length === 0 || assignedOptions.includes( parseInt( optionId ) );
			} );
		}

		const emptyMasks = masks.filter( ( m ) => ( fromObjectMap( m.id ) ?? [] ).length === 0 );

		if ( emptyMasks.length > 0 ) {
			mask = emptyMasks[ 0 ];
		} else if ( masks.length === 1 ) {
			mask = masks[ 0 ];
		}
	}

	return mask;
};

export const optionsFromMask = ( mask = null ) => {
	mask = mask ?? activeMask();

	return {
		...defaultOptions(),
		...mask?.options || {},
	};
};

export const previewFields = () => {
	return Array.from( document.querySelectorAll( '.wpo-field[data-live-preview-button-text]' ) ).map( ( field ) => {
		return parseInt( field.dataset.optionId );
	} );
}

export const isOptionPreviewable = ( optionId = null ) => {
	optionId = optionId ?? get( 'optionId' );
	let previewableImages = get( 'availableProductImages' ).length;

	const foundVariation = get( 'foundVariation' );
	if ( foundVariation ) {
		const assignedOptions = (foundVariation?.printable_areas?.options?.assigned_options ?? '').split( ',' ).map( ( option ) => parseInt( option || 0 ) ).filter( Boolean );;
		const printableAreas = JSON.parse( foundVariation?.printable_areas?.areas ?? '[]' );
		printableAreas.forEach( ( area ) => {
			if ( area?.options?.assigned_options ) {
				assignedOptions.push( ...maskAssignedOptions( area ) );
			}
		} );
		if ( assignedOptions.length === 0 || assignedOptions.includes( optionId ) ) {
			previewableImages++;
		}
	}

	return previewableImages > 0;
};

const canImagePreviewOption = ( optionId = null ) => {
	optionId = optionId ?? get( 'optionId' );
	const image = productImage();
	if ( ! image ) {
		return false;
	}

	let printableAreas = JSON.parse( image?.dataset?.printableAreas ?? '[]' );

	if ( get( 'foundVariation' ) ) {
		const vImage = variationImage();
		if ( vImage?.printable_areas?.areas?.length > 0 ) {
			printableAreas = vImage.printable_areas.areas;
		} else {
			// if the variation image doesn't have any printable areas,
			// we check if the main product image has the "variations" option enabled
			const options = optionsFromProductImage( mainProductImage() );
			if ( options.variations === false ) {
				return false;
			}
			printableAreas = masksFromProductImage( mainProductImage() );
		}
	}

	if ( printableAreas.length === 0 ) {
		return false;
	}

	let assignedOptions = [];

	for ( const area of printableAreas ) {
		const areaOptions = maskAssignedOptions( area, image );

		if ( areaOptions.length === 0 ) {
			// At least one area has no assigned options.
			// Therefore, the current image can preview any option.
			return true;
		}

		assignedOptions.push( ...areaOptions );
	}

	// remove falsey values and duplicates
	assignedOptions = [ ...new Set( assignedOptions.filter( Boolean ) ) ];

	return assignedOptions.length === 0 || assignedOptions.includes( optionId );
};


const updateSliderButtons = () => {
	const availableImages = get( 'availableProductImages' );
	const imageCount = availableImages.length;
	const allImages = productImages();
	const productIndexes = availableImages.map( ( image ) => allImages.indexOf( image ) );

	const index = parseInt( get( 'productImageIndex' ) ?? -1 );
	const productIndex = productIndexes.indexOf( index );

	const buttons = get( 'buttons' );

	buttons.prev.style.display = imageCount < 2 || index === productIndexes[0] || productIndex < 0 ? 'none' : 'block';
	buttons.next.style.display = imageCount < 2 || index === productIndexes[ imageCount - 1 ] || productIndex < 0 ? 'none' : 'block';

	buttons.prev.dataset.index = productIndexes[ productIndex - 1 ] ?? null;
	buttons.next.dataset.index = productIndexes[ productIndex + 1 ] ?? null;
}

export const redraw = ( c ) => {
	c = c || canvas();
	if ( ! c ) {
		return;
	}

	const maskProps = defaultMaskProps();
	const showMasks = get( 'showMasks' );
	c.getObjects( ...maskTypes ).forEach( ( object ) => {
		object.set( {
			fill: showMasks ? maskProps.fill : 'transparent',
			strokeWidth: maskProps.strokeWidth * ( showMasks ? 1 : ( object === highlightedMask ? 1 : 0 ) ),
		})
	} );

	c.calcOffset();
	c.requestRenderAll();
}

export const add = ( object ) => {
	if ( ! object ) {
		return;
	}
	canvas()?.add( object );
};

export const clear = () => {
	canvas()?.clear();
};

export const resetZoom = () => {
	canvas()?.setZoom( 1 );
	canvas()?.absolutePan( { x: 0, y: 0 } );
};

export const isOpen = () => {
	return document.querySelector( 'html' )?.classList?.contains( 'is-live-preview-modal-open' );
};

export const open = () => {
	if ( get( 'filledInFields' )?.length === 0 ) {
		// If there are no fields filled in, we don't open the modal
		return;
	}

	if ( ! isOptionPreviewable() ) {
		return;
	}

	if ( imageMasks().length === 0 ) {
		return;
	}
	
	updateCatalog();
	updateCanvas()
		.then( () => {
			document.querySelector( 'html' ).classList.add( 'is-live-preview-modal-open' );
			redraw();
			resetZoom();
			dispatchEvent( 'wlp:modal:open', { canvas: canvas() } );
		} )
		.catch( ( error ) => {
			debug( error );
		} );
};

export const apply = () => {
	set( { optionId: 0, isLoading: true } );
	saveResult();
	document.querySelector( 'html' ).classList.remove( 'is-live-preview-modal-open' );
	dispatchEvent( 'wlp:modal:close', { canvas: canvas(), cancel: false, apply: true } );
};

export const close = () => {
	set( { optionId: 0, isLoading: false } );
	removeTypesFromCanvas( exportableTypes() );
	document.querySelector( 'html' ).classList.remove( 'is-live-preview-modal-open' );
	dispatchEvent( 'wlp:modal:close', { canvas: canvas(), cancel: true, apply: false } );
};

export const selectMask = ( mask, success = false ) => {
	set( { activeMask: mask } );
	setMaskHighlight( mask, success );
	setCatalogItemsState();
};

export const deselectMask = ( mask ) => {
	mask = mask || get( 'activeMask' );

	set( { activeMask: null } );
	unsetMaskHighlight( mask );
	setCatalogItemsState();
};

const setMaskHighlight = ( mask, success = false ) => {
	mask = mask || activeMask();
	highlightedMask = mask;
	const defaultProps = defaultMaskProps();

	if ( ! mask || ! maskTypes.includes( mask.type ) ) {
		canvas().getObjects( ...maskTypes ).forEach( ( m ) => {
			m.set( {
				...defaultProps,
			} );
		} );
		redraw();
		return;
	}

	mask.set( {
		...defaultProps,
		stroke: success ? '#03c7a0' : '#ff0000',
		strokeDashArray: dashArray( success, displayRatio() ),
	} );
	redraw();
};

const unsetMaskHighlight = ( mask ) => {
	const defaultProps = defaultMaskProps();

	if ( mask && maskTypes.includes( mask.type ) ) {
		// if a mask is provided, unset the highlight for that mask only
		mask.set( defaultProps );
	} else {
		// if no mask is provided, unset the highlight for all masks
		const masks = canvas().getObjects( ...maskTypes );
		masks.forEach( ( m ) => {
			m.set( defaultProps );
		} );
	}

	highlightedMask = null;
	redraw();
};

export const flashMaskHighlight = ( mask, success = false ) => {
	return new Promise( ( resolve ) => {
		mask = mask || highlightedMask;

		if ( ! mask || ! maskTypes.includes( mask.type ) ) {
			resolve( false );
			return;
		}
		
		// flashes the current mask 4 times with the appropriate border depending on success
		// the flashing time is 75ms
		// the mask is never unselected during the flash but the flash is stopped if the mask is deselected
		const flashTime = 75;
		const flashCount = 4;
		let flashIndex = 0;

		const flash = () => {
			if ( flashIndex >= flashCount ) {
				resolve();
				deselectMask( mask );
				return;
			}

			setMaskHighlight( mask, success );

			setTimeout( () => {
				flashIndex++;
				unsetMaskHighlight( mask );
				setTimeout( () => {
					flash();
				}, flashTime );
			}, flashTime );
		}

		flash();
	} );
}

const addProductImage = ( element ) => {
	_domElements.productImages = [ ..._domElements.productImages, element ];
};

const setImageSource = ( image, src ) => {
	let tempImage = new Image();

	image.closest( 'div' ).style.backgroundImage = `url(${ src })`;

	const swapSource = ( img, url ) => {
		if ( get( 'foundVariation' ) && variationImageInGallery() !== img ) {
			img = mainProductImage();
		}

		if ( ! url.startsWith( 'data:' ) && url.indexOf( 'wpo-uploads' ) < 0 ) {
			img.dataset.original_large_image = img.dataset.large_image;
			img.dataset.original_src = img.src;
			img.dataset.original_srcset = img.srcset;
			img.dataset.original_large_image_width = img.dataset.large_image_width;
			img.dataset.original_large_image_height = img.dataset.large_image_height;
		}
		img.src = url;
		img.srcset = '';
		img.dataset.src = url;
		img.dataset.large_image = url;
		img.closest( 'a' )?.setAttribute( 'href', url );
		img.closest( 'div' ).style.backgroundImage = 'none';
		const zoomImg = img
			.closest( wlpSettings.options.gallery_image_selector )
			?.querySelector( 'img.zoomImg' );
		if ( zoomImg ) {
			zoomImg.src = url;
			zoomImg.srcset = '';
		}
		
		// if ( ! url.startsWith( 'data:' ) ) {
		// 	setIsLoading( false );
		// }
	}
	
	tempImage.onload = () => {
		swapSource( image, src );
		tempImage.onload = null;
		tempImage.remove();
		tempImage = null;
		
	}

	tempImage.src = src;
}

const setOriginalImage = ( image ) => {
	if ( ! image ) {
		return;
	}

	const imageData = image.dataset;

	if ( image.src && ! image.src.startsWith( 'data:' ) && image.src.indexOf( 'wpo-uploads' ) < 0 ) {
		imageData.original_src = image.src;
	}

	imageData.original_srcset = image.srcset;
	const isDataURL = imageData.src.startsWith( 'data:' );
	const largeImage = imageData.large_image;
	const livePreview = imageData.livePreview;

	if ( imageData.large_image && ! isDataURL && largeImage !== livePreview ) {
		imageData.original_large_image = imageData.large_image;
	}
};

export const resetImages = ( images = null ) => {
	images = images || productImages();

	if ( ! images || images.length === 0 ) {
		return;
	}

	images.forEach( ( image ) => {
		resetImage( image );
	} );

	updateSliderButtons();
	updatePreviewInput();

}

export const resetImage = ( image = null ) => {
	image = image || productImages()[ 0 ];

	if ( get( 'foundVariation' ) ) {
		const vImage = variationImageInGallery();
		if ( vImage ) {
			// if the variation image is in the gallery, we reset it
			// setFoundVariation( null );
			const vImageData = vImage.dataset;

			vImage.src = vImageData.original_src;
			vImage.srcset = vImageData.original_srcset;
			vImageData.src = vImageData.original_src;
			vImageData.large_image = vImageData.original_large_image;
			return;
		}
	}

	if ( ! image ) {
		return;
	}

	const imageData = image.dataset;

	image.src = imageData.original_src;
	image.srcset = imageData.original_srcset;
	imageData.src = imageData.original_src;
	imageData.large_image = imageData.original_large_image;

	if ( _domElements.oData?.o_src && get( 'foundVariation' ) ) {
		// the image has the original attributes from the main product image
		// stored in the dataset by the factory WooCommerce variation form script
		// so we need to restore those attributes as well
		for ( const key in _domElements.oData ) {
			imageData[ key ] = _domElements.oData[ key ];
		}
		image.src = imageData.o_src;
		image.height = imageData.o_height;
		image.width = imageData.o_width;
		image.srcset = imageData.o_srcset;
		image.title = imageData.o_title;
		image.alt = imageData.o_alt;
		image.sizes = imageData.o_sizes;
		imageData.caption = imageData.o_dataCaption;
		imageData.src = imageData.o_dataSrc;
		imageData.large_image = imageData.o_dataLarge_image;
		imageData.large_image_width = imageData.o_dataLarge_image_width;
		imageData.large_image_height = imageData.o_dataLarge_image_height;
		imageData.original_src = imageData.o_src;
		imageData.original_srcset = imageData.o_srcset;
		imageData.original_large_image = imageData.o_dataLarge_image;
	}

	image.closest( 'a' )?.setAttribute( 'href', imageData.large_image );
	const zoomImg = image
		.closest( wlpSettings.options.gallery_image_selector )
		?.querySelector( 'img.zoomImg' );

	if ( zoomImg ) {
		zoomImg.src = imageData.large_image;
		zoomImg.srcset = '';
	}
};

export const backupOData = ( image = null ) => {
	image = image || productImages()[ 0 ];
	const imageData = { ...( image?.dataset || {} ) };

	if ( _domElements.oData?.o_src || imageData?.o_src?.startsWith( 'data:' ) ) {
		return;
	}

	Object.assign( _domElements.oData, {
		o_src: imageData?.o_src ?? image.src,
		o_height: imageData?.o_height ?? image.height,
		o_width: imageData?.o_width ?? image.width,
		o_srcset: imageData?.o_srcset ?? image.srcset,
		o_title: imageData?.o_title ?? image.title,
		o_alt: imageData?.o_alt ?? image.alt,
		o_sizes: imageData?.o_sizes ?? image.sizes,
		o_dataCaption: imageData?.o_dataCaption ?? imageData?.caption,
		o_dataSrc: imageData?.o_dataSrc ?? ( imageData.src || image.src ),
		o_dataLarge_image: imageData?.o_dataLarge_image ?? ( imageData.large_image || image.src ),
		o_dataLarge_image_width: imageData?.o_dataLarge_image_width ?? ( imageData.large_image_width || image.width ),
		o_dataLarge_image_height: imageData?.o_dataLarge_image_height ?? ( imageData.large_image_height || image.height ),
	} );
};

const updatePreviewInput = () => {
	const previewFiles = [];

	if ( get( 'foundVariation' ) ) {
		previewFiles.push( variationImageInGallery()?.dataset?.livePreview );
	} else {
		get( 'availableProductImages' )?.forEach( ( image ) => {
			previewFiles.push( image?.dataset?.livePreview );
		} );
	}
	// filter preview files to remove empty values and duplicates
	const previewFilesFiltered = previewFiles.filter( ( file, index, self ) => {
		return file && self.indexOf( file ) === index;
	} );
	get( 'previewInput' ).value = previewFilesFiltered.join( ',' );

	if ( ! get( 'foundVariation' ) ) {
		slideToImage( get( 'productImageIndex' ) );
	}

	setIsLoading( false );
	dispatchEvent( 'wlp:preview:updated', { canvas: canvas() } );
};

const collectPreviewImages = () => {
	let previewImages = get( 'availableProductImages' )?.filter( ( image ) => {
		// check if the image has any masks mapped to it
		return fromMaskMap( image )?.some( ( mask ) => {
			// check if the mask has any objects mapped to it
			if ( fromObjectMap( mask.id )?.length > 0 ) {
				// if the mask has objects mapped to it, we can preview the image
				return true;
			}

			return false;
		});
	} ) ?? [];

	if ( get( 'foundVariation' ) ) {
		const vImage = variationImageInGallery();
		if ( vImage ) {
			// The selected variation image is in the gallery
			// Add it to the preview images
			previewImages.push( vImage );

			const masterVariation = variationImages().find( ( image ) => {
				return image?.printable_areas?.areas?.length > 0 && image?.printable_areas?.options?.variations;
			} );

			// Check if the main product image can be removed from the preview images
			if ( ( vImage.dataset?.printableAreas ?? [] ).length === 0 ) {
				// The variation image has no printable areas,
				// This means that the main product image was only used
				// to extend the printable areas to the variation image
				// Remove it from the preview images
				previewImages = previewImages.filter( ( image ) => {
					return image?.dataset?.original_large_image !== masterVariation?.full_src;
				} );
			}
		}
	}

	previewImages = Array.from( new Set( previewImages ) );

	set( { previewImages } );

	return previewImages;
}

export const saveResult = ( next = false ) => {
	if ( ! next ) {
		// Start processing the first image by collecting all the preview images first
		collectPreviewImages();
	}

	const previewImages = get( 'previewImages' );
	const pImage = previewImages.shift();
	set( { previewImages: previewImages } );

	if ( ! pImage ) {
		if ( ! next ) {
			// The process had just started and there are no images to process
			// Reset all the images in the gallery to their original state
			resetImages();
		}

		// There are no more images to process
		// Update the preview input and return
		updatePreviewInput();
		return;
	}

	updateCanvas( pImage ).then( () => {
		if ( canvas().getObjects( ...exportableTypes() ).length === 0 ) {
			// if the canvas has no images, we:
			//   1. reset the product image to its original state
			//   2. remove the live preview attribute of the image
			//   3. process the next image
			resetImage( pImage );
			delete pImage.dataset.livePreview;
			saveResult( true );

			return;
		}

		redraw();

		const dataURL = canvas().toDataURL( {
			format: wlpSettings.options.file_format,
			quality: wlpSettings.options.file_quality,
			multiplier: 1,
			// enableRetinaScaling: true,
			filter: ( object ) => {
				return exportableTypes().includes( object.type );
			},
		} );
		const dataHash = getStringHash( dataURL );
		const imageData = dataURL.split( ',' )[ 1 ] ?? '';

		if ( imageData.length > 0 ) {
			// we first check whether the image is already cached
			const cachedFile = cachedImages.get( dataHash ) ?? null;

			if ( cachedFile ) {
				// if the image is already cached, we don't need to upload it again
				// because we already have its URL on the server
				setImageSource( pImage, cachedFile );
				pImage.dataset.livePreview = cachedFile;
				// process the next image, if any
				saveResult( true );
				return;
			}

			setIsLoading( true );
			setState( { edited: true } );
			const useResampling = true;
			resampleDataURL( dataURL, useResampling ).then( ( dataURL ) => {
				setImageSource( pImage, dataURL );

				// if the canvas has images, we export the canvas to a data URL
				// and upload it to the server
				// if the image is not cached, we upload it to the server and return its URL
				apiFetch( {
					path: 'wc-live-preview/v1/file-upload',
					method: 'POST',
					data: {
						current_url: getState( 'productId' ),
						file_data: dataURL.split( ',' )[ 1 ] ?? '',
						file_format: wlpSettings.options.file_format === 'jpeg' ? 'jpg' : 'png',
					},
				} )
					.then( ( response ) => {
						pImage.dataset.livePreview = response;
						cachedImages.set( dataHash, response );
						setImageSource( pImage, response );
						// process the next image, if any
						saveResult( true );
					} )
					.catch( ( error ) => {
						debug( 'error', error );
					} );
			} );
		}
	} )
	.catch( ( error ) => {
		debug( error );
		saveResult( true );
	} );
};

const setCatalogItemsState = () => {
	const catalogItems = document.querySelectorAll( '.wlp-catalog-item' );
	const mask = activeMask();
	let assignedOptions = [];
	
	if ( mask ) {
		assignedOptions = maskAssignedOptions( mask );
	}

	catalogItems.forEach( ( item ) => {
		const itemOptionId = parseInt( item.dataset.optionId ?? 0 );
		const isMaskSelected = !! get( 'activeMask' );
		const isDisabled = isMaskSelected && assignedOptions.length > 0 && ! assignedOptions.includes( itemOptionId );
		const isHidden = ! canImagePreviewOption( itemOptionId );

		item.toggleAttribute( 'disabled', isDisabled );
		item.toggleAttribute( 'hidden', isHidden );
	} );
};

/**
 * Resample the content of the canvas using the Hermite filter
 *
 * To improve the quality of images resized inside the canvas,
 * we use the Hermite filter to resample the content of the canvas
 * 
 * @returns Promise<string> The data URL of the resampled image
 */
const resampleDataURL = ( dataURL, resample = true ) => {
	if ( resample === false || isIOS() ) {
		// If resampling is disabled or on iOS, return the original data URL
		if ( isIOS() ) {
			debug( 'iOS does not support a canvas larger than 16777216 pixels. Resampling the final image is automatically disabled.' );
		}
		return Promise.resolve( dataURL );
	}

	return new Promise( ( resolve ) => {
		const fCanvas = canvas();
		const resultImage = document.createElement( 'img' );
		const canvasScale = get( 'canvasScale' ) ?? 4

		resultImage.onload = () => {
			const newCanvas = document.createElement( 'canvas' );
			const width_source = fCanvas.width;
			const height_source = fCanvas.height;
			const width = width_source / canvasScale;
			const height = height_source / canvasScale;
			newCanvas.width = width_source;
			newCanvas.height = height_source;

			const ratio_w = width_source / width;
			const ratio_h = height_source / height;
			const ratio_w_half = Math.ceil( ratio_w / 2 );
			const ratio_h_half = Math.ceil( ratio_h / 2 );

			const newCtx = newCanvas.getContext( '2d' );
			newCtx.drawImage( resultImage, 0, 0, width_source, height_source );
			const img = newCtx.getImageData( 0, 0, width_source, height_source );
			const img2 = newCtx.createImageData( width, height );
			const data = img.data;
			const data2 = img2.data;

			for ( let j = 0; j < height; j++ ) {
				for ( let i = 0; i < width; i++ ) {
					const x2 = ( i + j * width ) * 4;
					let weight = 0;
					let weights = 0;
					let weights_alpha = 0;
					let gx_r = 0;
					let gx_g = 0;
					let gx_b = 0;
					let gx_a = 0;
					const center_y = ( j + 0.5 ) * ratio_h;
					const yy_start = Math.floor( j * ratio_h );
					const yy_stop = Math.ceil( ( j + 1 ) * ratio_h );
					for ( let yy = yy_start; yy < yy_stop; yy++ ) {
						const dy = Math.abs( center_y - ( yy + 0.5 ) ) / ratio_h_half;
						const center_x = ( i + 0.5 ) * ratio_w;
						const w0 = dy * dy; //pre-calc part of w
						const xx_start = Math.floor( i * ratio_w );
						const xx_stop = Math.ceil( ( i + 1 ) * ratio_w );
						for ( let xx = xx_start; xx < xx_stop; xx++ ) {
							const dx = Math.abs( center_x - ( xx + 0.5 ) ) / ratio_w_half;
							const w = Math.sqrt( w0 + dx * dx );
							if ( w >= 1 ) {
								continue;
							}
							// hermite filter
							weight = 2 * w * w * w - 3 * w * w + 1;
							const pos_x = 4 * ( xx + yy * width_source );
							//alpha
							gx_a += weight * data[ pos_x + 3 ];
							weights_alpha += weight;
							//colors
							if ( data[ pos_x + 3 ] < 255 ) {
								weight = ( weight * data[ pos_x + 3 ] ) / 250;
							}
							gx_r += weight * data[ pos_x ];
							gx_g += weight * data[ pos_x + 1 ];
							gx_b += weight * data[ pos_x + 2 ];
							weights += weight;
						}
					}
					data2[ x2 ] = gx_r / weights;
					data2[ x2 + 1 ] = gx_g / weights;
					data2[ x2 + 2 ] = gx_b / weights;
					data2[ x2 + 3 ] = gx_a / weights_alpha;
				}
			}

			newCanvas.width = width;
			newCanvas.height = height;

			newCtx.putImageData( img2, 0, 0 );
			const newDataURL = newCanvas.toDataURL();

			resultImage.remove();
			newCanvas.remove();

			resolve( newDataURL );
		};

		if ( wlpSettings.options?.use_canvas_resampling ?? true ) {
			resultImage.src = dataURL;
		} else {
			resolve( dataURL );
		}
	} );
};

export const setup = () => {
	setupImages();
	setupModal();
	setupCanvas();
	setupCatalog();
	setupTriggers();
	setupPreviewInput();
	updateCanvas()
		.catch( ( error ) => {
			debug( error );
		} );
}

