/**
 * Internal dependencies
 */
import * as modules from './modules';
import * as fabric from './fabric';
import * as state from './state';
import * as ui from './ui';
import * as utils from './utils';

export default ( settings ) => {
	const $ = window.jQuery;

	state.init( settings );

	const core = {
		fabric,
		state,
		ui,
		utils,
	};

	const addModule = ( name, loader ) => {
		if ( modules.hasModule( name ) ) {
			// the module is already loaded
			// return the existing module
			return modules.getModule( name );
		}

		if ( typeof loader === 'function' ) {
			const newModule = modules.addModule( name, loader( core ) );
			newModule.init();
			return newModule;
		}
	};

	const getModule = ( name ) => {
		if ( ! modules.hasModule( name ) ) {
			throw new Error( `Module '${ name }' not found.` );
		}
		return modules.getModule( name );
	};

	const activeObjects = () => {
		return ui.canvas().getActiveObjects();
	};

	const onFoundVariation = ( event, variation ) => {
		if ( ! variation || ! variation.variation_id ) {
			return;
		}

		ui.setFoundVariation( variation );

		let vImage = ui.variationImage();
		if ( vImage ) {
			ui.resetImage( vImage );
		}

		vImage = ui.variationImage();

		if ( vImage ) {
			const imageIndex = ui.productImages( true ).findIndex(
				// ( image ) => image.src === variationImage.src
				( image ) => image === ui.productImage()
			);

			ui.set( { productImageIndex: Math.max( 0, imageIndex ) } );

			const image = ui.productImages( true )[ imageIndex ];
			if ( image ) {
				ui.backupOData( image );
				Object.assign( image.dataset, {
					original_src: vImage.src,
					original_srcset: '',
					original_large_image: vImage.full_src,
				} );
			}

			if ( ui.isOpen() ) {
				ui.updateCanvas()
					.then( () => {
						ui.setIsLoading( false );
					} )
					.catch( ( error ) => {
						utils.debug( 'onFoundVariation error:', error );
					} )
			} else {
				if ( ui.get( 'filledInFields' )?.length > 0 ) {
					ui.saveResult();
				}
			}
		}
	}

	const onResetVariation = () => {
		ui.setIsLoading( true );
		ui.slideToImage( 0 );
		ui.resetImage( ui.variationImage() );
		ui.resetImage( ui.productImages( true )[ 0 ] );
		ui.updateCanvas()
			.catch( ( error ) => {
				utils.debug( 'onResetVariation error:', error );
			} )
			.finally( () => {
				ui.setFoundVariation( null );
				ui.setIsLoading( false );
			} );
	};

	const bindEvents = () => {
		document.querySelector( '.wlp-live-preview-close' )?.addEventListener( 'click', ui.close );
		document.querySelector( '#wlp-live-preview-cancel' )?.addEventListener( 'click', ui.close );
		document.querySelector( '#wlp-live-preview-apply' )?.addEventListener( 'click', ui.apply );
		document.querySelector( '#wlp-live-preview-overlay' )?.addEventListener( 'click', ( event ) => {
			if ( event?.target.id === 'wlp-live-preview-overlay' ) {
				ui.close();
			}
		} );

		document.addEventListener( 'wlp:object:dropFailed', ( event ) => {
			const { target } = event.detail;
			flashMaskHighlight( target )
				.then( () => {
					draggedObject = null;
				} );
		} );

		// document.addEventListener( 'wlp:object:added', ( event ) => {
		// 	const { mask, object } = event.detail;
		// 	const canvas = ui.canvas();
		// 	state.addToObjectMap( mask.id, object );
		// 	canvas.bringObjectToFront( object );
		// 	ui.redraw();
		// } );

		document.querySelector( '#wlp-live-preview-show-masks' )?.addEventListener( 'change', ( event ) => {
			ui.set( { showMasks: event.target.checked } );
			ui.redraw();
		} );

		document.addEventListener( 'click', ( event ) => {
			if ( ! ui.isOpen() ) {
				return;
			}

			const isClickInsideCanvasEditor = !! event?.target.closest( 'div.wlp-canvas-editor' );
			if ( ! isClickInsideCanvasEditor ) {
				ui.canvas().discardActiveObject();
				// ui.redraw();
			}
		});

		document.addEventListener( 'keydown', ( event ) => {
			if ( ui.isOpen() ) {
				if ( state.get( 'isEditingText' ) ) {

					return;
				}

				const key = event.key.toLowerCase();

				if ( key === 'escape' ) {
					ui.close();
				}

				const canvas = ui.canvas();

				if ( key === 'delete' || key === 'backspace' ) {
					state.set( { removingObject: true } );
					ui.removeFromCanvas( canvas?.getActiveObjects() );
					state.set( { removingObject: false } );
				}

				if ( [ 'arrowleft', 'arrowright', 'arrowup', 'arrowdown' ].includes( key ) ) {
					const objects = canvas.getActiveObjects();
					if ( objects.length === 0 ) {
						return;
					}

					if ( event.ctrlKey || event.metaKey ) {
						if ( event.shiftKey ) {
							if ( key === 'arrowup' ) {
								canvas.bringObjectToFront( ...objects );
							}
							if ( key === 'arrowdown' ) {
								canvas.sendObjectToBack( ...objects );
							}
						} else {
							if ( key === 'arrowup' ) {
								canvas.bringObjectForward( ...objects );
							}
							if ( key === 'arrowdown' ) {
								canvas.sendObjectBackwards( ...objects );
							}
						}

						canvas.getObjects( ...fabric.maskTypes ).forEach( ( mask ) => {
							canvas.sendObjectToBack( mask );
						});
					} else {
						const step = event.shiftKey ? 10 : 1;
						const stepSize = step * ui.displayRatio();

						objects.forEach( ( object ) => {
							if ( ! object ) {
								return;
							}

							switch ( key ) {
								case 'arrowleft':
									if ( ! object.lockMovementX ) {
										object.left -= stepSize;
									}
									break;
								case 'arrowright':
									if ( ! object.lockMovementX ) {
										object.left += stepSize;
									}
									break;
								case 'arrowup':
									if ( ! object.lockMovementY ) {
										object.top -= stepSize;
									}
									break;
								case 'arrowdown':
									if ( ! object.lockMovementY ) {
										object.top += stepSize;
									}
									break;
							}

							object.setCoords();
						} );
					}

					ui.redraw();
				}
			}
		} );

		$( document )
			.on( 'found_variation', 'form.cart.variations_form', onFoundVariation )
			.on( 'reset_data', 'form.cart.variations_form', onResetVariation );
	};

	const init = () => {
		if ( ui.modal() ) {
			return;
		}

		ui.setup();
		bindEvents();
	};

	init( settings );

	return {
		init,
		activeObjects,
		open: ui.open,
		close: ui.close,
		saveResult: ui.saveResult,
		toggleMControls: fabric.toggleMControls,
		addModule,
		getModule,
		onFoundVariation,
		onResetVariation,
		get: state.get,
		fabric,
		modules,
		ui,
		state,
		utils,
	};
};
