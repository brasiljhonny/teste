export default [
	{
		name: 'texts',
		type: 'textarea',
		fType: 'textbox',
		class: 'wpo-field-textarea',
		selector: 'textarea',
		event: 'focus',
		load: () => {
			return import(
				/*webpackChunkName: "texts"*/
				'./modules/texts'
			);
		} 
	},
	{
		name: 'texts',
		type: 'text',
		fType: 'i-text',
		class: 'wpo-field-text',
		selector: 'input[type="text"]',
		event: 'focus',
		load: () => {
			return import(
				/*webpackChunkName: "texts"*/
				'./modules/texts'
			);
		} 
	},
	{
		name: 'images',
		type: 'image',
		fType: 'image',
		class: 'wpo-field-file_upload',
		selector: '.wpo-file-dropzone.dropzone',
		event: 'dropzone:addedfile',
		load: () => {
			return import(
				/*webpackChunkName: "images"*/
				'./modules/images'
			);
		}
	},

	// add more module loaders here as needed
];

