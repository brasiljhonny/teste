import { nanoid } from 'nanoid';

const filters = {};

export const applyFilters = ( hook, value, ...args ) => {
	if ( ! filters[ hook ] || filters[ hook ].length === 0 ) {
		return value;
	}

	filters[ hook ].forEach( ( filter, index ) => {
		value = filter.callback( value, ...args );
	} );

	return value;
}

export const addFilter = ( hook, callback ) => {
	if ( ! filters[ hook ] ) {
		filters[ hook ] = [];
	}

	filters[ hook ].push( { callback } );
};

export const debug = ( ...message ) => {
	if ( wlpSettings?.debug ) {
		// eslint-disable-next-line no-console
		console.trace( ...message );
	}
};

export const warn = ( ...message ) => {
	// eslint-disable-next-line no-console
	console.warn( ...message );
};

export const $ = () => {
	return window.jQuery || window.$;
}

export const dispatchEvent = ( eventName, detail ) => {
	document.dispatchEvent( new CustomEvent( eventName, { detail } ) );
};

export const uid = () => {
	return nanoid();
}

export const floatPrecision = ( number, precision = 2 ) => {
	const factor = Math.pow( 10, precision );
	return Math.round( number * factor ) / factor;
};

export const getStringHash = ( str, seed = 0 ) => {
	let h1 = 0xdeadbeef ^ seed,
		h2 = 0x41c6ce57 ^ seed;
	for ( let i = 0, ch; i < str.length; i++ ) {
		ch = str.charCodeAt( i );
		h1 = Math.imul( h1 ^ ch, 2654435761 );
		h2 = Math.imul( h2 ^ ch, 1597334677 );
	}
	h1 = Math.imul( h1 ^ ( h1 >>> 16 ), 2246822507 );
	h1 ^= Math.imul( h2 ^ ( h2 >>> 13 ), 3266489909 );
	h2 = Math.imul( h2 ^ ( h2 >>> 16 ), 2246822507 );
	h2 ^= Math.imul( h1 ^ ( h1 >>> 13 ), 3266489909 );

	return 4294967296 * ( 2097151 & h2 ) + ( h1 >>> 0 );
};

export const isCoarsePointer = () => window.matchMedia("(pointer: coarse)").matches;

export const isIOS = () => {
    const uaData = navigator?.userAgentData;
    
    // Use User-Agent Client Hints if available
    if (uaData && uaData?.platform) {
        return uaData?.platform === 'iOS';
    }

    // Fallback to User-Agent sniffing
    const ua = navigator?.userAgent || '';
    const isAppleDevice = /iPhone|iPad|iPod/.test(ua);

    // Detect iPads running iPadOS (which now spoof as Mac)
    const isModerniPad = navigator?.maxTouchPoints > 1 && /Macintosh/.test(ua);

    return isAppleDevice || isModerniPad;
};


export const bindDoubleTap = (element, callback, options = {}) => {
	const delay = options.delay || 300; // ms between taps
	const moveThreshold = options.moveThreshold || 10; // px

	let lastTapTime = 0;
	let lastTapX = null;
	let lastTapY = null;

	const getTouchPosition = (e) => {
		const t = e.changedTouches?.[0] || e;
		return { x: t.clientX, y: t.clientY };
	};

	const handler = (e) => {
		const now = Date.now();
		const { x, y } = getTouchPosition(e);

		if (now - lastTapTime < delay) {
			const dx = Math.abs(x - lastTapX);
			const dy = Math.abs(y - lastTapY);

			if (dx < moveThreshold && dy < moveThreshold) {
				callback(e);
				lastTapTime = 0; // reset
				return;
			}
		}

		lastTapTime = now;
		lastTapX = x;
		lastTapY = y;
	};

	if ('ontouchend' in window) {
		element.addEventListener('touchend', handler);
	} else {
		element.addEventListener('pointerup', (e) => {
			if (e.pointerType === 'touch') handler(e);
		});
	}
}

