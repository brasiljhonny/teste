export default ( core ) => {
	const { state, ui, fabric, utils } = core;

	let objects = [];
	let imageQueue = [];

	const exportableTypes = [ 'image' ];

	ui.canvas().on("object:modified", (event) => {
		const object = event.target;

		if ( ! exportableTypes.includes( object.type ) ) {
			return;
		}

		// processing unique to image objects
	});

	ui.canvas().on("object:scaling", (event) => {
		const object = event.target;
		if ( ! exportableTypes.includes( object.type ) ) {
			return;
		}

		// if ( object.filters?.length ) {
		// 	const resizeFilter = object.filters[ 0 ];
		// 	resizeFilter.scaleX = object.scaleX;
		// 	resizeFilter.scaleY = object.scaleY;
		// 	object.applyResizeFilters();
		// }
		// object.setCoords();
		// ui.redraw();
	});

	const setupObjects = () => {
		document.querySelectorAll( '.wpo-file-dropzone.dropzone' ).forEach( ( element ) => {
			const field = element.closest( '.wpo-field-file_upload' );
			const optionId = parseInt( field?.dataset?.optionId ) || 0;

			element.addEventListener( 'dropzone:queuecomplete', () => {
				ui.set( { optionId } );
				addUploadedFiles( element.dropzone.files, optionId );
				const customizeButtonText = field?.dataset?.livePreviewButtonText || wlpSettings.options?.live_preview_button_text;
				if ( objects?.length > 0 ) {
					ui.removeTypesFromCanvas( ...fabric.exportableTypes() );

					let button = element
						.closest( '.wpo-field-file_upload' )
						?.querySelector( 'a.wlp-customize-preview' );

					if ( ! button ) {
						button = document.createElement( 'a' );
						button.classList.add( 'wlp-customize-preview' );
						button.innerText = customizeButtonText;
						element.closest( '.wpo-field-file_upload' )?.querySelector( 'label' )?.append( button );
						button.addEventListener( 'click', ( event ) => {
							event.preventDefault();
							ui.set( { optionId } );
							ui.open();
						} );
					}

					let masks = ui.canvas().getObjects( fabric.maskTypes );
					if ( masks.length === 0 ) {
						masks = ui.imageMasks();
						ui.add( ...masks );
					}

					// if (
					// 	masks.length === 1 &&
					// 	objects.length === 1 &&
					// 	state.fromObjectMap( masks[ 0 ]?.id ).length === 0
					// ) {
					// 	addToCanvas( objects[ 0 ], masks[ 0 ] ).then( () => {
					// 		const options = ui.optionsFromMask( masks[ 0 ] );
					// 		if ( options.no_move && options.no_rotate && options.no_scale && options.single_image ) {
					// 			ui.saveResult();
					// 			return;
					// 		}
					// 	} );
					// }
				}

				document.querySelectorAll( '.dz-preview img' ).forEach( ( element ) => {
					// remove every event listeners from the element
					const field = element.closest( '.wpo-field-file_upload' );
					const optionId = parseInt( field?.dataset?.optionId ) || 0;
		
					if ( ! ui.isOptionPreviewable( optionId ) ) {
						return;
					}
		
					const clone = element.cloneNode( true );
					clone.addEventListener( 'click', (event) => {
						ui.set( { optionId } );
						const productImageIndex = ui.productImages( true ).indexOf( ui.productImages()[0] );
						ui.set( { productImageIndex } );
						ui.updateCatalog();
						ui.open();
					} );
					element.replaceWith( clone );
				} );

				const filledInFields = Array.from( new Set( [ ...( ui.get( 'filledInFields' ) || [] ), optionId ] ) );
				ui.set( { filledInFields } );
					
				if ( filledInFields.length === ui.previewFields().length ) {
					ui.open();
				}
			} );
			element.addEventListener( 'dropzone:removedfile', ( event, file ) => {
				if ( ! ui.isOptionPreviewable( optionId ) ) {
					return;
				}

				const files = event.detail.args;
				const fileIds = files.map( ( file ) => file.upload.uuid );
				if ( fileIds.length === 0 ) {
					const filledInFields = ( ui.get( 'filledInFields' ) || [] ).filter( ( id ) => id !== optionId );
					ui.set( { filledInFields } );
				}

				removeUploadedFiles( fileIds );

				if ( ! hasUploadedFiles() ) {
					// restore the original product image
					ui.resetImage( ui.productImage() );
					ui.slideToImage(0);
				}
			} );
		} );
	}

	const bindEvents = () => {
		document.addEventListener( 'wlp:object:dropping', ( event ) => {
			const { object, destination } = event.detail;

			if ( ! exportableTypes.includes( object.type ) ) {
				return;
			}

			addToCanvas( object, destination )
				.then( () => {
					// ui.redraw();
				} )
				.catch( ( error ) => {
					utils.debug( error );
				} );
		} );
	};

	const removeUploadedFiles = ( ids ) => {
		objects = objects.filter( ( file ) => ! ids.includes( file.id ) );
		const imageObjects = ui.canvas().getObjects( 'image' ).filter( ( image ) => ids.includes( image.id ) );
		imageObjects.forEach( ( image ) => {
			ui.canvas().remove( image );
			state.removeFromObjectMap( image );
			utils.dispatchEvent( 'wlp:image:removed', { image } );
		} );

		ui.updateCatalog();
	};

	const addUploadedFiles = ( files, optionId ) => {
		files = files
			.map( ( file ) => {
				const fileData = file?.xhr?.response ? JSON.parse( file.xhr.response ) : null;
				return {
					id: file?.upload?.uuid,
					url: fileData?.url ?? '',
					size: file?.size ?? 0,
					type: 'image',
					optionId,
				};
			} )
			.filter( ( file ) => file.id && file.url && ! objects.map( ( f ) => f.id ).includes( file.id ) );

		objects = [ ...objects, ...files ];
		ui.updateCatalog();
	};

	const hasUploadedFiles = () => {
		return objects.length > 0;
	};

	const hasImageDuplicates = ( image ) => {
		const currentImageObjects = ui.canvas().getObjects( 'image' ).filter( ( i ) => i.id === image.id );
		if ( currentImageObjects.length > 0 ) {
			// images with the same ID are already part of the canvas
			// we need to check whether they have the same position, dimensions, scale, and angle.
			// If at least one of the current images is identical to the one we are adding,
			// we don't need to add it again

			return currentImageObjects.some( ( currentImage ) => {
				return (
					currentImage.left === image.left &&
					currentImage.top === image.top &&
					currentImage.width === image.width &&
					currentImage.height === image.height &&
					currentImage.angle === image.angle &&
					currentImage.scaleX === image.scaleX &&
					currentImage.scaleY === image.scaleY
				);
			} );
		}

		return false;
	};

	const maskIncludesImage = ( mask, image ) => {
		return state.fromObjectMap( mask.id ).map( i => i.id ).includes( image.id );
	};

	const enqueueImage = ( image, mask = null ) => {
		mask = mask ?? ui.activeMask();
		mask = mask.id;
		imageQueue.push( { image, mask } );
	};

	const dequeueImage = ( image, mask = null ) => {
		mask = mask ?? ui.activeMask();
		imageQueue = imageQueue.filter( ( item ) => item.image !== image && item.mask !== mask.id );
	};

	const isImageEnqueued = ( image, mask ) => {
		mask = mask ?? ui.activeMask();
		return imageQueue.some( ( item ) => item.image === image && item.mask === mask.id );
	};

	const createImageFromURL = ( url, props = {} ) => {
		return new Promise( ( resolve, reject ) => {
			const tempImage = new Image();
			tempImage.onload = () => {
				if ( ! tempImage.width || ! tempImage.height ) {
					reject( 'Image has no dimensions' );
					return;
				}
	
				const img = new fabric.classes.FabricImage( tempImage, {
						...fabric.defaultObjectProps( ui.displayRatio()),
						...props,
				} );
	
				resolve( img );
			};
			tempImage.src = url;
		} );
	}

	const formatCatalogItem = ( item, object ) => {
		if ( ! object.url ) {
			return;
		}

		item.removeAttribute( 'hidden' );

		const fileName = object.url.split( '/' ).pop();

		const image = item.querySelector( 'img' );
		image.src = object.url;
		image.title = fileName;
		image.alt = fileName;

		const fieldFile = item.querySelector( '.wlp-catalog-item-file' );
		fieldFile.textContent = fileName;
		fieldFile.title = fileName;

		const fieldSize = item.querySelector( '.wlp-catalog-item-size' );
		fieldSize.textContent = object.size ? `${ utils.floatPrecision( object.size / 1024, 2 ) } kB` : '';

		return item;
	};

	const fitToMask = ( mask, image ) => {
		const canvas = ui.canvas();
		const options = ui.optionsFromMask( mask );
		const boundingRect = mask.getBoundingRect( true );
		const default_image_sizing = wlpSettings.options?.default_image_sizing ?? 'contain';
		const scaleMethod = image.sizingMethod ?? default_image_sizing;
		const minMax = scaleMethod === 'contain' ? 'min' : 'max';

		let left = 0;
		let top = 0;
		let width = canvas.width;
		let height = canvas.height;
		let scale = Math[ minMax ]( width / image.getOriginalSize().width / 4, height / image.getOriginalSize().height / 4 );

		left = boundingRect.left;
		top = boundingRect.top;
		width = boundingRect.width;
		height = boundingRect.height;
		scale = Math[ minMax ](
			mask.width * mask.scaleX / image.getOriginalSize().width,
			mask.height * mask.scaleY / image.getOriginalSize().height
		);

		image.set( {
			...fabric.defaultObjectProps( ui.displayRatio() ),
			left: boundingRect.left + boundingRect.width / 2,
			top: boundingRect.top + boundingRect.height / 2,
			scaleX: scale,
			scaleY: scale,
			angle: mask.angle,
			lockMovementX: options?.no_move ?? false,
			lockMovementY: options?.no_move ?? false,
			lockScalingX: options?.no_resize ?? false,
			lockScalingY: options?.no_resize ?? false,
			lockRotation: options?.no_rotate ?? false,
		} );
		image.setControlsVisibility( {
			mtr: ! ( options?.no_rotate ?? false ),
			tl: ! ( options?.no_resize ?? false ),
			tr: ! ( options?.no_resize ?? false ),
			bl: ! ( options?.no_resize ?? false ),
			br: ! ( options?.no_resize ?? false ),
			mt: ! ( options?.no_resize ?? false ),
			ml: ! ( options?.no_resize ?? false ),
			mr: ! ( options?.no_resize ?? false ),
			mb: ! ( options?.no_resize ?? false ),
		} );
		utils.dispatchEvent( 'wlp:image:resized', { image } );
	};

	const addToCanvas = ( image, destination = null ) => {
		return new Promise( ( resolve ) => {
			const mask = destination || ui.activeMask( image.optionId );

			if ( ! mask ) {
				resolve( false );
				return;
			}

			const options = ui.optionsFromMask( mask );

			if ( ! ui.canAddObjectToMask( mask, image ) ) {
				// the image is not assigned to the current mask
				ui.flashMaskHighlight( mask )
					.then( () => {
						resolve( false );
					} );
				return;
			}

			if ( image instanceof fabric.classes.FabricImage ) {
				if ( hasImageDuplicates( image ) ) {
					resolve();
					return;
				}

				if ( ! maskIncludesImage( mask, image ) ) {
					// if the image is not part of the mask, we initialize its position, scale, etc.
					fitToMask( mask, image );
				}

				ui.add( image );
				utils.dispatchEvent( 'wlp:image:added', { image } );
				state.addToObjectMap( mask.id, image );
				ui.canvas().bringObjectToFront( image );
				ui.redraw();
				resolve();
				return;
			}

			const fileId = image?.id ?? uid();
			const fileOptionId = parseInt( image?.optionId ?? '0' );
			const fileUrl = image?.url ?? '';

			if ( ! fileUrl ) {
				// we tried everything we could, no image source was provided
				resolve( false );
				return;
			}

			if ( isImageEnqueued( fileUrl, mask ) ) {
				resolve();
				return;
			}

			enqueueImage( fileUrl, mask );

			createImageFromURL( fileUrl ).then( ( img ) => {
				const maskImages = state.fromObjectMap( mask.id );
				if ( maskImages.length > 0 && options.single_image ) {
					ui.removeFromCanvas( maskImages );
					state.toObjectMap( mask.id, [] );
				}
				state.addToObjectMap( mask.id, img );

				img.set( {
					...fabric.defaultObjectProps( ui.displayRatio() ),
					id: fileId,
					parentId: mask.id,
					optionId: fileOptionId,
					originX: 'center',
					originY: 'center',
					transparentCorners: false,
					selectable: true,
					element: img.getElement(),
					sizingMethod: options?.default_image_sizing ?? 'contain',
					clipPath: fabric.clipPath( mask ),
				} );
				img.controls.mtr.offsetY = -40 * ui.displayRatio();

				fitToMask( mask, img );

				img.on( 'changed', () => {
					state.replaceInObjectMap( mask.id, img );
				})

				img.on( 'removed', ( event ) => {
					if ( state.get( 'removingObject' ) ) {
						state.removeFromObjectMap( img );
					}
					utils.dispatchEvent( 'wlp:image:removed', { image: img } );
				} );

				img.on( 'mousedblclick', ( event ) => {
					if ( event.target !== img ) {
						return
					}

					img.sizingMethod = img.sizingMethod === 'contain' ? 'cover' : 'contain';
					fitToMask( mask, img );
					ui.canvas().discardActiveObject();
					ui.canvas().setActiveObject( img );
					ui.redraw();
				} );

				const resizeFilter = new fabric.classes.filters.Resize( {
					resizeType: 'sliceHack',
					scaleX: 1,
					scaleY: 1,
				} );

				img.filters.push( resizeFilter );
				img.applyResizeFilters();

				img.controls.deleteControl = fabric.deleteControl({
					mouseUpHandler: ( _eventData, transform ) => {
						ui.canvas().remove( transform.target );
						state.removeFromObjectMap( transform.target );
						ui.redraw();
					}
				});

				if ( ! hasImageDuplicates( img ) ) {
					ui.add( img );
					utils.dispatchEvent( 'wlp:image:added', { image: img } );
					ui.canvas().bringObjectToFront( img );
					ui.canvas().setActiveObject( img );
				}

				dequeueImage( fileUrl, mask );
				ui.redraw();
				resolve();
			} );
		} );
	};

	/**
	 * Get all image objects
	 *
	 * @param {boolean} validOnly If true, only returns objects with a valid URL
	 * @returns {Array} Array of image objects
	 */
	const getObjects = ( validOnly = false ) => {
		if ( validOnly ) {
			return objects.filter( ( object ) => object?.url.length > 0 );
		}

		return objects;
	};

	const getObjectsByOption = ( optionId, validOnly = false ) => {
		return getObjects( validOnly ).filter( ( object ) => object.optionId === parseInt( optionId ) );
	};

	const init = () => {
		utils.addFilter( 'wlpInitialObjects', ( objects, mask ) => {
			getObjects().forEach( ( image, index ) => {
				const optionMasks = ui.optionMasks( image.optionId );
				if ( image.url.length > 0 && optionMasks.length === 1 && optionMasks[ 0 ].id === mask.id ) {
					objects.push( image );
				}
			} );

			return objects;
		});

		utils.addFilter( 'wlpExportableTypes', ( types ) => {
			return [ ...types, ...exportableTypes ];
		} );

		setupObjects();
		bindEvents();
	};

	return {
		init,
		getObjects,
		getObjectsByOption,
		addToCanvas,
		formatCatalogItem,
	}
}
