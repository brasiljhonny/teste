/**
 * Internal dependencies
 */
import TextToolbar from './toolbar';

export default ( core ) => {
	const { state, ui, fabric, utils } = core;
	const toolbar = TextToolbar( { state, ui, fabric, utils } );

	const textObjects = {};
	let objects = [];

	let selectedText = null;

	const exportableTypes = [ 'i-text', 'textbox' ];

	/**
	 * When the font properties of the selected text change,
	 * update the hidden input field attached to the text object
	 */
	const updateTextProperties = ( properties = {} ) => {
		const textField = document.querySelector( `.wpo-field[data-option-id="${selectedText?.optionId}"]` );

		if ( ! textField ) {
			return;
		}

		const textProperties = {
			fontFamily: selectedText.fontFamily,
			color: selectedText.fill,
			underline: selectedText.underline,
			fontWeight: selectedText.fontWeight,
			fontStyle: selectedText.fontStyle,
			textAlign: selectedText.textAlign,
			...properties,
		}

		const form = textField.closest( 'form.cart' );

		if ( form ) {
			let textPropertyInput = form.querySelector( `input[name="wlp-text-preview[${selectedText.optionId}]"]` );

			if ( ! textPropertyInput ) {
				textPropertyInput = document.createElement( 'input' );
				textPropertyInput.type = 'hidden';
				textPropertyInput.name = `wlp-text-preview[${selectedText.optionId}]`;
				form.append( textPropertyInput );
			}

			textPropertyInput.value = JSON.stringify( textProperties );
		}
	}

	const bindEvents = () => {
		document.addEventListener( 'keyup', onTextEditing );

		document.addEventListener( 'wlp:object:dropping', ( event ) => {
			const { object, target, destination } = event.detail;

			if ( target !== destination && exportableTypes.includes( target?.type ) ) {
				// if we drop a text object from the catalog into a text fabric object,
				// the stringified version of the object is replaced to the text of the original target
				// so that the text is updated with the wrong text
				// Therefore, we need to update the text of the original target
				target._clearCache();
				target.set( 'text', target.text.replace( JSON.stringify( object ), '' ) );
				target.initDimensions();
				target.setCoords();
				ui.redraw();
			}

			if ( ! [ 'text', 'textarea' ].includes( object.type ) ) {
				return;
			}

			addToCanvas( object, destination )
				.then( () => {
					ui.redraw();
				} )
				.catch( ( error ) => {
					utils.debug( 'error', error );
				} );
		} );

		ui.canvas().on( 'object:added', (event) => {
			// processing that is unique to text objects
			const object = event.target;
			// if the printable area the object is added to contains a text object,
			// remove the previous text object
			const mask = ui.canvas().getObjects( ...fabric.maskTypes ).find( ( m ) => m.id === object.parentId );

			if ( ! mask ) {
				return;
			}

			const previousTextObjects = state.fromObjectMap( mask.id ).filter( ( i ) => exportableTypes.includes( i.type ) );
			previousTextObjects.forEach( ( previousTextObject ) => {
				if ( previousTextObject.id === object.id ) {
					// if the previous text object is the same as the newly added one, skip it
					return;
				}
				ui.removeFromCanvas( [ previousTextObject ] );
				state.removeFromObjectMap( previousTextObject );
			} );
		} );

		ui.canvas().on( 'object:modified', (event) => {
			// processing that is unique to text objects
			const object = event.target;

			if ( ! exportableTypes.includes( object.type ) ) {
				return;
			}

			toolbar.updateToolbar();
		});

		ui.canvas().on( 'object:scaling', (event) => {
			// processing that is unique to text objects

			const object = event.target;
			if ( ! exportableTypes.includes( object.type ) ) {
				return;
			}

			object._clearCache();

			if ( object?.type === 'i-text' ) {
				const factors = [object.scaleX, object.scaleY].filter((scale) => scale !== 1);

				if ( factors.length === 0 ) {
					factors.push(1);
				}
				const maxScale = Math.max(...factors);

				object.set(
					{
						width: object.width * object.scaleX,
						height: object.height * object.scaleY,
						fontSize: object.fontSize * maxScale,
						scaleX: 1,
						scaleY: 1,
						dirty: true,
					},
				);
			} else {
				object.set(
					{
						width: object.width * object.scaleX,
						height: object.height * object.scaleY,
						scaleX: 1,
						scaleY: 1,
						dirty: true,
					},
				);
			}
			object.setCoords();
			// ui.redraw();
		});

		toolbar.addEventListener( 'change', ( event ) => {
			const text = selectedText || event.detail?.selectedText;

			if ( ! text ) {
				return;
			}

			updateTextProperties();
			ui.redraw();
		} );
	};

	const init = () => {
		utils.addFilter( 'wlpInitialObjects', ( objects, mask ) => {
			getObjects().forEach( ( text ) => {
				const optionMasks = ui.optionMasks( text.optionId );
				if ( text.text.length > 0 && optionMasks.length === 1 && optionMasks[ 0 ].id === mask.id ) {
					objects.push( text );
				}
			} );

			return objects;
		});

		utils.addFilter( 'wlpExportableTypes', ( types ) => {
			return [ ...types, ...exportableTypes ];
		} );

		setupObjects();
		toolbar.init();
		bindEvents();
	};

	const defaultOptions = () => {
		return {
			originX: 'center',
			originY: 'center',
			transparentCorners: false,
			selectable: true,
			paintFirst: 'stroke',
		};
	};

	const createText = ( text, type = 'text', props = {} ) => {
		const defaultProps = {
			id: props.id || utils.uid(),
			text,
			fontSize: 20 * ui.displayRatio(),
			fill: '#000',
			stroke: '#fff',
			strokeWidth: 0,
			fontFamily: 'Arial',
			textAlign: 'left',
			objectCaching: false,
		};

		const textClass = type === 'textarea' ? fabric.classes.Textbox : fabric.classes.IText;
		textClass.prototype.objectCaching = false;
	
		return new textClass( text, { ...defaultProps, ...props } );
	}

	const addText = ( text, options ) => {
		return addTextObject( text, 'text', options );
	};

	const addParagraph = ( text, options ) => {
		return addTextObject( text, 'textarea', options );
	};

	const addTextObject = ( text, type = 'text', options = {} ) => {
		options = {
			...defaultOptions(),
			...options
		};

		const textObject = createText( text, type, options );

		textObject.canDrop = () => false;
		textObject.controls.deleteControl = fabric.deleteControl({
			mouseUpHandler: ( _eventData, transform ) => {
				ui.canvas().remove( transform.target );
				state.removeFromObjectMap( transform.target );
				ui.redraw();
			}
		});

		// Show toolbar when text is selected
		textObject.on( 'selected', (event) => {
			selectedText = textObject;
			toolbar.setSelectedText( selectedText );
			updateTextProperties();
		});

		// Hide toolbar when text is deselected
		textObject.on( 'deselected', () => {
			selectedText = null;
			toolbar.setSelectedText( selectedText );
		});

		textObject.on("editing:entered", () => {
			state.set( { isEditingText: true } );
		} );

		textObject.on("editing:exited", () => {
			onTextEditing();
			ui.redraw();
			state.set( { isEditingText: false } );
		});

		if ( ! textObjects[ textObject.optionId ] ) {
			textObjects[ textObject.optionId ] = [];
		}

		textObjects[ textObject.optionId ].push( textObject );
		textObject._clearCache();
		textObject.set( 'fontFamily', toolbar.getDefaultFont() );
		textObject.setCoords();

		return textObject;
	};

	const onTextEditing = ( event ) => {
		if ( ! state.get( 'isEditingText' ) ) {
			// Text editing is not active
			return;
		}

		if ( event && event.target.closest( '.wlp-catalog-item' ) ) {
			// We are editing the text in the catalog item
			return;
		}

		const textField = document.querySelector( `.wpo-field[data-option-id="${selectedText.optionId}"]` );
		const textInput = textField?.querySelector( 'input[type="text"], textarea' );

		if ( ! textInput ) {
			return;
		}

		textInput.value = selectedText.text;

		textObjects[ selectedText.optionId ]?.forEach( tO => {
			tO._clearCache();
			tO.set(
				{
					text: textInput.value,
					dirty: true,
				}
			);
			tO.setCoords();
		} );

		const catalogItem = ui.catalog().querySelector( `li.wlp-catalog-item[data-option-id="${selectedText.optionId}"]` );

		if ( catalogItem ) {
			catalogItem.dataset.text = textInput.value;
			catalogItem.querySelector( '.wlp-catalog-item-text' ).value = textInput.value;
		}
	}

	const formatCatalogItem = ( item, object ) => {
		if ( ! object.text ) {
			return;
		}

		item.removeAttribute( 'hidden' );

		const field = document.querySelector( `.wpo-field[data-option-id="${ object.optionId }"]` );
		const itemText = item.querySelector( '.wlp-catalog-item-text' );
		itemText.value = object.text;
		itemText.title = object.text;
		itemText.addEventListener( 'focus', ( event ) => {
			state.set( { isEditingText: true } );
		} );
		itemText.addEventListener( 'blur', ( event ) => {
			state.set( { isEditingText: false } );
		} );
		itemText.addEventListener( 'input', ( event ) => {
			const value = event.target.value;
			const selector = object.type === 'textarea' ? 'textarea' : 'input';
			field.querySelector( selector ).value = value;
			item.dataset.text = value;
			updateText( value, object.optionId );
		} );

		return item;
	}

	const updateText = ( text, optionId ) => {
		if ( textObjects[ optionId ]?.length === 0 ) {
			return;
		}

		const optionTexts = textObjects[ optionId ] ?? [];

		if ( text?.length > 0 ) {
			optionTexts?.forEach( textObject => {
				textObject._clearCache();
				textObject.set(
					{
						text: text,
						dirty: true,
					}
				);
				textObject.setCoords();
			} );
		} else {
			ui.removeFromCanvas(optionTexts);
			delete textObjects[ optionId ];
		}
		ui.redraw();
	};

	const setupObjects = () => {
		document.querySelectorAll( '.wpo-field-text, .wpo-field-textarea' ).forEach( ( field ) => {
			if ( ! field.dataset.livePreviewButtonText ) {
				return;
			}

			const optionId = parseInt( field.dataset.optionId );
			const input = field.querySelector( 'input[type="text"], textarea' );
			const text = input?.value ?? '';
			const type = field.classList.contains( 'wpo-field-text' ) ? 'text' : 'textarea';

			objects.push( { optionId, text, type } );

			input.addEventListener( 'input', ( event ) => {
				objects.find( ( ( text ) => text.optionId === optionId ) ).text = event.target.value;
				const catalogItem = ui.catalog().querySelector( `li.wlp-catalog-item[data-option-id="${ optionId }"]` );
				if ( catalogItem ) {
					catalogItem.dataset.text = event.target.value;
					catalogItem.querySelector( 'input' ).value = event.target.value;
				}
			} );

			input.addEventListener( 'blur', ( event ) => {
				const newText = event?.target?.value;
				const filledInFields = Array.from( new Set( [ ...( ui.get( 'filledInFields' ) || [] ), optionId ] ) );
				ui.set( { filledInFields } );

				ui.updateCatalog();

				if ( filledInFields.length === ui.previewFields().length ) {
					ui.open();
				}

				if ( newText?.length > 0 ) {
					updateText( newText, optionId );

					const customizeButtonText = field?.dataset?.livePreviewButtonText || wlpSettings?.options?.live_preview_button_text;
					let button = field?.querySelector( 'a.wlp-customize-preview' );

					if ( ! button ) {
						button = document.createElement( 'a' );
						button.classList.add( 'wlp-customize-preview' );
						button.innerText = customizeButtonText;
						field?.querySelector( 'label' )?.append( button );
						button.addEventListener( 'click', ( event ) => {
							event.preventDefault();
							ui.set( { optionId } );
							ui.open();
						} );
					}
					
					const listItem = document.querySelector( `.wlp-catalog-item[data-option-id="${optionId}"]` );
					if ( ! listItem ) {
						ui.updateCatalog();
						return;
					}
					listItem.dataset.text = newText;
					listItem.querySelector( '.wlp-catalog-item-text' ).value = newText;

					textObjects[ optionId ]?.forEach( textObject => {
						textObject._clearCache();
						textObject.set(
							{
								text: newText,
								dirty: true,
							}
						)
						textObject.setCoords();
					} );
					ui.redraw();
				} else {
					ui.set( { filledInFields: filledInFields.filter( ( id ) => id !== optionId ) } );
				}
			} );
		} );
	};

	const maskIncludesText = ( mask, text ) => {
		return state.fromObjectMap( mask.id ).map( i => i.id ).includes( text.id );
	};

	const fitToMask = ( mask, text ) => {
		if ( text.type === 'textbox' ) {
			return;
		}
				
		const canvas = ui.canvas();
		const options = ui.optionsFromMask( mask );
		const boundingRect = mask.getBoundingRect( true );
		const default_sizing = wlpSettings.options?.default_image_sizing ?? 'contain';
		const scaleMethod = text.sizingMethod ?? default_sizing;
		const minMax = scaleMethod === 'contain' ? 'min' : 'max';
		text.set( {
			fontSize: 24,
			dirty: true,
		} );
		text._clearCache();
		const textWidth = text.calcTextWidth();
		const textHeight = text.calcTextHeight();

		let left = 0;
		let top = 0;
		let width = canvas.width;
		let height = canvas.height;
		let scale = Math[ minMax ]( width / textWidth / 4, height / textHeight / 4 );

		if ( mask ) {
			const boundingRect = mask.getBoundingRect( true );
			left = boundingRect.left;
			top = boundingRect.top;
			width = boundingRect.width;
			height = boundingRect.height;
			scale = Math[ minMax ](
				mask.width * mask.scaleX / textWidth,
				mask.height * mask.scaleY / textHeight
			);
		}

		text.set( {
			fontSize: 24 * scale,
			dirty: true,
		} );
		text._clearCache();

		const textProps = {
			...fabric.defaultObjectProps( ui.displayRatio() ),
			left: boundingRect.left + boundingRect.width / 2,
			top: boundingRect.top + boundingRect.height / 2,
			scaleX: 1,
			scaleY: 1,
			angle: mask.angle,
		};

		text.set( textProps );
		text.setCoords();
	};

	const addToCanvas = ( text, destination ) => {
		return new Promise( ( resolve ) => {
			const mask = destination || ui.activeMask( text.optionId );

			if ( ! mask ) {
				resolve( false );
				return;
			}

			// if the text is already a fabric object, we can add it directly to the canvas
			if ( exportableTypes.includes( text?.type ) ) {
				if ( ! maskIncludesText( mask, text ) ) {
					// if the text is not part of the mask, we initialize its position, scale, etc.
					fitToMask( mask, text );
				}

				ui.removeFromCanvas( text );
				ui.add( text );
				state.removeFromObjectMap( text );
				state.addToObjectMap( mask.id, text );
				utils.dispatchEvent( 'wlp:object:added', { mask, object: text } );
				ui.canvas().bringObjectToFront( text );
				resolve();
				return;
			}

			if ( ! ui.canAddObjectToMask( mask, text ) ) {
				// the text is not assigned to the current mask
				ui.flashMaskHighlight( mask )
					.then( () => {
						resolve( false );
					} );
				return;
			}

			const textId = text?.optionId ?? '0';
			const textValue = text?.text ?? '';
			const textType = text?.type ?? 'text';
			const options = ui.optionsFromMask( mask );

			const textProps = {
				...fabric.defaultObjectProps( ui.displayRatio() ),
				id: utils.uid(),
				parentId: mask.id,
				optionId: textId,
				fill: '#000',
				sizingMethod: wlpSettings?.options?.default_image_sizing ?? 'contain',
				clipPath: fabric.clipPath( mask ),
				lockMovementX: options?.no_move ?? false,
				lockMovementY: options?.no_move ?? false,
				lockScalingX: options?.no_resize ?? false,
				lockScalingY: options?.no_resize ?? false,
				lockRotation: options?.no_rotate ?? false,
			};

			if ( textType === 'textarea' ) {
				const boundingRect = mask.getBoundingRect( true );
				Object.assign( textProps, {
					originX: 'left',
					originY: 'top',
					width: boundingRect.width,
					height: boundingRect.height,
					top: boundingRect.top,
					left: boundingRect.left,
					fontSize: 24 * ui.displayRatio(),
					textAlign: 'left',
					editable: true,
				} );
			}

			const textObject = addTextObject(
				textValue,
				textType,
				textProps
			);

			textObject.setControlsVisibility( {
				mtr: ! ( options?.no_rotate ?? false ),
				tl: ! ( options?.no_resize ?? false ),
				tr: ! ( options?.no_resize ?? false ),
				bl: ! ( options?.no_resize ?? false ),
				br: ! ( options?.no_resize ?? false ),
				mt: ! ( options?.no_resize ?? false ),
				ml: ! ( options?.no_resize ?? false ),
				mr: ! ( options?.no_resize ?? false ),
				mb: ! ( options?.no_resize ?? false ),
			} );

			if ( textType === 'textarea' ) {
				textObject.setControlsVisibility( {
					tl: false,
					tr: false,
					bl: false,
					br: false,
					mb: false,
					mt: false,
					ml: false,
				} );
			}

			textObject.controls.mtr.offsetY = -40 * ui.displayRatio();

			// there can only be a single text object per printable area,
			// so we remove the previous one if it exists
			const previousTextObjects = state.fromObjectMap( mask.id ).filter( ( i ) => fabric.exportableTypes().includes( i.type ) );

			previousTextObjects.forEach( ( t ) => {
				ui.removeFromCanvas( [ t ] );
				state.removeFromObjectMap( t );
			} );
			ui.add( textObject );
			state.addToObjectMap( mask.id, textObject );

			fitToMask( mask, textObject );

			textObject.on( 'removed', ( event ) => {
				if ( state.get( 'removingObject' ) ) {
					state.removeFromObjectMap( textObject );
				}
				
				const catalogItem = ui.catalog().querySelector( `li.wlp-catalog-item[data-option-id="${ textObject.optionId }"]` )
				if ( catalogItem ) {
					catalogItem.disabled = false;
				}
				utils.dispatchEvent( 'wlp:text:removed', { text: textObject } );
			});

			textObject.on( 'mousedblclick', ( event ) => {
				if ( event.target !== textObject || state.get( 'isEditingText' ) ) {
					return;
				}

				textObject.sizingMethod = textObject.sizingMethod === 'contain' ? 'cover' : 'contain';
				fitToMask( mask, textObject );
				ui.canvas().discardActiveObject();
				ui.canvas().setActiveObject( textObject );
				ui.redraw();
			} );

			textObject.on( 'changed', () => {
				if ( textObject.type === 'textbox' ) {
					textObject.set( {
						width: mask.width,
						height: mask.height,
					} );
					textObject.initDimensions();
					textObject.setCoords();
					textObject._clearCache();
					textObject.dirty = true;
					ui.redraw();
				}
				state.replaceInObjectMap( mask.id, textObject );
			});

			textObject.on( 'modified', () => {
				state.replaceInObjectMap( mask.id, textObject );
			});

			textObject.on( 'fontFamily:changed', () => {
				fitToMask( mask, textObject );
				state.replaceInObjectMap( mask.id, textObject );
				ui.redraw();
			});

			ui.canvas().setActiveObject( textObject );

			ui.redraw();
			resolve();
		} );
	};

	/**
	 * Returns all text objects
	 *
	 * @param {boolean} validOnly If true, only returns text objects with non-empty text
	 * @return {Array} Returns all text objects
	 */
	const getObjects = ( validOnly = false ) => {
		if ( validOnly ) {
			return objects.filter( ( object ) => object?.text.length > 0 );
		}

		return objects;
	};
	
	/**
	 * Return the object corresponding to the given option ID.
	 *
	 * NOTE: The text module return one object per option ID,
	 * but we still return an array to keep the same interface as other modules.
	 * @param {int|string} optionId
	 * @return {Array} Returns an array of text objects
	 */
	const getObjectsByOption = ( optionId, validOnly = false ) => {
		return getObjects( validOnly ).filter( ( object ) => object.optionId === parseInt( optionId ) );
	};

	return {
		init,
		addTextObject,
		addText,
		addParagraph,
		updateText,
		getObjects,
		getObjectsByOption,
		addToCanvas,
		formatCatalogItem,
	};
}
