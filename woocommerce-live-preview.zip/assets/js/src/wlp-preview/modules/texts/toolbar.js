/**
 * External dependencies
 */
import NiceSelect from 'nice-select2/dist/js/nice-select2.js';
/**
 * Internal dependencies
 */
import { loadFont, getFonts } from './fonts.js';

export default ( props ) => {
	const { ui, state, fabric } = props;
	let selectedText = null;
	let toolbar = null;
	let fontFamilySelect = null;
	let nsFontFamily = null;
	const allFonts = [];

	const init = () => {
		const template = document.querySelector( 'template#wlp-text-toolbar' );
		document.querySelector( 'div.wlp-canvas-editor' ).append( template.content.cloneNode( true ) );
		toolbar = document.querySelector( '#wlp-preview-text-toolbar' );

		if ( ! toolbar ) {
			return;
		}

		fontFamilySelect = toolbar.querySelector( 'select#font-family' );
		nsFontFamily = new NiceSelect(
			fontFamilySelect,
			{
				searchable: true,
				placeholder: "Select a font",
			}
		);

		fontFamilySelect.addEventListener('modalopen', () => {
			// Wait a moment to ensure the dropdown is rendered
			setTimeout(() => {
				const dropdownList = fontFamilySelect.nextElementSibling.querySelector('.nice-select-dropdown ul.list');
				const selected = dropdownList.querySelector('.option.selected');

				if (dropdownList && selected) {
					dropdownList.scrollTop = selected.offsetTop - dropdownList.offsetHeight / 2 + selected.offsetHeight / 2;
				}
			}, 0);

			state.set( { isFontListOpen: true } );
			state.set( { isEditingText: true } );
		});

		fontFamilySelect.addEventListener('modalclose', () => {
			if ( state.get( 'isFontListOpen' ) ) {
				state.set( { isEditingText: false } );
				state.set( { isFontListOpen: false } );
			}
		});


		const fontSize = toolbar.querySelector( '#font-size' );

		fontSize.addEventListener( 'focus', ( event ) => {
			state.set( { isEditingText: true } );
		} );

		fontSize.addEventListener( 'blur', ( event ) => {
			state.set( { isEditingText: false } );
		} );

		getFonts().then((fonts) => {
			allFonts.splice( 0, allFonts.length, ...fonts );
			fontFamilySelect.innerHTML = "";

			const fontsBySource = fonts.reduce((acc, font) => {
				const source = font.source || 'Custom';
				if (!acc[source]) {
					acc[source] = [];
				}
				acc[source].push(font);
				return acc;
			}, {});

			Object.entries(fontsBySource).forEach( ([groupName, fonts]) => {
				const group = document.createElement("optgroup");
				group.label = groupName;
				fontFamilySelect.append(group);

				fonts.forEach((font) => {
					const option = document.createElement("option");
					option.value = font.family;
					option.textContent = font.family;
					group.append(option);
				});
			} );

			loadFontFamily(allFonts[0].family);
			updateToolbar();
		});

		bindEvents();
	};

	const addEventListener = ( event, callback ) => {
		if ( ! toolbar ) {
			utils.warn("Toolbar is not initialized yet. You must add event listeners after the toolbar is initialized.");
			return;
		}

		toolbar?.addEventListener( event, callback );
	};

	const setSelectedText = ( text ) => {
		if ( text && text.type !== 'i-text' && text.type !== 'textbox' ) {
			return;
		}

		selectedText = text;
		updateToolbar();
	};

	const getDefaultFont = () => {
		if ( allFonts.length === 0 ) {
			return 'sans-serif';
		}

		return allFonts[0].family;
	};

	const updateFont = ( family = null, size = null, weight = null, style = null) => {
		if ( ! selectedText ) {
			return;
		}
	
		const canvas = ui.canvas();
	
		family = family || selectedText.fontFamily;
		const currentFontSize = toolbar.querySelector("#font-size").value * ui.displayRatio();
	
		selectedText._clearCache();
		selectedText.set("fontFamily", family);
		selectedText.set(
			"fontSize",
			size === "auto" ? parseInt(size * ui.displayRatio() || selectedText.fontSize) : currentFontSize
		);
		let measuredWidth = Math.min(canvas.width - 20, selectedText.calcTextWidth());
		let measuredHeight = selectedText.calcTextHeight() / selectedText.textLines.length;
	
		if (size === "auto") {
			selectedText.set("fontSize", selectedText.fontSize * ((canvas.width - 20) / measuredWidth));
			selectedText._clearCache();
			measuredWidth = Math.min(canvas.width - 20, selectedText.calcTextWidth());
			measuredHeight = selectedText.calcTextHeight() / selectedText.textLines.length;
		}
		selectedText.set("width", measuredWidth);
		selectedText.set("height", measuredHeight);
		selectedText.initDimensions();
		selectedText.setCoords();
		selectedText.fire("changed");
		ui.redraw();
		updateToolbar();
	};

	const loadFontFamily = ( family, weight = null, style = null ) => {
		weight = weight || selectedText?.fontWeight || 400;
		style = style || selectedText?.fontStyle || 'normal';

		loadFont(family, weight, style)
			.then(() => {
				updateFont( family );
				selectedText?.fire("wlp:family:changed");
				onFontChange();
			})
			.catch((error) => {
				console.error(error);
			});
	};

	const onFontChange = () => {
		toolbar.dispatchEvent(new CustomEvent('change', {
			detail: selectedText
		}));
	};

	const bindEvents = () => {
		document.addEventListener( 'click', onToolbarAction);
		document.addEventListener( 'change', onToolbarAction);
		document.addEventListener( 'input', onToolbarAction);
	};


	const onToolbarAction = (event) => {
		const target = event.target;
		const toolbarContent = target && target.closest( '#wlp-preview-text-toolbar' );

		if ( ! toolbarContent || ! selectedText ) {
			return;
		}

		if ( state.get( 'isEditingText' ) ) {
			// event.preventDefault();
			// event.stopPropagation();
		}

		selectedText._clearCache();

		switch (true) {
			case event.type === 'input':
				switch (target.id) {
					case "font-size":
						updateFont( selectedText.fontFamily, target.value );
						onFontChange();
						break;
					case "text-color":
						selectedText.set("fill", target.value);
						onFontChange();
						break;
				}
				break;

			case event.type === 'click':
				const button = target.closest( '.icon-button' );
				let isActive = false;

				if (button) {
					switch (button.id) {
						case "bold-btn":
							isActive = selectedText.fontWeight === 'bold';
							selectedText.set("fontWeight", isActive ? 'normal' : 'bold');
							loadFontFamily(selectedText.fontFamily, isActive ? 400 : 800, selectedText.fontStyle || 'regular');
							break;
						case "italic-btn":
							isActive = selectedText.fontStyle === 'italic';
							selectedText.set("fontStyle", isActive ? 'normal' : 'italic');
							loadFontFamily(selectedText.fontFamily, selectedText?.fontWeight, isActive ? 'regular' : 'italic');
							break;
						case "underline-btn":
							isActive = selectedText.underline;
							selectedText.set("underline", !isActive);
							onFontChange();
							break;
						case "align-left-btn":
						case "align-center-btn":
						case "align-right-btn":
							toolbarContent
								.querySelectorAll(".align-button")
								.forEach((btn) => {
									btn.classList.remove("active");
								});
							const activeAlignment = button.id.replace(/(align-|-btn)/g, "");
							isActive = selectedText.textAlign === activeAlignment;
							selectedText.set("textAlign", activeAlignment);
							onFontChange();
							break;
					}
					button.classList.toggle("active", !isActive);
				}
				break;

			case event.type === "change":
				if (target.id === "font-family") {
					loadFontFamily(target.value, selectedText?.fontWeight || 400, selectedText.fontStyle || 'normal');
				}
				break;
		}

		ui.redraw();
	};

	const updateToolbar = () => {
		if ( ! selectedText ) {
			toolbar?.toggleAttribute( 'hidden',  true );
			return;
		}

		const canvas = ui.canvas();
		const mask = canvas.getObjects( ...fabric.maskTypes ).find( ( m ) => m.id === selectedText.parentId );

		toolbar?.toggleAttribute( 'hidden',  false );
		const fontFamily = selectedText?.fontFamily ?? allFonts[0].family;
		const isFontFamilyDisabled = allFonts[0]?.length === 1 || ( mask.options?.no_font ?? false );
		const isColorDisabled = ( mask.options?.no_color ?? false );

		toolbar.querySelector( '#font-family' ).value = fontFamily;
		fontFamilySelect.toggleAttribute( 'disabled', isFontFamilyDisabled );
		nsFontFamily.setValue( fontFamily );

		toolbar.querySelector( '#font-size' ).value = Math.round( ( selectedText?.fontSize ?? 12 ) / ui.displayRatio() );
		toolbar.querySelector( '#bold-btn' ).classList.toggle( 'active', selectedText?.fontWeight === 'bold' );
		toolbar.querySelector( '#italic-btn' ).classList.toggle( 'active', selectedText?.fontStyle === 'italic' );
		toolbar.querySelector( '#underline-btn' ).classList.toggle( 'active', selectedText?.underline );

		toolbar.querySelector( '.buttons-align' ).toggleAttribute( 'hidden', ( selectedText?.type !== 'textbox' ) );

		if ( selectedText?.type === 'textbox' ) {
			toolbar.querySelector( '#align-left-btn' ).classList.toggle( 'active', selectedText?.textAlign === 'left' );
			toolbar.querySelector( '#align-center-btn' ).classList.toggle( 'active', selectedText?.textAlign === 'center' );
			toolbar.querySelector( '#align-right-btn' ).classList.toggle( 'active', selectedText?.textAlign === 'right' );
		}
		
		toolbar.querySelector( '#text-color' ).value = `#${( fabric.createColor( selectedText?.fill ) ).toHex()}`;
		toolbar.querySelector( '#text-color' ).toggleAttribute( 'disabled', isColorDisabled );
	};

	return {
		init,
		setSelectedText,
		updateToolbar,
		getDefaultFont,
		addEventListener,
	}
};