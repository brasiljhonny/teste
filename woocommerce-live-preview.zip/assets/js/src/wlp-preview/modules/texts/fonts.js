/**
 * External dependencies
 */
import WebFont from "webfontloader";


const fonts = [];

const normalizeVariant = ( variant ) => {
	if ( variant === '400italic' ) {
		variant = 'italic';
	}

	if ( variant === '400' ) {
		variant = 'regular';
	}

	return variant;
};

const getFontVariant = ( weight, style, availableVariants ) => {
	availableVariants = availableVariants || [];
	const fontWeight = (String(weight) || 'normal').replace( /normal/g, 'regular' ).replace( /regular/g, '400' ).replace( /bold/g, '800');
	const fontStyle = (style || 'normal').replace( /oblique/g, 'italic' ).replace( /normal/g, '' );
	let fontVariant = normalizeVariant( `${fontWeight}${fontStyle}` );

	// If a list of available variants is provided and the requested variant is not available,
	// we need to find the closest available variant
	// before falling back to the regular variant or the closest available one.
	// For example, if we requested '100italic' but only '200italic' is available,
	// we will use '200italic' instead.

	if ( availableVariants.length > 0 && ! availableVariants.includes( fontVariant ) ) {
		// Find the closest weight among the available variants
		let testVariant;
		let topWeight = parseInt( fontWeight );
		let bottomWeight = parseInt( fontWeight );

		while ( topWeight <= 900 || bottomWeight >= 100 ) {
			testVariant = normalizeVariant( `${bottomWeight}${fontStyle}` );

			if ( availableVariants.includes( testVariant ) ) {
				break;
			}

			testVariant = normalizeVariant( `${topWeight}${fontStyle}` );

			if ( availableVariants.includes( testVariant ) ) {
				break;
			}

			topWeight += 100;
			bottomWeight -= 100;
		}

		if ( availableVariants.includes( testVariant ) ) {
			fontVariant = testVariant;
		} else {
			// If no matching weight is found, fall back to the first available variant
			fontVariant = availableVariants[ 0 ];
		}
	}

	return fontVariant;
};

const findFont = ( family, weight = null, style = null ) => {
	if ( ! family || fonts.length === 0 ) {
		return null;
	}
	const availableFonts = fonts.filter( ( f ) => f.family === family );

	if ( availableFonts.length === 0 ) {
		utils.warn( `Font family "${ family }" not found` );
		return null;
	}

	const font = availableFonts[ 0 ];
	const availableVariants = Object.keys( font.files );
	const fontVariant = getFontVariant( weight, style, availableVariants );

	if ( ! font.files[ fontVariant ] ) {
		utils.warn( `Font variant "${ fontVariant }" not found for family "${ family }"` );
		return null;
	}

	return {
		family: font.family,
		source: font.source || 'Custom',
		files: font.files,
		variant: fontVariant,
		url: font.files[ fontVariant ],
		weight: font.weight || 'normal',
		style: font.style || 'normal',
		availableVariants: availableVariants,
	};
};

const getGoogleFonts = (force = false) => {
	return new Promise((resolve) => {
		fetch(
			`/wp-json/wc-live-preview/v1/fonts`
		)
			.then((response) => response.json())
			.then((gFonts) => {
				const googleFonts = gFonts.map((font) => {
					return {
						...font,
						source: 'Google Fonts',
					}
				} );
				resolve(googleFonts);
			})
	});
};

const getDocumentFonts = () => {
	if ( wlpSettings?.options?.show_document_fonts !== true ) {
		return [];
	}

	const documentFonts = Array.from( document.fonts ).filter( ( font ) => font.status === 'loaded' );
	const docFonts = [];

	documentFonts.forEach( ( font ) => {
		const fontFamily = font.family;
		const fontVariant = getFontVariant( font.weight, font.style );

		if ( ! docFonts.some( ( f ) => f.family === fontFamily ) ) {
			docFonts.push( {
				family: fontFamily,
				source: 'Document',
				files: {
					[fontVariant]: font.family,
				},
			} );
		} else {
			const existingFont = docFonts.find( ( f ) => f.family === fontFamily );
			if ( ! existingFont.files[fontVariant] ) {
				existingFont.files[fontVariant] = font.family;
			}
		}
	} );

	return docFonts.reverse();
};

export const getFonts = () => {
	return new Promise((resolve) => {
		if ( fonts.length > 0 ) {
			resolve(fonts);
			return;
		}
		// Fetch Google Fonts and document fonts
		getGoogleFonts().then((googleFonts) => {
			fonts.splice(0, fonts.length); // Clear the fonts array
			fonts.push(...getDocumentFonts());
			fonts.push(...googleFonts);
			resolve(fonts);
		});
	});
}

const updateFontSelector = () => {
	if (fonts.length === 0) {
		getGoogleFonts();
		return;
	}


	// TODO: Update the font family selector to reflect the current selected text's font family

	// nsFontFamily.update();
	// nsFontFamily.setValue(selectedText?.fontFamily);
	// const currentFontFamily = nsFontFamily.getValue() || fonts[0].family;
	// updateFont(currentFontFamily);
};

export const loadFont = (family, weight = null, style = null) => {
	return new Promise((resolve, reject) => {
		const font = fonts.find(f => f.family === family);
		if ( !font ) {
			reject(`Font not found`);
			return;
		}

		const availableVariants = Object.keys(font.files);
		const fontVariant = getFontVariant(weight, style, availableVariants);
		const selectedFont = findFont(family, weight, style);
		if ( !selectedFont ) {
			reject(`Selected font not found`);
			return;
		}

		if ( selectedFont.source === 'document' ) {
			resolve(selectedFont.family);
			return;
		}

		WebFont.load({
			google: {
				families: [`${family}:${fontVariant}`],
			},
			fontactive: (fontFamily) => {
				resolve(fontFamily);
			},
		});
	});
};

