import { getFieldLoader } from './modules.js';

( function ( $, settings ) {
	__webpack_public_path__ = settings.module_path_url;
	let $latestWQVModal = null;

	const previewableFields = [];

	const loadLivePreview = () => {
		return new Promise( ( resolve ) => {
			if ( ! window.LivePreview ) {
				import(
					/*webpackChunkName: "live-preview"*/
					'./live-preview.js'
				).then( ( module ) => {
					const livePreview = module.default( settings );
					document.dispatchEvent(
						new CustomEvent( 'wlp:loaded', {
							detail: {
								LivePreview: livePreview,
								settings,
							}
						} )
					);
					window.LivePreview = livePreview;
					window.LivePreview.init();

					resolve( livePreview );
				} );
			} else {
				resolve( window.LivePreview );
			}
		} );
	};

	const bindEvents = () => {
		window.addEventListener( 'DOMContentLoaded', () => {
			init();
		} );

		if ( previewableFields.length === 0 ) {
			// there are no previewable fields on the page
			// Bail out before any live preview events are bound
			return;
		}
	
		$( document.body ).on( 'quick_view_pro:load', (event, $modal) => {
			init( $modal.find( 'form.cart' ).get( 0 ) );
		} );

		$( document.body ).on( 'quick_view_pro:open', (event, $modal) => {
			$latestWQVModal = $modal;
		} );

		$( document ).one( 'found_variation', 'form.cart.variations_form', ( event, variation ) => {
			if ( ! window.LivePreview ) {
				loadLivePreview()
					.then( (livePreview) => {
						livePreview?.onFoundVariation( event, variation );
					} )
					.catch( ( error ) => {
						console.debug( 'found_variation error:', error );
					} );
			}
		} );

		document.addEventListener( 'wlp:modal:close', () => {
			if ( $latestWQVModal === null ) {
				return;
			}

			const productId = $latestWQVModal.attr( 'id' ).replace( 'quick-view-', '' );
			WCQuickViewPro.openQuickView( productId, $( `li.post-${ productId } a.wc-quick-view-button` ) );
			$latestWQVModal = null;
			window.dontCloseWQV = true;
		} );
	};

	const init = ( cartForm = null ) => {
		cartForm = cartForm || document.querySelector( 'form.cart' );

		if ( ! cartForm ) {
			return;
		}

		previewableFields.splice( 0, previewableFields.length, ...cartForm.querySelectorAll( '.wpo-field[data-live-preview-button-text]' ) );

		if ( previewableFields.length > 0 ) {
			// if there is at least one file field with live preview enabled
			// we need to add a live preview parameter to the body of the `get_variation` request
			$.ajaxSetup( {
				beforeSend: ( request, ajaxSettings ) => {
					// add a live preview parameter to the body of the request
					// so we can identify the request as a live preview request
					if ( ajaxSettings?.data && ajaxSettings?.url.includes( 'wc-ajax=get_variation' ) ) {
						ajaxSettings.data += '&isLivePreview=1';
					}
				},
			} );				
		}

		previewableFields.forEach( ( field ) => {
			const loader = getFieldLoader( field );

			if ( loader ) {
				field.querySelector( loader.selector )?.addEventListener( loader.event, () => {
					loadLivePreview()
						.then( (livePreview) => {
							loader.load().then( ( module ) => {
								livePreview.addModule( loader.name, module.default );
							} );
						} );
				} );
			}
		} );
	}

	init();
	bindEvents();

} )( jQuery, wlpSettings );