const _internalState = {};
const _cachedImages = {};
const $ = window.jQuery

/**
 * Initialize the internal state.
 *
 * @param {object} settings - The initial settings for the state.
 * @returns {void}
 */
export const init = ( settings ) => {
	Object.assign( _internalState, {
		...settings,
		objectMap: new Map(),
		maskMap: new Map(),
	});
}

/**
 * Get a value from the internal state.
 *
 * @param {string} key - The key to retrieve from the state.
 * @returns {*} The value from the state or the entire state if no key is provided.
 */
export const get = ( key ) => {
	if ( ! key ) {
		return _internalState;
	}

	if ( key in _internalState ) {
		return _internalState[ key ];
	}

	return null;
}

/**
 * Set a value in the internal state.
 *
 * @param {Object} partial - The partial state to set.
 * @returns {void}
 */
export const set = ( partial ) => {
	Object.assign( _internalState, partial );
};

/**
 * Set the printable areas attached to a specific key.
 * The key of the map is the image element itself and the value is an array of printable areas.
 *
 * @param {string} key 
 * @param {Array} value 
 * @returns {void}
 */
export const toMaskMap = ( key, value ) => {
	if ( ! value ) {
		return;
	}

	_internalState.maskMap.set( key, value );
};

/**
 * Get the printable areas attached to a specific key.
 * The key of the map is the image element itself and the value is an array of printable areas.
 *
 * @param {string} key - The key of the image element.
 * @returns {Array} The array of printable areas or an empty array if none exist.
 */
export const fromMaskMap = ( key ) => {
	return _internalState.maskMap.get( key );
};

/**
 * Set the objects attached to a specific key.
 * The key of the map is the id of a printable area and the value is an array of objects.
 *
 * @param {string} key - The ID of the printable area.
 * @param {Array} objects - The array of objects to attach.
 * @returns {void}
 */
export const toObjectMap = ( key, objects ) => {
	_internalState.objectMap.set( key, objects );
};

/**
 * Get the objects attached to a specific key.
 * The key of the map is the id of a printable area and the value is an array of objects.
 *
 * @param {string} key - The ID of the printable area.
 * @returns {Array} The array of objects or an empty array if none exist.
 */
export const fromObjectMap = ( key ) => {
	return _internalState.objectMap.get( key ) ?? [];
};

/**
 * Add an object to the array of objects attached to a specific key.
 *
 * @param {string} key - The ID of the printable area.
 * @param {*} object - The object to add.
 * @returns {void}
 */
export const addToObjectMap = ( key, object ) => {
	if ( ! object ) {
		return;
	}

	const objects = fromObjectMap( key ) ?? [];
	if ( objects.map( ( i ) => i.id ).includes( object?.id ) ) {
		return;
	}

	toObjectMap( key, [ ...( objects.filter( Boolean ) ), object ] );
};

/**
 * Find the key associated with a specific object.
 *
 * @param {Object} object - The object to find.
 * @returns {string|null} The key associated with the object or null if not found.
 */
export const findKeyByObject = ( object ) => {
	let foundKey = null;

	_internalState.objectMap.forEach( ( objects, key ) => {
		if ( foundKey || ! objects || objects.length === 0 ) {
			return;
		}

		const found = objects.find( ( o ) => o.id === object.id );
		
		if ( found ) {
			foundKey = key;
		}
	} );

	return foundKey;
};

/**
 * Remove an object from the array of objects attached to a specific key.
 *
 * @param {Object} object - The object to remove.
 * @returns {void}
 */
export const removeFromObjectMap = ( object ) => {
	if ( typeof object === 'string' ) {
		// the id was passed instead of the object
		object = { id: object };
	}
	
	// Find the object in the map
	const key = object.parentId || findKeyByObject( object );

	if ( ! key ) {
		return;
	}

	const objects = fromObjectMap( key ) ?? [];

	toObjectMap( key, objects.filter( ( i ) => i.id !== object?.id ) );
};

/**
 * Replace an object in the map.
 *
 * An object is unique to the entire map, so we can find it by its ID.
 * If the object has a parentId, that is the key of the map.
 * If it does not have a parentId, we will find the key
 * by searching the object ID in the map.
 *
 * @param {Object} object 
 * @returns {void}
 */
export const replaceInObjectMap = ( object ) => {
	const key = object.parentId || findKeyByObject( object );

	if ( ! key ) {
		return;
	}

	const objects = fromObjectMap( key ) ?? [];
	objects = objects.map( ( o ) => {
		if ( o.id === object.id ) {
			return object;
		}

		return o;
	} );

	toObjectMap( key, objects.map( ( o ) => {
		if ( o.id === object.id ) {
			return object;
		}

		return o;
	} ) );
};

/**
 * Handles the caching of preview images.
 * This allows us to store images in memory
 * and retrieve them later without needing to reload them from the server.
 */
export const cachedImages = {
    get(key) {
        return _cachedImages[key];
    },
    set(key, value) {
        _cachedImages[key] = value;
    },
    getAll() {
        return { ..._cachedImages }; // shallow copy to prevent mutation
    },
    update(partial) {
        Object.assign(_cachedImages, partial);
    }
};
