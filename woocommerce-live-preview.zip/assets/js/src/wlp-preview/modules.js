/**
 * Internal dependencies
 */
import loaders from './loaders';

const modules = {};

export const getFieldLoader = ( field ) => {
	return loaders.find( ( m ) => field?.className.includes( m.class ) );
};

export const hasModule = ( name ) => {
	return !! modules[ name ];
};

export const getModule = ( name ) => {
	if ( ! modules[ name ] ) {
		return null;
	}

	return modules[ name ];
};

export const getModuleByType = ( type ) => {
	const loader = loaders.find( ( m ) => m.type === type || m.fType === type );

	return getModule( loader?.name );
};

export const getModuleByClass = ( className ) => {
	const loader = loaders.find( ( m ) => className.includes( m.class ) );

	return getModule( loader?.name );
};

export const getModuleByOption = ( optionID ) => {
	const previewFields = document.querySelectorAll( '.wpo-field[data-live-preview-button-text]' );
	const field = Array.from( previewFields ).find( ( f ) => {
		return parseInt( f?.dataset?.optionId ) === parseInt( optionID );
	} );

	return getModuleByClass( field?.className );
};

export const addModule = ( name, module ) => {
	if ( hasModule( name ) ) {
		// the module is already loaded
		// return the existing module
		return getModule( name );
	}

	if ( typeof module === 'object' ) {
		modules[ name ] = module;
	}

	return getModule( name );
};

