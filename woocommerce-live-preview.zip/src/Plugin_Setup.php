<?php
namespace Barn2\Plugin\WC_Live_Preview;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Plugin\Licensed_Plugin;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Plugin\Plugin_Activation_Listener;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Service\Standard_Service;

/**
 * Hook into the plugin activation process.
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Plugin_Setup implements Plugin_Activation_Listener, Registerable, Standard_Service {

	/**
	 * Plugin's entry file
	 *
	 * @var string
	 */
	private $file;

	/**
	 * Plugin instance
	 *
	 * @var Plugin
	 */
	private $plugin;

	/**
	 * Get things started
	 *
	 * @param string $file
	 * @param Licensed_Plugin $plugin
	 */
	public function __construct( $file, Licensed_Plugin $plugin ) {
		$this->file   = $file;
		$this->plugin = $plugin;
	}

	/**
	 * Register the service
	 *
	 * @return void
	 */
	public function register(): void {
		register_activation_hook( $this->plugin->get_basename(), [ $this, 'on_activate' ] );
	}

	/**
	 * On plugin activation
	 *
	 * @param bool $network_wide Whether the plugin is being activated network-wide
	 * @return void
	 */
	public function on_activate( $network_wide ): void {}

	/**
	 * Do nothing.
	 *
	 * @param bool $network_wide Whether the plugin is being deactivated network-wide
	 * @return void
	 */
	public function on_deactivate( $network_wide ): void {}
}
