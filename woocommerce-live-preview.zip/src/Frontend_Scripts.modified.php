<?php

namespace Barn2\Plugin\WC_Live_Preview;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Conditional;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Util as Lib_Util;

/**
 * Handles the registering of the front-end scripts and stylesheets.
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Frontend_Scripts implements Registerable, Conditional, Standard_Service {

	private $plugin;
	private $handles = [
		'js'  => [
			'wlp-preview',
		],
		'css' => [
			'wlp-preview',
		],
	];

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin
	 */
	public function __construct( $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * {@inheritdoc}
	 */
	public function is_required(): bool {
		return Lib_Util::is_front_end();
	}

	/**
	 * {@inheritdoc}
	 */
	public function register(): void {
		add_filter( 'wc_product_options_live_preview_default_customize_button_text', [ $this, 'get_default_customize_button_text' ], 10 );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ], 15 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ], 20 );
	}

	/**
	 * Get the default text for the customize button.
	 *
	 * @param string $customize_button_text The text for the customize button.
	 * @return string
	 */
	public function get_default_customize_button_text( $customize_button_text ) {
		$options = get_option( 'wlp_live_preview', [] );

		return $options['customize_button_text'] ?? __( 'Customize', 'woocommerce-live-preview' );
	}

	/**
	 * Register the front-end assets.
	 */
	public function register_assets(): void {
		if ( ! Util::is_preview_enabled() ) {
			return;
		}

		foreach ( $this->handles['js'] as $script_handle ) {
			$this->plugin->register_script(
				$script_handle,
				"assets/js/$script_handle.js",
				Lib_Util::get_script_dependencies( $this->plugin, "{$script_handle}.js" )['dependencies']
			);
			$this->add_inline_script( $script_handle );
		}


		// Register inline bridge script to force inline rendering (no modal)
		$this->plugin->register_script(
			'wlp-inline-bridge',
			'assets/js/wlp-inline-bridge.js',
			[ 'jquery', 'wlp-preview' ]
		);
		foreach ( $this->handles['css'] as $style_handle ) {
			wp_register_style(
				$style_handle,
				plugins_url( "assets/css/{$style_handle}.css", $this->plugin->get_file() ),
				[],
				$this->plugin->get_version()
			);
		}
	}

	/**
	 * Add inline script to the registered script.
	 *
	 * @param string $script_handle The script handle.
	 * @return bool
	 */
	public function add_inline_script( $script_handle ) {
		$product = wc_get_product();

		$position        = 'before';
		$script_template = 'var %1$s = %2$s;';
		$options         = wp_parse_args(
			get_option( 'wlp_live_preview', [] ),
			[
				'customize_button_text'     => __( 'Customize', 'woocommerce-live-preview' ),
				'default_image_sizing'      => 'contain',
				'upscale_factor'            => 4,
				'max_canvas_size'           => 2400,
				'file_format'               => 'png',
				'file_quality'              => 0.6,
				'gallery_viewport_selector' => '.flex-viewport',
				'gallery_image_selector'    => '.woocommerce-product-gallery__image',
				'google_fonts_api_key'      => '',
				'show_document_fonts'       => true,
			]
		);

		/**
		 * Filter the text for the customize button.
		 *
		 * This is the global setting for the text that will be displayed on the customize button.
		 * This can be overridden on a per-option basis in the WooCommerce Product Options editor.
		 *
		 * @param string $customize_button_text The text for the customize button.
		 * @param \WC_Product $product The product being displayed.
		 * @return string
		 */
		$customize_button_text = apply_filters( 'wc_live_preview_customize_button_text', $options['customize_button_text'], $product );

		/**
		 * Filter the default sizing strategy of images added to a printable area.
		 *
		 * The possible values are `contain` and `cover`:
		 *  * `contain` will fit the image inside the printable area
		 *  * `cover` will fill the printable area and parts of the image may be cropped
		 *
		 * The default value is 'contain'.
		 *
		 * @param int $default_image_sizing The default sizing strategy.
		 * @param \WC_Product $product The product being displayed.
		 * @return int
		 */
		$default_image_sizing = apply_filters( 'wc_live_preview_default_image_sizing', $options['default_image_sizing'], $product );

		/**
		 * Filters the default canvas upscaling.
		 *
		 * The canvas of the live preview will be upscaled by this factor
		 * to improve the quality of the preview image.
		 * The default value is 4.
		 *
		 * @param int $max_upscale_factor The upscale factor.
		 * @param \WC_Product $product The product being displayed.
		 * @return int
		 */
		$max_upscale_factor = apply_filters( 'wc_live_preview_max_upscale_factor', intval( $options['upscale_factor'] ), $product );

		/**
		 * Filter the max size of the live preview canvas element.
		 *
		 * The size is provided as a scalar value because the canvas
		 * will always maintain the aspect ratio of the image.
		 * The default value is 2400 for the larger side. For example, if the image is 800x600,
		 * the canvas will be 2400x1800 and the resulting upscale factor will be 3.
		 * If the image is 600x800, the canvas will be 1800x2400, with the same upscale factor.
		 * The resulting upscale factor will not exceed the value set in `max_upscale_factor`.
		 * For example, if the image is 400x300 and the upscale factor is 4, the canvas will be 1600x1200
		 * regardless of the max_canvas_size.
		 *
		 * @param int $max_canvas_size The max size of the canvas.
		 * @param \WC_Product $product The product being displayed.
		 * @return int
		 */
		$max_canvas_size = apply_filters( 'wc_live_preview_max_canvas_size', intval( $options['max_canvas_size'] ), $product );

		/**
		 * Filter the file format of the preview image.
		 *
		 * The possible values are `png` and `jpeg`.
		 * The default value is 'png'.
		 *
		 * @param string $file_format The file format of the preview image.
		 * @param \WC_Product $product The product being displayed.
		 * @return string
		 */
		$file_format = apply_filters( 'wc_live_preview_file_format', $options['file_format'], $product );

		/**
		 * Filter the quality of the preview image.
		 *
		 * The value should be a float between 0 and 1.
		 * The default value is 0.6.
		 *
		 * @param float $file_quality The quality of the preview image.
		 * @param \WC_Product $product The product being displayed.
		 * @return float
		 */
		$file_quality = apply_filters( 'wc_live_preview_file_quality', floatval( $options['file_quality'] ), $product );

		/**
		 * Filter the selector for the gallery viewport element.
		 *
		 * The default value is '.flex-viewport'.
		 *
		 * @param string $gallery_viewport_selector The selector for the gallery viewport.
		 * @param \WC_Product $product The product being displayed.
		 * @return string
		 */
		$gallery_viewport_selector = apply_filters( 'wc_live_preview_gallery_viewport_selector', $options['gallery_viewport_selector'], $product );

		/**
		 * Filter the selector for the image gallery.
		 *
		 * The default value is '.woocommerce-product-gallery__image'.
		 *
		 * @param string $gallery_image_selector The selector for the image gallery.
		 * @param \WC_Product $product The product being displayed.
		 * @return string
		 */
		$gallery_image_selector = apply_filters( 'wc_live_preview_gallery_image_selector', $options['gallery_image_selector'], $product );

		/**
		 * Filter whether the document fonts should be hidden in the live preview.
		 *
		 * @param bool $show_document_fonts Whether to show document fonts.
		 * @param \WC_Product $product The product being displayed.
		 * @return bool
		 */
		$show_document_fonts = apply_filters( 'wc_live_preview_hide_document_fonts', $options['show_document_fonts'], $product );

		switch ( $script_handle ) {
			case 'wlp-preview':
				$var_content = wp_json_encode(
					[
						'debug'           => defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG,
						'page_template'   => get_page_template(),
						'module_path_url' => $this->plugin->get_dir_url() . 'assets/js/',
						'options'         => [
							'customize_button_text'     => $customize_button_text,
							'default_image_sizing'      => $default_image_sizing,
							'max_upscale_factor'        => $max_upscale_factor,
							'max_canvas_size'           => $max_canvas_size,
							'file_format'               => $file_format,
							'file_quality'              => $file_quality,
							'gallery_viewport_selector' => $gallery_viewport_selector,
							'gallery_image_selector'    => $gallery_image_selector,
							'google_fonts_api_key'      => $options['google_fonts_api_key'],
							'show_document_fonts'       => $show_document_fonts,
						],
					]
				);
				$script      = sprintf( $script_template, 'wlpSettings', $var_content );
				break;
		}

		return wp_add_inline_script( $script_handle, $script, $position );
	}

	/**
	 * Enqueue the front-end assets.
	 */
	public function enqueue_assets(): void {
		wp_enqueue_script( 'wlp-preview' );
		
		// Enqueue bridge and pass mapping from external fields to Live Preview
		wp_enqueue_script( 'wlp-inline-bridge' );
		wp_localize_script( 'wlp-inline-bridge', 'WLP_BRIDGE_CFG', [
			'fields'   => [
				[ 'selector' => 'input[name="wccpe_texto"]',  'prop' => 'text',       'optionId' => 101 ],
				[ 'selector' => 'select[name="wccpe_fonte"]', 'prop' => 'fontFamily', 'optionId' => 101 ],
				[ 'selector' => 'input[name="wccpe_cor"]',    'prop' => 'fill',       'optionId' => 101 ],
			],
			'defaults' => [
				'fontFamily'    => 'Arial',
				'fill'          => '#000000',
				'fontSize'      => 64,
				'fontWeight'    => 'normal',
				'textAlign'     => 'center',
				'letterSpacing' => 0,
				'anchorX'       => 50,
				'anchorY'       => 50,
			],
			'forceInline' => true,
		] );
wp_enqueue_style( 'wlp-preview' );
	}
}
