<?php

namespace Barn2\Plugin\WC_Live_Preview\Integrations;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Conditional;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Util as Lib_Util;

/**
 * The utility class.
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Quick_View implements Registerable, Standard_Service, Conditional {

	/**
	 * {@inheritdoc}
	 */
	public function is_required() {
		return Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Quick_View_Pro\wqv' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'wc_live_preview_is_preview_enabled', [ $this, 'is_preview_enabled' ] );
	}

	/**
	 * Filter the status of the preview functionality.
	 *
	 * @param bool $is_preview_enabled The current status of the preview functionality.
	 * @return bool
	 */
	public function is_preview_enabled( $is_preview_enabled ) {
		return $is_preview_enabled || is_shop();
	}
}
