<?php
/**
 * The HTML for the printable area editor.
 *
 * @package   Barn2\woocommerce-live-preview
 */

 // phpcs:ignore
$post_id         = esc_attr( $post_id );
$shape_buttons   = [
	'rectangle' => __( 'Add a rectangular printable area', 'woocommerce-live-preview' ),
	'circle'    => __( 'Add a circular printable area', 'woocommerce-live-preview' ),
	'freeform'  => __( 'Add a freeform printable area', 'woocommerce-live-preview' ),
];
$global_settings = [
	'variations' => __( 'Use for variation images', 'woocommerce-live-preview' ),
];
$area_settings   = [
	'single_image' => __( 'Allow only one image per area', 'woocommerce-live-preview' ),
	'no_move'      => __( 'Disable moving', 'woocommerce-live-preview' ),
	'no_resize'    => __( 'Disable resizing', 'woocommerce-live-preview' ),
	'no_rotate'    => __( 'Disable rotating', 'woocommerce-live-preview' ),
	'no_font'      => __( 'Disable font selection', 'woocommerce-live-preview' ),
	'no_color'     => __( 'Disable color selection', 'woocommerce-live-preview' ),
];

$tabindex = 0;

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
?>

<div class="printable-area-editor">
	<div id="media-head-<?php echo $post_id; ?>" style="display: none;"></div>
	<div id="printable-area-editor-<?php echo $post_id; ?>">
		<div class="imgedit-wrap wp-clearfix">
			<div id="paedit-panel-<?php echo $post_id; ?>">
				<div class="imgedit-panel-content wp-clearfix">
					<h2 style="flex: 1 0 100%;">
						<span><?php echo __( 'PRINTABLE AREAS', 'woocommerce-live-preview' ); ?></span>
						<a href="https://barn2.com/kb/live-preview" target="_blank" class="wlp-live-preview-documentation" tabindex="<?php echo ++$tabindex; ?>">
							<span class="dashicon dashicons dashicons-book"></span>
							<?php echo __( 'Documentation', 'woocommerce-live-preview' ); ?>
						</a>
					</h2>
					<div class="imgedit-tools">
						<input type="hidden" id="paedit-nonce-<?php echo $post_id; ?>" value="<?php echo $preview_nonce; ?>" />
						<input type="hidden" id="paedit-sizer-<?php echo $post_id; ?>" value="<?php echo $sizer; ?>" />
						<input type="hidden" id="paedit-selection-<?php echo $post_id; ?>" value="" />
						<input type="hidden" id="paedit-x-<?php echo $post_id; ?>" value="<?php echo isset( $meta['width'] ) ? $meta['width'] : 0; ?>" />
						<input type="hidden" id="paedit-y-<?php echo $post_id; ?>" value="<?php echo isset( $meta['height'] ) ? $meta['height'] : 0; ?>" />

						<div id="paedit-crop-<?php echo $post_id; ?>" class="imgedit-crop-wrap">
							<canvas id="mask-editor"></canvas>
							<div class="imgedit-crop-grid"></div>
							<img id="image-preview-<?php echo $post_id; ?>" onload="imageEdit.imgLoaded('<?php echo $post_id; ?>'); printableAreaEditor.displayCanvas(this);"
								src="<?php echo esc_url( admin_url( 'admin-ajax.php', 'relative' ) . '?action=imgedit-preview&amp;_ajax_nonce=' . $preview_nonce . '&amp;postid=' . $post_id . '&amp;rand=' . wp_rand( 1, 99999 ) ); ?>"
								alt=""
							/>
						</div>
					</div>
					<div class="paedit-settings">
						<div class="paedit-tool-active">
							<div id="paedit-group-printable-areas" class="paedit-group-top">
								<h2><?php echo __( 'Add printable areas', 'woocommerce-live-preview' ); ?></h2>
								<?php
								foreach ( $shape_buttons as $key => $label ) {
									// phpcs:ignore
									$nonce = wp_create_nonce( 'add_printable_area_' . $key );
									?>
									<button
										id="paedit-<?php echo $key . '-' . $post_id; ?>"
										class="button-secondary button-icon-<?php echo $key; ?>"
										type="button"
										onclick="printableAreaEditor.add<?php echo ucfirst( $key ); ?>Area( <?php printf( '%s, \'%s\'', $post_id, $nonce ); ?>, this );"
										title="<?php echo $label; ?>"
										tabindex="<?php echo ++$tabindex; ?>"
									></button>
								<?php } ?>
							</div>
							<div id="paedit-group-image-options" class="paedit-group-top">
								<h2><?php echo __( 'Image global settings', 'woocommerce-live-preview' ); ?></h2>
								<div class="imgedit-group imgedit-panel-active">
									<div id="paedit-image-options" class="imgedit-group-controls">

										<?php
										foreach ( $global_settings as $key => $label ) {
											// phpcs:ignore 
											$id = str_replace( '_', '-', $key );
											?>
											<fieldset class="paedit-checkbox-option global-setting">
												<label for="paedit-<?php echo $id . '-' . $post_id; ?>" class="">
													<input
														id="paedit-<?php echo $id . '-' . $post_id; ?>"
														name="<?php echo $key; ?>"
														type="checkbox"
														<?php checked( filter_var( $area_options[ $key ], FILTER_VALIDATE_BOOLEAN ) ); ?>
														tabindex="<?php echo ++$tabindex; ?>"
													>
													<?php echo $label; ?>
												</label>
											</fieldset>
										<?php } ?>
									</div>
								</div>
							</div>
							<div id="selected-area-settings" class="paedit-group-top hidden">
								<h2><?php echo __( 'Selected area', 'woocommerce-live-preview' ); ?></h2>
								<div id="paedit-group-image-options" class="paedit-group-top">
									<h2><?php echo __( 'Content Settings', 'woocommerce-live-preview' ); ?></h2>
									<div class="imgedit-group imgedit-panel-active">
										<div id="paedit-image-options" class="imgedit-group-controls">

											<?php
											foreach ( $area_settings as $key => $label ) {
												// phpcs:ignore 
												$id = str_replace( '_', '-', $key );
												?>
												<fieldset class="paedit-checkbox-option area-setting">
													<label for="paedit-<?php echo $id . '-' . $post_id; ?>" class="">
														<input
															id="paedit-<?php echo $id . '-' . $post_id; ?>"
															name="<?php echo $key; ?>"
															type="checkbox"
															<?php checked( filter_var( $area_settings[ $key ], FILTER_VALIDATE_BOOLEAN ) ); ?>
															tabindex="<?php echo ++$tabindex; ?>"
														>
														<?php echo $label; ?>
													</label>
												</fieldset>
											<?php } ?>
										</div>
									</div>
								</div>
								<?php if ( $option_dropdown ) { ?>
									<div class="paedit-group-top">
										<h2><?php echo __( 'Linked Option', 'woocommerce-live-preview' ); ?></h2>
										<div id="paedit-wpo-option-dropdown-container">
											<?php echo $option_dropdown; ?>
										</div>
									</div>
								<?php } ?>
								<div id="selected-area-details" class="paedit-group-top">
									<h2><?php echo __( 'Area Details', 'woocommerce-live-preview' ); ?></h2>
									<dl>
										<dt><?php echo __( 'Type:', 'woocommerce-live-preview' ); ?></dt>
										<dd id="selected-area-type"></dd>
										<dt><?php echo __( 'Position:', 'woocommerce-live-preview' ); ?></dt>
										<dd id="selected-area-position"></dd>
										<dt><?php echo __( 'Size:', 'woocommerce-live-preview' ); ?></dt>
										<dd id="selected-area-size"></dd>
									</dl>
								</div>
							</div>
						</div>

						<div id="paedit-action-buttons" class="paedit-group-top">
							<button
								class="button-primary" type="button"
								onclick="printableAreaEditor.save();"
								tabindex="<?php echo ++$tabindex; ?>"
							>
								Apply
							</button>
							<button type="button"
								onclick="printableAreaEditor.close( <?php echo $post_id . ', 1'; ?> );"
								class="button"
								tabindex="<?php echo ++$tabindex; ?>"
							>
								Cancel
							</button>
						</div>
					</div>
				</div>

			</div>

			<div class="imgedit-wait" id="imgedit-wait-<?php echo $post_id; ?>"></div>
			<div class="hidden" id="imgedit-leaving-<?php echo $post_id; ?>">
				<?php echo __( 'There are unsaved changes that will be lost.', 'woocommerce-live-preview' ); ?>
				<?php echo __( "'OK' to continue, 'Cancel' to return to the Printable Area Editor.", 'woocommerce-live-preview' ); ?>
			</div>
		</div>
	</div>
</div>

<?php
