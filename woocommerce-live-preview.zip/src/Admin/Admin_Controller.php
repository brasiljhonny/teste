<?php

namespace Barn2\Plugin\WC_Live_Preview\Admin;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Plugin\Admin\Admin_Links;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\WooCommerce\Admin\Navigation;
use Barn2\Plugin\WC_Live_Preview\Plugin;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Admin\Plugin_Promo;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Conditional;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Service\Service_Container;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Util as Lib_Util;

/**
 * General Admin Functions
 *
 * @package   Barn2\woocommerce-product-options
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Admin_Controller implements Registerable, Conditional, Standard_Service {

	use Service_Container;

	private $plugin;
	private $license_setting;
	private $options;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin          = $plugin;
		$this->license_setting = $plugin->get_license_setting();

		$this->add_services();
	}

	/**
	 * {@inheritdoc}
	 */
	public function is_required() {
		return Lib_Util::is_admin();
	}

	/**
	 * Get the admin services.
	 *
	 * @return void
	 */
	public function add_services() {
		$this->add_service( 'admin_links', new Admin_Links( $this->plugin ) );
		$this->add_service( 'settings_page', new Settings_Page( $this->plugin ) );
		$this->add_service( 'admin_editor', new Admin_Editor( $this->plugin ) );
	}

	/**
	 * {@inheritdoc}
	 */
	public function register(): void {
		$this->register_services();

		$plugin_promo = new Plugin_Promo( $this->plugin );
		$plugin_promo->register();

		$this->start_all_services();
	}
}
