<?php


namespace Barn2\Plugin\WC_Live_Preview\Admin;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Plugin\Licensed_Plugin;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Product_Options\Model\Group;
use Barn2\Plugin\WC_Product_Options\Model\Option;
use Barn2\Plugin\WC_Product_Options\Dependencies\Illuminate\Database\Eloquent\Collection;

use const WC_PLUGIN_FILE;
use const WC_VERSION;

/**
 * The Live Preview settings tab.
 *
 * @package   Barn2\woocommerce-product-options
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Admin_Editor implements Registerable, Standard_Service {

	private $plugin;

	/**
	 * Get things started.
	 *
	 * @param Licensed_Plugin $plugin
	 */
	public function __construct( Licensed_Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * Register the settings.
	 */
	public function register() {
		add_action( 'wp_ajax_wlp_editor', [ $this, 'ajax_load_editor' ] );
		add_action( 'wp_ajax_wlp_editor_save', [ $this, 'ajax_save_editor_data' ] );
		add_action( 'wp_ajax_wlp_editor_copy_areas', [ $this, 'ajax_copy_areas' ] );
		add_action( 'attachment_updated', [ $this, 'update_printable_areas' ] );
		add_action( 'print_media_templates', [ $this, 'print_media_templates' ] );
		add_filter( 'wp_prepare_attachment_for_js', [ $this, 'add_attachment_meta' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ], PHP_INT_MAX );
	}

	/**
	 * Handles the AJAX request to load the editor.
	 *
	 * This function is triggered via an AJAX call to load the editor interface.
	 *
	 * @return void
	 */
	public function ajax_load_editor() {
		$post_id    = abs( filter_input( INPUT_POST, 'attachment_id', FILTER_VALIDATE_INT ) );
		$post_nonce = filter_input( INPUT_POST, 'nonce' );

		if ( ! wp_verify_nonce( $post_nonce, "wlp-editor-$post_id" ) ) {
			wp_send_json_error( [ 'message' => 'You are not allowed to perform this action.' ] );
		}

		$note          = '';
		$nonce         = wp_create_nonce( "wlp-editor-$post_id" );
		$preview_nonce = wp_create_nonce( "image_editor-$post_id" );

		if ( ! $post_id ) {
			wp_send_json_error( [ 'message' => 'Invalid attachment ID' ] );
		}

		$attachment = get_post( $post_id );

		if ( ! $attachment ) {
			wp_send_json_error( [ 'message' => 'Attachment not found' ] );
		}

		$meta = wp_get_attachment_metadata( $post_id );

		if ( isset( $meta['width'], $meta['height'] ) ) {
			$big = max( $meta['width'], $meta['height'] );
		} else {
			wp_send_json_error( [ 'message' => __( 'Image data does not exist. Please re-upload the image.', 'woocommerce-live-preview' ) ] );
		}

		$printable_areas = get_post_meta( $post_id, '_wlp_printable_areas', true );
		$areas           = $printable_areas['areas'] ?? [];
		$legacy_options  = $printable_areas['options'] ?? [];
		unset( $legacy_options['variations'] );

		foreach ( $areas as $key => $area ) {
			$areas[ $key ]['options'] = array_map(
				function ( $value ) {
					if ( is_numeric( $value ) ) {
						return floatval( $value );
					}

					if ( $value === 'true' || $value === 'false' ) {
						return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
					}

					return $value;
				},
				$area['options'] ?? $legacy_options
			);
		}

		$sizer           = $big > 600 ? 600 / $big : 1;
		$option_dropdown = $this->get_linkable_option_dropdown();

		$area_options = array_merge(
			[
				'variations' => false,
			],
			array_map(
				function ( $value ) {
					return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
				},
				$printable_areas['options'] ?? $legacy_options
			)
		);

		ob_start();
		include $this->plugin->get_dir_path() . 'src/Admin/views/html-wlp-editor.php';
		$html = ob_get_clean();

		wp_send_json_success(
			[
				'html'    => $html,
				'areas'   => $areas,
				'options' => $area_options,
			]
		);
	}

	/**
	 * Get the default area options.
	 *
	 * @return array
	 */
	public function get_default_area_options( $legacy_options = [] ) {
		return array_merge(
			$legacy_options ?? [],
			[
				'single_image'     => true,
				'no_move'          => false,
				'no_resize'        => false,
				'no_rotate'        => false,
				'assigned_options' => '',
			]
		);
	}

	/**
	 * Handles the AJAX request to save the editor data.
	 *
	 * This function is triggered via an AJAX call to save the editor data.
	 * It saves the data as metadata of the attachment image.
	 *
	 * @return void
	 */
	public function ajax_save_editor_data() {
		$post_id = abs( filter_input( INPUT_POST, 'attachment_id', FILTER_VALIDATE_INT ) );
		$nonce   = filter_input( INPUT_POST, 'nonce' );

		if ( ! wp_verify_nonce( $nonce, "wlp-editor-$post_id" ) ) {
			wp_send_json_error( [ 'message' => 'You are not allowed to perform this action.' ] );
		}

		if ( ! $post_id ) {
			wp_send_json_error( [ 'message' => 'Invalid attachment ID' ] );
		}

		$data = filter_input( INPUT_POST, 'data', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );

		if ( ! is_array( $data ) || ! isset( $data['areas'] ) || empty( $data['areas'] ) ) {
			delete_post_meta( $post_id, '_wlp_printable_areas' );
			wp_send_json_success();
		}
		$data['options'] = array_merge(
			[
				'variations' => false,
			],
			$data['options'] ?? []
		);

		update_post_meta( $post_id, '_wlp_printable_areas', $data );

		wp_send_json_success();
	}

	/**
	 * Update the printable areas of the attachment.
	 *
	 * @param int $post_id The attachment ID.
	 * @return void
	 */
	public function update_printable_areas( $post_id ) {
		// phpcs:reason The nonce has already been verified in the `wp_ajax_save_attachment` function
		// phpcs:ignore WordPress.Security.NonceVerification
		$changes = $_REQUEST['changes'] ?? [];

		if ( ! isset( $changes['printableAreas'] ) ) {
			return;
		}

		$printable_areas = $changes['printableAreas'];

		if ( ! isset( $printable_areas['areas'] ) || ! is_array( $printable_areas['areas'] ) || empty( $printable_areas['areas'] ) ) {
			delete_post_meta( $post_id, '_wlp_printable_areas' );
			return;
		}

		update_post_meta( $post_id, '_wlp_printable_areas', $printable_areas );
	}

	/**
	 * Add the editor button to the attachment details.
	 *
	 * @param array $response
	 * @param object $attachment
	 *
	 * @return array
	 */
	public function add_attachment_meta( $response, $attachment ) {
		$printable_areas = get_post_meta( $attachment->ID, '_wlp_printable_areas', true );

		if ( ! $printable_areas ) {
			$printable_areas = [
				'areas'   => [],
				'options' => [ 'variations' => false ],
			];
		}

		$legacy_options = $printable_areas['options'] ?? [];
		unset( $legacy_options['variations'] );

		foreach ( $printable_areas['areas'] as $key => $area ) {
			$printable_areas['areas'][ $key ]['options'] = array_map(
				function ( $value ) {
					if ( is_numeric( $value ) ) {
						return floatval( $value );
					}

					if ( $value === 'true' || $value === 'false' ) {
						return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
					}

					return $value;
				},
				$area['options'] ?? $legacy_options
			);
		}

		if ( ! $response['meta'] ) {
			$response['meta'] = [];
		}

		$response['meta']['printable_areas']  = $printable_areas;
		$response['nonces']['printable_area'] = wp_create_nonce( "wlp-editor-$attachment->ID" );

		return $response;
	}

	/**
	 * Print the media templates for the printable area buttons.
	 *
	 * @return void
	 */
	public function print_media_templates() {
		$buttons = [
			'set'   => [
				'text'   => __( 'Set printable areas', 'woocommerce-live-preview' ),
				'action' => 'open',
			],
			'edit'  => [
				'text'   => __( 'Edit printable areas', 'woocommerce-live-preview' ),
				'action' => 'open',
			],
			'copy'  => [
				'text'   => __( 'Copy areas', 'woocommerce-live-preview' ),
				'action' => 'copyAreas',
			],
			'paste' => [
				'text'   => __( 'Paste areas', 'woocommerce-live-preview' ),
				'action' => 'pasteAreas',
			],
		];

		// Template for the additional WLP buttons.
		?>
		<script type="text/html" id="tmpl-wlp-printable-area-buttons">
			<label class="name">
				<span class="label-text"><?php esc_html_e( 'Printable areas', 'woocommerce-live-preview' ); ?></span>
				<span class="barn2-help-tip" data-tip="<?php esc_html_e( 'To duplicate the printable areas from one image to another, use the \'Copy areas\' button and then go to the other image and click \'Paste areas\'.', 'woocommerce-live-preview' ); ?>"></span>
			</label>
			<span class="wlp-button-container">
				<?php foreach ( $buttons as $key => $button ) { ?>
					<button
						id="wlp-button-<?php echo esc_attr( $key ); ?>"
						type="button"
						class="button wlp-editor-button"
						data-action="<?php echo esc_attr( $button['action'] ); ?>"
						data-post-id="{{ data?.id }}"
						data-nonce="{{ data?.nonces?.printable_area }}"
						<?php
						if ( $key === 'copy' ) {
							echo '{{ data?.meta?.printable_areas?.areas?.length > 0 ? "" : "disabled" }}';
						}
						if ( $key === 'paste' ) {
							echo 'disabled';
						}
						?>
						>
							<?php echo $button['text']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</button>
				<?php } ?>
			</span>
		</script>
		<?php
	}

	/**
	 * Return the HTML markup of a dropdown with the names of the groups and options
	 * that have at least one option of the following types:
	 * - file_upload
	 * - text
	 * - paragraph
	 *
	 * @return string
	 */
	public function get_linkable_option_dropdown() {
		// phpcs:disable Generic.Commenting.DocComment.MissingShort

		/** @disregard P1009 Undefined type */
		$group_collection = Group::orderBy( 'name', 'asc' )->get();

		/** @disregard P1009 Undefined type */
		if ( ! $group_collection instanceof Collection ) {
			return false;
		}

		$linkable_options = [];
		$image_mime_types = array_filter(
			get_allowed_mime_types(),
			function ( $mime_type ) {
				return strpos( $mime_type, 'image' ) === 0;
			}
		);

		$image_extensions = array_reduce(
			array_keys( $image_mime_types ),
			function ( $extensions, $mime_type ) {
				return array_merge( $extensions, explode( '|', $mime_type ) );
			},
			[]
		);

		foreach ( $group_collection as $group ) {
			/** @disregard P1009 Undefined type */
			$option_collection = Option::where( 'group_id', $group->id )->orderBy( 'menu_order', 'asc' )->get();

			/** @disregard P1009 Undefined type */
			if ( ! $option_collection instanceof Collection ) {
				continue;
			}

			$linkable_options[ $group->id ] = [
				'name'    => $group->name,
				'options' => [],
			];

			foreach ( $option_collection as $option ) {
				if ( ! ( $option->settings['live_preview'] ?? false ) ) {
					continue;
				}

				if ( $option->type === 'file_upload' ) {
					$allowed_types  = array_reduce(
						$option->settings['file_upload_allowed_types'] ?? [],
						function ( $types, $type ) {
							return array_merge( $types, explode( '|', $type ) );
						},
						[]
					);
					$support_images = false;

					if ( empty( $allowed_types ) ) {
						// Allowed types is empty, so we use the default types, which support images.
						$support_images = true;
					} elseif ( ! empty( array_intersect( $image_extensions, $allowed_types ) ) ) {
						// The option has allowed types and at least one of them is an image extension.
						$support_images = true;
					}

					if ( $support_images ) {
						$linkable_options[ $group->id ]['options'][] = [
							'id'   => $option->id,
							'name' => $option->name,
						];
					}
				}

				if ( in_array( $option->type, [ 'text', 'textarea' ], true ) ) {
					$linkable_options[ $group->id ]['options'][] = [
						'id'   => $option->id,
						'name' => $option->name,
					];
				}
			}
		}

		// phpcs:enable Generic.Commenting.DocComment.MissingShort

		// Generate the HTML markup of a dropdown with group names used as optgroup and option names as options.
		// This will be used in the editor to select the file upload option to attach the live preview to.

		$html = '<select id="paedit-wpo-option-dropdown" name="assigned_options" multiple>';

		foreach ( $linkable_options as $group ) {
			$group_name = $group['name'];

			if ( empty( $group['options'] ) ) {
				continue;
			}

			$html .= "<optgroup label='$group_name'>";

			foreach ( $group['options'] as $option ) {
				$html .= "<option value='{$option['id']}'>{$option['name']}</option>";
			}

			$html .= '</optgroup>';

		}

		$html .= '</select>';

		return $html;
	}

	/**
	 * Enqueue the assets.
	 */
	public function enqueue_assets() {
		global $wp_scripts;
		$screen = get_current_screen();

		if ( $screen->id !== 'upload' && $screen->post_type !== 'attachment' && $screen->post_type !== 'shop_order' ) {
			return;
		}

		wp_enqueue_script( 'barn2-tiptip', plugins_url( 'dependencies/barn2/barn2-lib/build/js/jquery-tiptip/jquery.tipTip.js', $this->plugin->get_file() ), [ 'jquery' ], $this->plugin->get_version(), true );
		wp_enqueue_style( 'barn2-tooltip', plugins_url( 'dependencies/barn2/barn2-lib/build/css/tooltip-styles.css', $this->plugin->get_file() ), [], $this->plugin->get_version() );

		// phpcs:disable Generic.Commenting.DocComment.MissingShort
		/** @disregard P1011 Undefined constant */
		wp_enqueue_script( 'selectWoo', plugins_url( 'assets/js/selectWoo/selectWoo.full.min.js', WC_PLUGIN_FILE ), [ 'jquery' ], WC_VERSION, false );
		/** @disregard P1011 Undefined constant */
		wp_enqueue_style( 'select2', plugins_url( 'assets/css/select2.css', WC_PLUGIN_FILE ), [], WC_VERSION );
		// phpcs:enable Generic.Commenting.DocComment.MissingShort

		wp_enqueue_script(
			'wlp-media-extension',
			$this->plugin->get_dir_url() . 'assets/js/admin/wlp-media-extension.js',
			[ 'jquery', 'media-views', 'media-grid' ],
			$this->plugin->get_version(),
			[
				'in_footer' => true,
			]
		);

		wp_enqueue_script(
			'wlp-editor',
			$this->plugin->get_dir_url() . 'assets/js/admin/wlp-editor.js',
			[ 'jquery', 'selectWoo' ],
			$this->plugin->get_version(),
			[
				'in_footer' => true,
			]
		);

		wp_add_inline_script(
			'wlp-editor',
			sprintf(
				'window.wlpEditor = %s;',
				wp_json_encode(
					[
						'debug' => defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG,
					]
				)
			),
			'before'
		);

		wp_enqueue_style(
			'wlp-editor',
			$this->plugin->get_dir_url() . 'assets/css/admin/wlp-editor.css',
			[ 'select2' ],
			$this->plugin->get_version()
		);
	}
}
