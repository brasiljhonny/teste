<?php

namespace Barn2\Plugin\WC_Live_Preview\Admin;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Plugin\License\License;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Plugin\Licensed_Plugin;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Live_Preview\Util;

/**
 * The settings page.
 *
 * @package   Barn2\woocommerce-product-options
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Settings_Page implements Registerable, Standard_Service {

	/**
	 * Plugin handling the page.
	 *
	 * @var Licensed_Plugin
	 */
	public $plugin;

	/**
	 * License handler.
	 *
	 * @var License
	 */
	public $license;

	/**
	 * List of settings.
	 *
	 * @var array
	 */
	public $registered_settings = [];

	/**
	 * The live preview options.
	 *
	 * @var array
	 */
	private $options = [];

	/**
	 * Constructor.
	 *
	 * @param Licensed_Plugin $plugin
	 */
	public function __construct( Licensed_Plugin $plugin ) {
		$this->plugin  = $plugin;
		$this->license = $plugin->get_license();
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'wc_product_options_general_settings', [ $this, 'add_live_preview_settings' ], 15 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_filter( 'wc_product_options_settings_app_params', [ $this, 'add_wpo_settings_param' ] );
		add_action( 'admin_footer', [ $this, 'add_live_preview_settings_css' ] );
	}

	/**
	 * Register the settings.
	 *
	 * @param array $settings
	 * @return array
	 */
	public function add_live_preview_settings( $settings ) {
		if ( filter_input( INPUT_GET, 'page' ) !== 'wpo_options' || filter_input( INPUT_GET, 'tab' ) !== 'general' ) {
			return $settings;
		}

		$google_fonts = Util::get_google_fonts();

		if ( is_wp_error( $google_fonts ) ) {
			$google_fonts = [];
		}

		$font_families = array_column( $google_fonts, 'family' );
		$font_options  = array_combine( $font_families, $font_families );

		$live_preview_settings = [
			[
				'title' => __( 'Live Preview', 'woocommerce-live-preview' ),
				'type'  => 'title',
				'id'    => 'wlp_live_preview_general',
				'desc'  => __( 'The following options control the WooCommerce Live Preview extension.', 'woocommerce-live-preview' ),
			],
			[
				'title'    => __( 'Customize button text', 'woocommerce-live-preview' ),
				'type'     => 'text',
				'id'       => 'wlp_live_preview[customize_button_text]',
				'desc'     => __( 'The text used for the customize button.', 'woocommerce-live-preview' ),
				'class'    => 'regular-text',
				'default'  => __( 'Customize', 'woocommerce-live-preview' ),
				'desc_tip' => __( 'The text of this button can be overridden for each option.', 'woocommerce-live-preview' ),
			],
			[
				'title'    => __( 'Preview label', 'woocommerce-live-preview' ),
				'type'     => 'text',
				'id'       => 'wlp_live_preview[cart_label]',
				'desc'     => __( 'The label for the previews on the cart and checkout pages.', 'woocommerce-live-preview' ),
				'class'    => 'regular-text',
				'default'  => __( 'Preview', 'woocommerce-live-preview' ),
				'desc_tip' => __( 'When previews are added to the product metadata in the cart, this label will be used to identify them.', 'woocommerce-live-preview' ),
			],
			[
				'title'    => __( 'Google Fonts API Key', 'woocommerce-live-preview' ),
				'type'     => 'text',
				'id'       => 'wlp_live_preview[google_fonts_api_key]',
				'desc'     => sprintf(
					// translators: %s is a link to the Google Fonts API page.
					__( 'To use Google fonts, it is necessary to add your Google API Key.<br>%s to learn how to generate a new one.', 'woocommerce-live-preview' ),
					sprintf(
						'<a href="%s" target="_blank">%s</a>',
						'https://developers.google.com/fonts/docs/developer_api#identifying_your_application_to_google',
						__( 'Click here', 'woocommerce-live-preview' )
					)
				),
				'class'    => 'regular-text',
				'default'  => '',
				'desc_tip' => __( 'The Google Fonts API key is required to use Google fonts in the live preview.', 'woocommerce-live-preview' ),
			],
			count( $font_options ) > 0
				? [
					'title'             => __( 'Allowed Google fonts', 'woocommerce-live-preview' ),
					'type'              => 'multiselect',
					'id'                => 'wlp_live_preview[allowed_google_fonts]',
					'desc'              => __( 'Select the fonts available to your customers or leave blank to use all Google fonts', 'woocommerce-live-preview' ),
					'class'             => 'wc-enhanced-select',
					'options'           => $font_options,
					'default'           => '',
					'custom_attributes' => [
						'data-placeholder' => __( 'Select fonts', 'woocommerce-live-preview' ),
					],
				]
				: null,
			[
				'type' => 'sectionend',
				'id'   => 'wlp_live_preview_general',
			],
		];

		return array_merge( $settings, array_values( array_filter( $live_preview_settings ) ) );
	}

	/**
	 * Add the WPO settings param.
	 *
	 * @param array $params
	 *
	 * @return array
	 */
	public function add_wpo_settings_param( $params ) {
		$options                              = get_option( 'wlp_live_preview', [] );
		$params['use_live_preview']           = true;
		$params['live_preview_button_text']   = $options['customize_button_text'] ?? __( 'Customize', 'woocommerce-live-preview' );
		$params['live_preview_allowed_fonts'] = $options['allowed_google_fonts'] ?? [];

		return $params;
	}

	/**
	 * Enqueue reg for the settings page.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		$screen = get_current_screen();

		if ( $screen->base === 'product_page_wpo_options' && filter_input( INPUT_GET, 'tab' ) === 'general' ) {
			wp_enqueue_style( 'barn2-tooltip', plugins_url( 'dependencies/barn2/barn2-lib/build/css/tooltip-styles.css', $this->plugin->get_file() ), [], $this->plugin->get_version() );
			wp_enqueue_script( 'barn2-tiptip', plugins_url( 'dependencies/barn2/barn2-lib/build/js/jquery-tiptip/jquery.tipTip.js', $this->plugin->get_file() ), [ 'jquery' ], $this->plugin->get_version(), true );
			wp_add_inline_script( 'barn2-tiptip', 'jQuery(document).ready(function() { jQuery(".barn2-help-tip").tipTip({ attribute:"data-tip"}); });' );

			wp_add_inline_script(
				'wpo-settings-page',
				'( ( $ ) => {
					$(document).ready( () => {
						jQuery( "select.wc-enhanced-select" ).select2(
							{
								minimumResultsForSearch: 10,
								closeOnSelect: false,
								dropdownAutoWidth: true,
								width: "calc(100% - 20px)",
								allowClear: true,
								scrollAfterSelect: false,
							}
						);
					} );
				} )( jQuery );',
			);
		} elseif ( $screen->base === 'upload' ) {
			wp_enqueue_media();
			wp_enqueue_script( 'wlp-editor' );
			wp_enqueue_style( 'wlp-editor' );
		}
	}

	/**
	 * Add CSS for the Google Fonts Select2 box.
	 *
	 * @return void
	 */
	public function add_live_preview_settings_css() {
		?>
		<style>
			select#wlp_live_preview\[allowed_google_fonts\] + .select2-container {
				.select2-selection__rendered {
					display: flex;
					overflow: hidden;
					padding-left: 8px;
					text-overflow: ellipsis;
					white-space: nowrap;
					flex-flow: wrap;
					gap: 5px;
					padding: 5px;

					li {
						list-style: none;
						margin: 0;
						padding: 5px;
					}
				
					.select2-selection__clear {
						cursor: pointer;
						position: absolute;
						float: none;
						font-weight: 700;
						margin-top: 5px;
						margin-right: 10px;
						top: 5px;
						right: 5px;
					}
					
					.select2-search__field {
						min-height: auto;
						margin: 0;
						padding: 0;
						line-height: 1;
						width: auto !important;
					}
				}
			}
		</style>
		<?php
	}
}
