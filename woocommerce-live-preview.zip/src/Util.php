<?php

namespace Barn2\Plugin\WC_Live_Preview;

use WP;
use WP_Error;

/**
 * The utility class.
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Util {

	/**
	 * Check if the assets should be registered.
	 *
	 * @return bool
	 */
	public static function is_preview_enabled() {
		$use_live_preview = false;

		if ( is_product() ) {
			$use_live_preview = true;
		}

		/**
		 * Filter whether the live preview functionality is in use.
		 *
		 * Normally, the condition for the live preview to be available
		 * is that the user is on a product page.
		 * However, this filter allows other plugins to enable the live preview
		 * functionality on other pages, such as the shop page or other custom pages.
		 *
		 * @param bool $use_live_preview Whether the live preview functionality is in use.
		 */
		return apply_filters( 'wc_live_preview_is_preview_enabled', $use_live_preview );
	}

	/**
	 * Get the full list of Google Fonts.
	 *
	 * @return array|WP_Error
	 */
	public static function get_google_fonts() {
		$wlp_options      = get_option( 'wlp_live_preview', [] );
		$api_key          = $wlp_options['google_fonts_api_key'] ?? '';
		$cache_key        = 'wlp_font_list_cached';
		$font_list_cached = $api_key ? get_transient( $cache_key ) : false;
		$font_json_file   = $api_key ? WP_CONTENT_DIR . '/cache/wlp_google_fonts.json' : '';

		if ( $font_list_cached === false || ! file_exists( $font_json_file ) ) {
			$wlp_options = get_option( 'wlp_live_preview', [] );
			$api_key     = $wlp_options['google_fonts_api_key'] ?? '';

			if ( empty( $api_key ) ) {
				return new WP_Error( 'wlp_google_fonts_error', __( 'Google Fonts API key is not set. Please go to Products > Product options > Settings and enter your Google Fonts API key.', 'woocommerce-live-preview' ) );
			}

			/**
			 * Filter the sorting parameter for the Google Fonts API.
			 *
			 * @param string $sort The sorting parameter for the Google Fonts API. Default: 'popularity'.
			 */
			$sort = apply_filters( 'wc_live_preview_google_fonts_sort', 'popularity' );

			/**
			 * Filter the limit for the Google Fonts API.
			 *
			 * @param int $limit The limit for the Google Fonts API. Default: 0 (no limit).
			 */
			$limit = apply_filters( 'wc_live_preview_google_fonts_limit', 0 );

			$google_fonts_url = add_query_arg(
				[
					'key'  => $api_key,
					'sort' => $sort,
				],
				"https://www.googleapis.com/webfonts/v1/webfonts"
			);

			if ( (int) $limit > 0 ) {
				$google_fonts_url = add_query_arg( 'limit', $limit, $google_fonts_url );
			}

			$response = wp_remote_get( $google_fonts_url );

			if ( is_wp_error( $response ) ) {
				return new WP_Error( 'wlp_google_fonts_error', __( 'Failed to fetch Google Fonts. Please check your API key and try again.', 'woocommerce-live-preview' ) );
			}

			$body = wp_remote_retrieve_body( $response );

			if ( empty( $body ) ) {
				return new WP_Error( 'wlp_google_fonts_error', __( 'No fonts found. Please check your API key and try again.', 'woocommerce-live-preview' ) );
			}

			$fonts = json_decode( $body, true );

			if ( empty( $fonts['items'] ) ) {
				return new WP_Error( 'wlp_google_fonts_error', __( 'No fonts found. Please check your API key and try again.', 'woocommerce-live-preview' ) );
			}

			$font_list = array_map(
				function ( $font ) {
					return array_intersect_key( $font, array_flip( [ 'category', 'family', 'menu', 'files' ] ) );
				},
				$fonts['items']
			);

			if ( ! file_exists( WP_CONTENT_DIR . '/cache/' ) ) {
				wp_mkdir_p( WP_CONTENT_DIR . '/cache/' );
			}

			// phpcs:ignore
			file_put_contents( $font_json_file, wp_json_encode( $font_list ) );
			set_transient( $cache_key, time(), DAY_IN_SECONDS );
		} else {
			// phpcs:ignore
			$font_list = json_decode( file_get_contents( $font_json_file ), true );
			if ( empty( $font_list ) ) {
				return new WP_Error( 'wlp_google_fonts_error', __( 'No fonts found. Please check your API key and try again.', 'woocommerce-live-preview' ) );
			}
		}

		return $font_list;
	}
}
