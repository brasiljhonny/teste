<?php

namespace Barn2\Plugin\WC_Live_Preview;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Plugin\Premium_Plugin;

/**
 * The main plugin class. Responsible for setting up to core plugin services.
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Plugin extends Premium_Plugin {
	const NAME           = 'WooCommerce Live Preview';
	const ITEM_ID        = 657851;
	const PARENT_ITEM_ID = 461766;
	const META_PREFIX    = 'wlp_';

	/**
	 * Constructs and initalizes the main plugin class.
	 *
	 * @param string $file    The root plugin __FILE__
	 * @param string $version The current plugin version
	 */
	public function __construct( $file = null, $version = '1.0' ) {
		parent::__construct(
			[
				'name'               => self::NAME,
				'item_id'            => self::ITEM_ID,
				'parent_item_id'     => defined( 'self::PARENT_ITEM_ID' ) ? constant( 'self::PARENT_ITEM_ID' ) : null,
				'version'            => $version,
				'file'               => $file,
				'is_woocommerce'     => true,
				'settings_path'      => 'edit.php?post_type=product&page=wpo_options&tab=general',
				'documentation_path' => 'kb-categories/live-preview-kb/',
			]
		);
	}

	/**
	 * Setup the plugin services
	 */
	public function add_services() {
		$this->add_service( 'plugin_setup', new Plugin_Setup( $this->get_file(), $this ), true );
		$this->maybe_activate_bonus_license();

		if ( $this->has_valid_license() ) {
			$this->add_service( 'admin_controller', new Admin\Admin_Controller( $this ) );

			$this->add_service( 'frontend_scripts', new Frontend_Scripts( $this ) );
			$this->add_service( 'handlers/single-product', new Handlers\Single_Product( $this ) );
			$this->add_service( 'handlers/item-data', new Handlers\Item_Data( $this ) );
			$this->add_service( 'rest', new Rest\Rest_Controller() );
			$this->add_service( 'integrations/quick-view', new Integrations\Quick_View( $this ) );
		}
	}

	/**
	 * Activate the bonus license if the plugin is part of a bundle
	 * and the parent license is active.
	 *
	 * @return void
	 */
	private function maybe_activate_bonus_license() {
		if ( is_null( $this->data['parent_item_id'] ) ) {
			return;
		}

		$plugin_license = $this->get_license();

		if ( ! $plugin_license->exists() || empty( $plugin_license->get_license_key() ) ) {
			add_filter( 'barn2_edd_licensing_api_request_args', [ $this, 'edd_licensing_api_request_args' ] );
			$parent_license_key = $this->get_parent_license_key();

			if ( $parent_license_key ) {
				$plugin_license->activate( $parent_license_key );
			}
		}
	}

	/**
	 * Filter the EDD licensing API request arguments.
	 *
	 * If the plugin is part of a bundle, use the parent license key
	 * to activate the bonus license.
	 *
	 * @param array $args The request arguments
	 * @return array
	 */
	public function edd_licensing_api_request_args( $args ) {
		if ( $args['body']['item_id'] === self::ITEM_ID && $args['body']['edd_action'] !== 'deactivate_license' ) {
			$parent_license_key = $this->get_parent_license_key();

			if ( ! $parent_license_key ) {
				delete_option( 'barn2_plugin_license_' . self::ITEM_ID );
				return $args;
			}

			$args['body']['license'] = $parent_license_key;
		}

		return $args;
	}

	/**
	 * Get the parent license key for the current plugin.
	 *
	 * If the plugin is part of a bundle as a child item, the parent license key
	 * is required to activate the bonus license.
	 *
	 * @return string|false
	 */
	private function get_parent_license_key() {
		$parent_license = get_option( 'barn2_plugin_license_' . $this->data['parent_item_id'], [] );
		$license_key    = $parent_license['license'] ?? '';

		if ( ! $license_key ) {
			return false;
		}

		$bonus_downloads = array_filter(
			$parent_license['bonus_downloads'] ?? [],
			function ( $download ) {
				return intval( $download->id ) === self::ITEM_ID;
			}
		);

		// The parent license doesn not include this plugin as a bonus download
		if ( empty( $bonus_downloads ) ) {
			return false;
		}

		return $license_key;
	}

	/**
	 * Check if the plugin has a valid license.
	 *
	 * Instead of checking the validity of the plugin's license,
	 * this method checks the validity of the parent license.
	 *
	 * @return bool
	 */
	public function has_valid_license() {
		return true;
		if ( is_null( $this->data['parent_item_id'] ) ) {
			return false;
		}

		$parent_license = get_option( 'barn2_plugin_license_' . $this->data['parent_item_id'], [] );

		if ( ! $parent_license ) {
			return false;
		}

		$parent_license_status = $parent_license['status'] ?? '';
		$bonus_downloads       = array_filter(
			$parent_license['bonus_downloads'] ?? [],
			function ( $download ) {
				return intval( $download->id ) === self::ITEM_ID;
			}
		);

		return ! empty( $bonus_downloads ) && in_array( $parent_license_status, [ 'active', 'expired' ], true );
	}
}
