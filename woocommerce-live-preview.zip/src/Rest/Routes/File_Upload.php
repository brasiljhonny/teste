<?php

namespace Barn2\Plugin\WC_Live_Preview\Rest\Routes;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Rest\Base_Route;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Rest\Route;
use WP_Error;
use WP_REST_Response;
use WP_REST_Server;

use const WC_ABSPATH;

/**
 * REST controller for the uploading files from the frontend.
 *
 * @package   Barn2\woocommerce-product-options
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class File_Upload extends Base_Route implements Route {

	protected $rest_base = 'file-upload';

	/**
	 * Register the REST routes.
	 */
	public function register_routes() {

		// CREATE.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
			]
		);

	}

	/**
	 * Upload file.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function create( $request ) {
		$product_id = $request->get_param( 'product_id' );

		if ( strpos( 'product', get_post_type( $product_id ) ) !== 0 ) {
			return new WP_Error( 'wpo_file_upload_error', __( 'The associated product was not provided.', 'woocommerce-live-preview' ) );
		}

		$custom_upload_dir = $this->custom_upload_dir();
		$file_format       = $request->get_param( 'file_format' ) ?? 'png';
		$file_name         = md5( $request->get_param( 'file_data' ) ) . '.' . $file_format;
		$file_data         = base64_decode( $request->get_param( 'file_data' ) );
		$file_path         = "{$custom_upload_dir['dir']}/$file_name";
		$file_url          = "{$custom_upload_dir['url']}/$file_name";

		if ( ! file_exists( $custom_upload_dir['dir'] ) ) {
			mkdir( $custom_upload_dir['dir'], 0755, true );
		}

		if ( file_put_contents( $file_path, $file_data ) === false ) {
			return new WP_Error( 'wpo_file_upload_error', __( 'Failed to upload file.', 'woocommerce-live-preview' ) );
		}

		$stat  = stat( dirname( $file_path ) );
		$perms = $stat['mode'] & 0000666;
		chmod( $file_path, $perms );

		// add path to unlinked files option
		$unlinked_files = get_option( 'wpo_unlinked_files', [] );

		if ( ! in_array( $file_url, $unlinked_files, true ) ) {
			$unlinked_files[] = $file_url;
			update_option( 'wpo_unlinked_files', $unlinked_files );
		}

		return new WP_REST_Response( $file_url, 200 );
	}

	public function delete( $request ) {
		$file_path = $request->get_param( 'file_url' );

		if ( ! $file_path ) {
			return new WP_Error( 'wpo_file_delete_error', __( 'Insufficient data supplied.', 'woocommerce-live-preview' ) );
		}

		$upload_dir     = wp_upload_dir();
		$wpo_upload_dir = $upload_dir['basedir'] . '/wpo-uploads';

		if ( strpos( $file_path, $wpo_upload_dir ) === false ) {
			return new WP_Error( 'wpo_file_delete_error', __( 'You are not allowed to delete files in this folder.', 'woocommerce-live-preview' ) );
		}

		$files = get_option( 'wpo_unlinked_files', [] );

		if ( in_array( $file_path, $files, true ) ) {
			wp_delete_file( $file_path );

			// remove folder if empty
			$folder = dirname( $file_path );

			if ( ! glob( $folder . '/*' ) ) {
				rmdir( $folder );
			}

			// remove from unlinked files
			$files = array_diff( $files, [ $file_path ] );

			update_option( 'wpo_unlinked_files', $files );
		}

		return new WP_REST_Response( [ 'message' => 'File deleted successfully.' ], 200 );
	}

	/**
	 * Custom upload directory.
	 *
	 * @return array $path_data
	 */
	public function custom_upload_dir(): array {

		// require wc-cart-functions for session shutdown
		require_once WC_ABSPATH . 'includes/wc-cart-functions.php';
		require_once WC_ABSPATH . 'includes/wc-notice-functions.php';

		if ( null === WC()->session ) {
			$session_class = apply_filters( 'woocommerce_session_handler', 'WC_Session_Handler' );

			// Prefix session class with global namespace if not already namespaced
			if ( false === strpos( $session_class, '\\' ) ) {
				$session_class = '\\' . $session_class;
			}

			WC()->session = new $session_class();
			WC()->session->init();
		}

		$path_data   = wp_upload_dir();
		$wpo_dir     = 'wpo-uploads';
		$session_dir = hash( 'md5', WC()->session->get_customer_id() );

		return [
			'dir' => "{$path_data['basedir']}/$wpo_dir/$session_dir",
			'url' => "{$path_data['baseurl']}/$wpo_dir/$session_dir",
		];
	}

	/**
	 * Permission callback.
	 *
	 * @return bool
	 */
	public function permission_callback() {
		return true;
	}
}
