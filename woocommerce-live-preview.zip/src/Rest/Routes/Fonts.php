<?php

namespace Barn2\Plugin\WC_Live_Preview\Rest\Routes;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Rest\Base_Route;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Rest\Route;
use Barn2\Plugin\WC_Live_Preview\Util;
use WP_Error;
use WP_REST_Response;
use WP_REST_Server;

/**
 * REST controller for the retrieval of Google Fonts.
 *
 * @package   Barn2\woocommerce-product-options
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Fonts extends Base_Route implements Route {

	protected $rest_base = 'fonts';

	/**
	 * Register the REST routes.
	 */
	public function register_routes() {
		// GET.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get' ],
					'permission_callback' => [ $this, 'permission_callback' ],
				],
			]
		);
	}

	/**
	 * Get a list of Google fonts, sorted by popularity, using the Google Fonts API.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function get( $request ) {
		$font_list = array_merge( $this->get_google_fonts(), $this->get_custom_fonts() );

		return new WP_REST_Response( array_values( $font_list ), 200 );
	}

	/**
	 * Get the list of Google Fonts.
	 *
	 * @return array
	 */
	private function get_google_fonts() {
		$google_fonts = Util::get_google_fonts();

		if ( is_wp_error( $google_fonts ) ) {
			return [];
		}

		$allowed_fonts = get_option( 'wlp_live_preview', [] )['allowed_google_fonts'] ?? [];

		if ( ! empty( $allowed_fonts ) ) {
			$google_fonts = array_filter(
				$google_fonts,
				function ( $font ) use ( $allowed_fonts ) {
					return in_array( $font['family'], $allowed_fonts, true );
				}
			);
		}

		return $google_fonts;
	}

	/**
	 * Get the list of custom fonts.
	 *
	 * @return array
	 */
	private function get_custom_fonts() {
		$custom_fonts = apply_filters( 'wlp_live_preview_custom_fonts', [] );

		if ( ! is_array( $custom_fonts ) ) {
			return [];
		}

		return array_values(
			array_filter(
				$custom_fonts,
				function ( $font ) {
					return ! empty( $font['family'] ) && ! empty( $font['files'] );
				}
			)
		);
	}

	/**
	 * Permission callback.
	 *
	 * @return bool
	 */
	public function permission_callback() {
		return true;
	}
}
