<?php
/**
 * Toolbar for text objects
 *
 * This template is used to render the toolbar for text objects..
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 *
 * @since 1.1.0
 */

?>

<template id="wlp-text-toolbar">
	<div id="wlp-preview-text-toolbar" class="toolbar" hidden>
		<!-- Font Family -->
		<select id="font-family" title="<?php esc_html_e( 'Font Family', 'woocommerce-live-preview' ); ?>"></select>

		<!-- Font Size -->
		<input id="font-size" type="number" value="24" title="<?php esc_html_e( 'Font Size', 'woocommerce-live-preview' ); ?>" min="1" step="1" />

		<!-- Font Style -->
		<div class="buttons-style">
			<button class="icon-button" id="bold-btn" title="<?php esc_html_e( 'Bold', 'woocommerce-live-preview' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="#e3e3e3"><path d="M293.54-215v-530H488q61.15 0 110.58 38.08Q648-668.85 648-604.38q0 44.84-21.66 73.11-21.65 28.27-46.65 41.04 30.77 10.61 58.77 41.96 28 31.35 28 84.42 0 76.69-56.54 112.77T496-215H293.54Zm86-79.69h113.23q47.23 0 66.77-26.23t19.54-50.31q0-24.08-19.54-50.31-19.54-26.23-68.62-26.23H379.54v153.08Zm0-230.31h103.77q36.46 0 57.81-20.85 21.34-20.84 21.34-49.92 0-30.92-22.57-50.54-22.58-19.61-55.35-19.61h-105V-525Z"/></svg>
			</button>
			<button class="icon-button" id="italic-btn" title="<?php esc_html_e( 'Italic', 'woocommerce-live-preview' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="#e3e3e3"><path d="M215.77-215v-72.31h152.69l129.62-385.38H345.39V-745h366.15v72.31H571.15L441.54-287.31h140.38V-215H215.77Z"/></svg>
			</button>
			<button class="icon-button" id="underline-btn" title="<?php esc_html_e( 'Underline', 'woocommerce-live-preview' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="#e3e3e3"><path d="M213.85-155v-60h532.3v60h-532.3ZM480-298.85q-93.31 0-145.65-56.65Q282-412.15 282-507.31v-316.15h74.15v319.84q0 60.62 32.23 97.16T480-369.92q59.39 0 91.62-36.54 32.23-36.54 32.23-97.16v-319.84H678v316.15q0 95.16-52.35 151.81-52.34 56.65-145.65 56.65Z"/></svg>
			</button>
		</div>

		<!-- Text Alignment -->
		<div class="buttons-align">
			<button class="icon-button align-button" id="align-left-btn" title="<?php esc_html_e( 'Align Left', 'woocommerce-live-preview' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="#e3e3e3"><path d="M140-140v-60h680v60H140Zm0-155v-60h440v60H140Zm0-155v-60h680v60H140Zm0-155v-60h440v60H140Zm0-155v-60h680v60H140Z"/></svg>
			</button>
			<button class="icon-button align-button" id="align-center-btn" title="<?php esc_html_e( 'Align Center', 'woocommerce-live-preview' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="#e3e3e3"><path d="M140-140v-60h680v60H140Zm160-155v-60h360v60H300ZM140-450v-60h680v60H140Zm160-155v-60h360v60H300ZM140-760v-60h680v60H140Z"/></svg>
			</button>
			<button class="icon-button align-button" id="align-right-btn" title="<?php esc_html_e( 'Align Right', 'woocommerce-live-preview' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="#e3e3e3"><path d="M140-760v-60h680v60H140Zm240 155v-60h440v60H380ZM140-450v-60h680v60H140Zm240 155v-60h440v60H380ZM140-140v-60h680v60H140Z"/></svg>
			</button>
		</div>

		<!-- Color Picker -->
		<input type="color" id="text-color" class="color-picker" value="#005588" title="<?php esc_html_e( 'Text Color', 'woocommerce-live-preview' ); ?>" />
	</div>
</template>