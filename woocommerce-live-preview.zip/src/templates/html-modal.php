<?php
/**
 * Live preview modal template
 *
 * This template is used to render the live preview modal.
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 *
 * @since 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$primary_button_class = wp_is_block_theme()
	? 'wp-element-button alt'
	: 'button button-primary alt';

$secondary_button_class = wp_is_block_theme()
	? 'wp-element-button button is-style-outline'
	: 'button button-secondary';
?>

<template id="wlp-modal-template">
	<div id="wlp-live-preview-overlay">
		<div id="wlp-live-preview-modal">
			<div id="wlp-live-preview-wrapper">
				<div id="wlp-live-preview-container">
					<div class="wlp-canvas-editor">
						<canvas id="wlp-live-preview-canvas"></canvas>
						<span class="wlp-prev-image" data-index="null" style="display: none;">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" fill="currentColor"><path d="M560-240 320-480l240-240 56 56-184 184 184 184-56 56Z"/></svg>
						</span>
						<span class="wlp-next-image" data-index="null" style="display: none;">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" fill="currentColor"><path d="M504-480 320-664l56-56 240 240-240 240-56-56 184-184Z"/></svg>
						</span>
					</div>
					<div id="wlp-live-preview-catalog">
						<ul id="wlp-catalog"></ul>
					</div>
					<div class="wlp-live-preview-toolbar">
						<label class="wlp-live-preview-modal-option" for="wlp-live-preview-show-masks">
							<input type="checkbox" id="wlp-live-preview-show-masks" checked="">
							<span class="label-text">
								<svg class="selected" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor"><path d="m424-312 282-282-56-56-226 226-114-114-56 56 170 170ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/></svg>
								<svg class="unselected" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Z"/></svg>
								<?php esc_html_e( 'Show printable areas', 'woocommerce-live-preview' ); ?>
							</span>
						</label>
						<div class="wlp-live-preview-toolbar-buttons">
							<button type="button" id="wlp-live-preview-apply" class="<?php echo esc_attr( $primary_button_class ); ?>"><?php esc_html_e( 'Apply', 'woocommerce-live-preview' ); ?></button>
							<button type="button" id="wlp-live-preview-cancel" class="<?php echo esc_attr( $secondary_button_class ); ?>"><?php esc_html_e( 'Cancel', 'woocommerce-live-preview' ); ?></button>
						</div>
					</div>
				</div>
				<button class="wlp-live-preview-close">
					<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg>
				</button>
			</div>
		</div>
	</div>
</template>
