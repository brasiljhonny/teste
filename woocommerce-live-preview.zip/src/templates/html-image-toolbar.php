<?php
/**
 * Toolbar for text objects
 *
 * This template is used to render the toolbar for text objects..
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 *
 * @since 1.1.0
 */

?>

<template id="wlp-image-toolbar">
	<div id="wlp-preview-image-toolbar" class="toolbar" hidden>
	</div>
</template>