<?php
/**
 * Catalog file template
 *
 * This template is used to render a file in the live preview catalog.
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 *
 * @since 1.0.0
 */

?>

<template id="wlp-catalog-item">
	<ul>
		<li class="wlp-catalog-item is-image" draggable="true">
			<span class="wlp-catalog-item-option"></span>
			<img class="wlp-catalog-item-image item-info">
			<div class="wlp-catalog-item-details item-info">
				<span class="wlp-catalog-item-file item-info"></span>
				<span class="wlp-catalog-item-size item-info"></span>
			</div>
		</li>
		<li class="wlp-catalog-item is-text" draggable="true">
			<span class="wlp-catalog-item-option"></span>
			<input class="wlp-catalog-item-text item-info" type="text" value="" />
		</li>
		<li class="wlp-catalog-item is-textarea" draggable="true">
			<span class="wlp-catalog-item-option"></span>
			<textarea class="wlp-catalog-item-text item-info"></textarea>
		</li>
	</ul>
</template>
