<?php

namespace Barn2\Plugin\WC_Live_Preview\Handlers;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Live_Preview\Util;

/**
 * Handles the integration with the single product page.
 *
 * @package   Barn2\woocommerce-live-preview
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Single_Product implements Registerable, Standard_Service {

	private $plugin;
	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin
	 */
	public function __construct( $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * {@inheritdoc}
	 */
	public function register(): void {
		add_filter( 'woocommerce_gallery_image_html_attachment_image_params', [ $this, 'add_mask_to_product_image' ], 10, 2 );
		add_filter( 'woocommerce_single_product_image_thumbnail_html', [ $this, 'add_printable_areas_to_html_image' ], 10, 2 );
		add_action( 'wp_footer', [ $this, 'print_template' ] );
		add_filter( 'woocommerce_available_variation', [ $this, 'add_printable_areas_to_available_variation' ] );
	}

	/**
	 * Get the printable areas for the given attachment.
	 *
	 * @param int $attachment_id
	 * @return array|null
	 */
	private function get_printable_areas( $attachment_id ) {
		$printable_areas = get_post_meta( $attachment_id, '_wlp_printable_areas', true );

		if ( ! $printable_areas ) {
			return null;
		}

		$printable_areas['options'] = $printable_areas['options'] ?? [];
		$printable_areas['areas']   = $printable_areas['areas'] ?? [];
		$default_area_options       = $printable_areas['options'];
		unset( $default_area_options['variations'] );

		foreach ( $printable_areas['areas'] as $key => $area ) {
			$printable_areas['areas'][ $key ]['options'] = array_map(
				function ( $value ) {
					if ( is_numeric( $value ) ) {
						return floatval( $value );
					}

					if ( $value === 'true' || $value === 'false' ) {
						return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
					}

					return $value;
				},
				$area['options'] ?? $default_area_options
			);
		}

		$printable_areas['options'] = $printable_areas['options'] ?? [];

		foreach ( $printable_areas['options'] as $key => $option ) {
			$filter = FILTER_VALIDATE_BOOLEAN;

			if ( $key === 'assigned_options' ) {
				$filter = FILTER_DEFAULT;
			}

			$printable_areas['options'][ $key ] = filter_var( $option, $filter );
		}

		return $printable_areas;
	}

	/**
	 * Add the printable areas and options to the attributes of the product image.
	 *
	 * @param array $params
	 * @param int   $attachment_id
	 * @return array
	 */
	public function add_mask_to_product_image( $params, $attachment_id ) {
		$printable_areas = $this->get_printable_areas( $attachment_id );

		if ( ! $printable_areas ) {
			return $params;
		}

		$params['data-printable-areas']   = wp_json_encode( $printable_areas['areas'] ?? [] );
		$params['data-printable-options'] = wp_json_encode( $printable_areas['options'] ?? [] );

		return $params;
	}

	/**
	 * Print the modal template.
	 *
	 * @return void
	 */
	public function print_template() {
		if ( ! Util::is_preview_enabled() ) {
			return;
		}

		include $this->plugin->get_dir_path() . 'src/templates/html-modal.php';
		include $this->plugin->get_dir_path() . 'src/templates/html-catalog-item.php';
		include $this->plugin->get_dir_path() . 'src/templates/html-text-toolbar.php';
	}

	/**
	 * Add the printable areas to the available variation data.
	 *
	 * @param array $data
	 * @return array
	 */
	public function add_printable_areas_to_available_variation( $data ) {
		$printable_areas = $this->get_printable_areas( $data['image_id'] );

		if ( ! $printable_areas && wp_doing_ajax() ) {
			// if the request doesn't involve Live Preview, return the data as is
			// so we avoid unnecessary processing for unrelated requests
			if ( filter_input( INPUT_POST, 'isLivePreview', FILTER_VALIDATE_INT ) !== 1 ) {
				return $data;
			}

			// The current request is an ajax request.
			// This means we are loading one variation at a time via ajax.
			// We need to find the parent product id and search for a variation image
			// that has printable areas.
			$parent_id      = wp_get_post_parent_id( $data['variation_id'] );
			$parent_product = wc_get_product( $parent_id );

			if ( $parent_product ) {
				foreach ( $parent_product->get_children() as $variation_id ) {
					$global_areas = $this->get_printable_areas( $this->get_variation_image_id( $variation_id ) );

					if ( $global_areas && $global_areas['options']['variations'] === true ) {
						// we found a variation image with printable areas extended to all variations
						// NOTE: only one image should have printable areas extended to all variations
						// if that is not the case, it can lead to unexpected behavior
						$printable_areas = $global_areas;
						break;
					}
				}
			}
		}

		if ( ! $printable_areas ) {
			return $data;
		}

		$data['image']['printable_areas'] = $printable_areas;

		return $data;
	}

	/**
	 * Get the image id of a variation.
	 *
	 * @param int $variation_id
	 * @return int|null
	 */
	private function get_variation_image_id( $variation_id ) {
		$variation = wc_get_product( $variation_id );

		if ( ! $variation ) {
			return null;
		}

		return $variation->get_image_id();
	}

	/**
	 * Add data attributes to the HTML markup of a product image, if not present already.
	 *
	 * This is necessary for the live preview to work
	 * with themes that don't use the standard WooCommerce hooks.
	 * Specifically, the ones that do not use `woocommerce_gallery_image_html_attachment_image_params`.
	 *
	 * @param string $html
	 * @param int    $attachment_id
	 * @return string
	 */
	public function add_printable_areas_to_html_image( $html, $attachment_id ) {
		if ( strpos( $html, 'data-printable-areas' ) !== false ) {
			return $html;
		}

		$printable_areas = $this->get_printable_areas( $attachment_id );

		if ( ! $printable_areas ) {
			return $html;
		}

		$extra_data = htmlspecialchars(
			sprintf(
				'data-printable-areas=%1$s data-printable-options=%2$s',
				wp_json_encode( $printable_areas['areas'] ?? [] ),
				wp_json_encode( $printable_areas['options'] ?? [] )
			),
			ENT_QUOTES,
			'UTF-8'
		);

		return preg_replace( '/<img\b([^>]*?)>/i', '<img\1 ' . $extra_data . '>', $html );
	}
}
