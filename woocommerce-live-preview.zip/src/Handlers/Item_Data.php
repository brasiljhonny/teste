<?php

namespace Barn2\Plugin\WC_Live_Preview\Handlers;

use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Live_Preview\Dependencies\Lib\Service\Standard_Service;

/**
 * Handles adding and displaying the product options item data.
 *
 * @package   Barn2\woocommerce-product-options
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Item_Data implements Registerable, Standard_Service {

	/**
	 * The text properties names.
	 *
	 * @var array
	 */
	public $prop_names = [];

	/**
	 * Whether the page requires the inline style for the text properties.
	 *
	 * @var bool
	 */
	public $text_prop_style = false;

	/**
	 * Register hooks and filters.
	 */
	public function register() {
		$this->prop_names = [
			'fontFamily' => __( 'Font', 'woocommerce-live-preview' ),
			'color'      => __( 'Color', 'woocommerce-live-preview' ),
			'fontWeight' => __( 'Weight', 'woocommerce-live-preview' ),
			'fontStyle'  => __( 'Style', 'woocommerce-live-preview' ),
			'underline'  => __( 'Underline', 'woocommerce-live-preview' ),
			'textAlign'  => __( 'Alignment', 'woocommerce-live-preview' ),
		];

		add_filter( 'woocommerce_add_cart_item_data', [ $this, 'add_cart_item_data' ], 30, 3 );
		add_filter( 'woocommerce_cart_item_thumbnail', [ $this, 'cart_item_thumbnail' ], 10, 2 );
		add_filter( 'woocommerce_get_item_data', [ $this, 'display_cart_item_data' ], 30, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', [ $this, 'add_order_item_data' ], 30, 4 );

		add_filter( 'woocommerce_order_again_cart_item_data', [ $this, 'order_again_cart_item_data' ], 30, 3 );

		add_action( 'admin_footer', [ $this, 'add_text_properties_style' ] );
		add_action( 'wp_footer', [ $this, 'add_text_properties_style' ] );
	}


	/**
	 * Add product options data to item inside the cart.
	 *
	 * @param array $cart_item_data
	 * @param int   $product_id
	 * @param int   $variation_id
	 * @return array
	 */
	public function add_cart_item_data( $cart_item_data, $product_id, $variation_id ): array {
		$product = $variation_id === 0 ? wc_get_product( $product_id ) : wc_get_product( $variation_id );

		if ( ! $product ) {
			return $cart_item_data;
		}

		$post_var_name   = $variation_id ? 'variation_id' : 'add-to-cart';
		$main_product_id = (int) filter_input( INPUT_POST, $post_var_name, FILTER_SANITIZE_NUMBER_INT );

		if ( $main_product_id !== $product_id && $main_product_id !== $variation_id ) {
			// The product being added to the cart is not the main product.
			// This is likely a product added as a product option.
			return $cart_item_data;
		}

		$preview_files = filter_input( INPUT_POST, 'wlp-preview-files', FILTER_DEFAULT );

		if ( empty( $preview_files ) ) {
			return $cart_item_data;
		}

		$cart_item_data['wlp_preview_files'] = $preview_files;

		// Get the text properties array from the form submission.
		$text_properties = filter_input( INPUT_POST, 'wlp-text-preview', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );

		if ( ! empty( $text_properties ) ) {
			foreach ( $text_properties as $key => $value ) {
				// Decode the JSON string and add it to the cart item data.
				$text_properties[ $key ] = json_decode( $value, true );
			}
			$cart_item_data['wlp_text_properties'] = $text_properties;
		}

		return $cart_item_data;
	}

	/**
	 * Display product options data in the cart and checkout.
	 *
	 * @param array $item_data
	 * @param array $cart_item
	 *
	 * @return array
	 */
	public function display_cart_item_data( $item_data, $cart_item ): array {
		if ( ! isset( $cart_item['wlp_preview_files'] ) ) {
			return $item_data;
		}

		$live_preview_options = get_option( 'wlp_live_preview', [] );
		$preview_label        = $live_preview_options['cart_label'] ?? __( 'Preview', 'woocommerce-live-preview' );

		/**
		 * Filter the label used for preview files on the cart and checkout pages.
		 *
		 * @param string $preview_label
		 * @param array $item_data
		 * @param array $cart_item
		 */
		$preview_label = apply_filters( 'wc_live_preview_item_data_preview_label', $preview_label ?: __( 'Preview', 'woocommerce-live-preview' ), $item_data, $cart_item );

		$item_data[] = [
			'key'   => $preview_label,
			'value' => $this->format_preview_files( $cart_item['wlp_preview_files'] ),
		];

		return $item_data;
	}

	/**
	 * Replace the product thumbnail with the preview files in the cart.
	 *
	 * @param string $product_thumbnail
	 * @param array  $cart_item
	 * @return string
	 */
	public function cart_item_thumbnail( $product_thumbnail, $cart_item ) {
		if ( ! isset( $cart_item['wlp_preview_files'] ) ) {
			return $product_thumbnail;
		}

		$preview_files  = explode( ',', $cart_item['wlp_preview_files'] );
		$preview_files  = array_map( 'esc_url', $preview_files );
		$html           = '';
		$display        = true;
		$display_hidden = '';
		$product        = $cart_item['data'];

		foreach ( $preview_files as $src ) {
			if ( ! $display ) {
				$display_hidden = ' style="display: none;"';
			}

			$html   .= sprintf(
				'<a href="%1$s" target="_blank" title="%2$s"><img class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" src="%3$s" alt="%2$s"%4$s></a>',
				$product->get_permalink(),
				$product->get_title(),
				$src,
				$display_hidden
			);
			$display = false;
		}

		return $html;
	}


	/**
	 * Add product options data to order item.
	 *
	 * @param WC_Order_Item_Product $item
	 * @param string                $cart_item_key
	 * @param array                 $cart_item
	 * @param WC_Order              $order
	 */
	public function add_order_item_data( $item, $cart_item_key, $cart_item, $order ): void {

		if ( ! isset( $cart_item['wlp_preview_files'] ) || empty( $cart_item['wlp_preview_files'] ) ) {
			return;
		}

		$files = explode( ',', $cart_item['wlp_preview_files'] );
		$item->add_meta_data( '_wlp_preview_files', $files );
		$preview_files_name = __( 'Preview Files', 'woocommerce-live-preview' );
		$item->add_meta_data( $preview_files_name, $this->format_preview_files( $files ) );

		$text_properties = $cart_item['wlp_text_properties'] ?? [];

		if ( ! empty( $text_properties ) ) {
			$item->add_meta_data( '_wlp_text_properties', $text_properties );
			$item->add_meta_data( __( 'Text Properties', 'woocommerce-live-preview' ), $this->format_text_properties( $text_properties, $cart_item ) );
		}

		// remove from unlinked files option
		$unlinked_files = get_option( 'wpo_unlinked_files', [] );

		foreach ( $files as $file ) {
			if ( ( $key = array_search( $file, $unlinked_files, true ) ) !== false ) {
				unset( $unlinked_files[ $key ] );
			}
		}

		update_option( 'wpo_unlinked_files', $unlinked_files );

		// add to current files order option
		$current_files = $order->get_meta( '_wlp_preview_files' );

		if ( ! empty( $current_files ) ) {
			$files = array_merge( $current_files, $files );
		}

		$order->update_meta_data( '_wlp_preview_files', $files );
		$order->update_meta_data( '_wlp_text_properties', $text_properties );
		$order->save();
	}

	/**
	 * Return the HTML markup of the preview files in the cart/checkout pages.
	 *
	 * @param array $preview_files
	 * @return string
	 */
	private function format_preview_files( $preview_files ) {
		$html = '<ul class="wpo-image-grid">';

		if ( is_string( $preview_files ) ) {
			$preview_files = explode( ',', $preview_files );
		}

		foreach ( $preview_files as $url ) {
			$data_pswp = 'data-pswp-width="600" data-pswp-height="600"';
			$file      = str_replace( wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $url );
			$size      = wp_getimagesize( $file );

			if ( $size ) {
				$data_pswp = sprintf( ' data-pswp-width="%1$s" data-pswp-height="%2$s"', $size[0], $size[1] );
			}

			$html .= sprintf(
				'<li><a href="%1$s" target="_blank"%3$s><img class="wlp-preview-cart-thumbnail" width="%4$s" height="auto" src="%1$s" alt="%2$s"></a></li>',
				$url,
				basename( $url ),
				$data_pswp,
				/**
				 * Filter the thumbnail width of the preview files in the cart, checkout, order confirmation page and email.
				 *
				 * This width will be used as the `width` attribute of the image element, with `height` set to `auto`.
				 *
				 * @param int $thumbnail_width
				 */
				apply_filters( 'wlp_cart_item_preview_image_width', 60 )
			);
		}

		$html .= '</ul>';

		return $html;
	}

	/**
	 * Return the HTML markup of the text properties in the cart/checkout pages.
	 *
	 * @param array $text_properties
	 * @return string
	 */
	private function format_text_properties( $text_properties, $cart_item ) {
		$wpo_options = $cart_item['wpo_options'] ?? [];

		$html = '<ul class="wlp-text-properties">';

		if ( is_string( $text_properties ) ) {
			$text_properties = explode( ',', $text_properties );
		}

		foreach ( $text_properties as $key => $value ) {
			$option_name = $wpo_options[ $key ]['name'] ?? $key;

			if ( is_array( $value ) ) {
				$html .= '<li>';
				$html .= '<span>' . esc_html( $option_name ) . '</span>';
				$html .= '<dl class="wlp-text-property-details">';

				foreach ( $value as $sub_key => $sub_value ) {
					$prop_name  = $this->prop_names[ $sub_key ] ?? $sub_key;
					$prop_value = $value[ $sub_key ];

					if ( $sub_key === 'underline' ) {
						$prop_value = filter_var( $prop_value, FILTER_VALIDATE_BOOLEAN ) ? __( 'Yes', 'woocommerce-live-preview' ) : __( 'No', 'woocommerce-live-preview' );
					}

					$value[ $sub_key ] = is_array( $sub_value ) ? implode( ', ', $sub_value ) : $sub_value;
					$html             .= sprintf(
						'<dt>%1$s</dt><dd>%2$s</dd>',
						esc_html( $prop_name ),
						esc_html( $prop_value )
					);
				}

				$html .= '</dl>';
				$html .= '</li>';
			} else {
				$html .= sprintf(
					'<li><span>%1$s</span><dl class="wlp-text-property-details"><dt>%2$s</dt></dl></li>',
					esc_html( $key ),
					esc_html( $value )
				);
			}
		}

		$html .= '</ul>';

		return $html;
	}

	/**
	 * Add the style for the text properties.
	 */
	public function add_text_properties_style() {
		if ( is_admin() ) {
			$screen = get_current_screen();

			if ( $screen->base !== 'woocommerce_page_wc-orders' ) {
				return;
			}
		} else {

		}
		?>
		<style>
			ul.wlp-text-properties {
				& {
					display: flex;
					flex-flow: wrap;
					margin: 0;
					font-size: 12px;
					gap: 10px;
				}
				li {
					&::marker {
						content: none;
					}

					span {
						font-weight: 600;
						display: block;
						border-bottom: 1px solid;
					}

					dl.wlp-text-property-details {
						& {
							display:grid;
							grid-template-columns: auto 1fr;
							grid-gap: 0 .5em;
						}
						dt{
							font-weight: 400;
							margin: 0;
							padding: 0;
							text-transform: lowercase;
						}
						dd{
							margin: 0;
							font-weight: 600;
							text-transform: capitalize;
						}
					}
				}
			}
		</style>
		<?php
	}

	/**
	 * Add preview files data to cart item when ordering again.
	 *
	 * @param array $cart_item_data
	 * @param WC_Order_Item_Product $item
	 * @param WC_Order $order
	 * @return array $cart_item_data
	 */
	public function order_again_cart_item_data( $cart_item_data, $item, $order ) {
		$preview_files = $item->get_meta( '_wlp_preview_files' );

		if ( empty( $preview_files ) ) {
			return $cart_item_data;
		}

		$cart_item_data['wlp_preview_files'] = implode( ',', $preview_files );

		return $cart_item_data;
	}
}
