(function(){
  function until(cond, cb, timeoutMs=8000, step=100){
    const t0 = Date.now();
    (function spin(){
      if (cond()) return cb();
      if (Date.now()-t0 > timeoutMs) return cb(new Error('timeout LivePreview core'));
      setTimeout(spin, step);
    })();
  }

  function getCore(){
    try{ return window.LivePreview?.core || null; }catch(e){ return null; }
  }

  function coalesce(v, d){ return (v===undefined||v===null||v==='') ? d : v; }

  function readPropsFromForm(map, defs){
    const props = {};
    (map||[]).forEach(item=>{
      const el = document.querySelector(item.selector);
      if(!el) return;
      let val = (el.type==='color' || el.type==='select-one' || el.type==='text' || el.type==='textarea')
        ? el.value : el.getAttribute('value');
      if(item.prop==='fontFamily' && !val) val = (defs||{}).fontFamily;
      if(item.prop==='fill' && !val) val = (defs||{}).fill;
      if(item.prop==='text' && !val) val = '';
      props[item.prop] = val;
      props.optionId   = item.optionId || 101;
    });

    props.fontFamily    = coalesce(props.fontFamily, (defs||{}).fontFamily);
    props.fill          = coalesce(props.fill, (defs||{}).fill);
    props.text          = coalesce(props.text, '');
    props.fontSize      = coalesce(props.fontSize, (defs||{}).fontSize);
    props.fontWeight    = coalesce(props.fontWeight, (defs||{}).fontWeight);
    props.textAlign     = coalesce(props.textAlign, (defs||{}).textAlign);
    props.letterSpacing = coalesce(props.letterSpacing, (defs||{}).letterSpacing);
    props.anchorX       = coalesce(props.anchorX, (defs||{}).anchorX);
    props.anchorY       = coalesce(props.anchorY, (defs||{}).anchorY);

    return props;
  }

  function attach(core){
    const { ui } = core;
    const cfg  = window.WLP_BRIDGE_CFG || {};
    const map  = cfg.fields || [];
    const defs = cfg.defaults || {};

    if(cfg.forceInline && ui && typeof ui.open === 'function'){
      const originalOpen = ui.open;
      ui.open = function(){
        try{
          ui.updateCatalog?.();
          ui.updateCanvas?.().then(()=>{ ui.redraw?.(); ui.resetZoom?.(); });
        }catch(e){}
      };
    }

    function applyInline(){
      try{
        const props = readPropsFromForm(map, defs);
        if(!props) return;

        const optionId = parseInt(props.optionId || 101, 10);
        const form = document.querySelector('form.cart') || document.body;
        const name = `wlp-text-preview[${optionId}]`;
        let hidden = form.querySelector(`input[name="${name}"]`);
        if(!hidden){
          hidden = document.createElement('input');
          hidden.type = 'hidden';
          hidden.name = name;
          form.appendChild(hidden);
        }

        const textProps = {
          optionId: optionId,
          text: (props.text||'').toString(),
          fill: props.fill,
          fontFamily: props.fontFamily,
          fontSize: parseFloat(props.fontSize)||defs.fontSize,
          fontWeight: props.fontWeight,
          textAlign: props.textAlign,
          charSpacing: (props.letterSpacing||0) * 100,
          anchor: { x: parseFloat(props.anchorX)||50, y: parseFloat(props.anchorY)||50 },
        };

        hidden.value = JSON.stringify(textProps);

        ui.updateCatalog?.();
        ui.updateCanvas?.().then(()=>{ ui.redraw?.(); });
      }catch(e){}
    }

    const selectors = (map||[]).map(m=>m.selector).filter(Boolean);
    const els = selectors.map(sel=>Array.from(document.querySelectorAll(sel))).flat();
    els.forEach(el=>{
      ['change','input','keyup'].forEach(evt=>el.addEventListener(evt, applyInline));
    });

    applyInline();

    document.addEventListener('found_variation', applyInline);
    document.addEventListener('wlp:modal:open', applyInline);
  }

  until(
    ()=> !!(window.wlpSettings && window.LivePreview && getCore()),
    function(){
      const core = getCore();
      if(core) attach(core);
    }
  );
})();